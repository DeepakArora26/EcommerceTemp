package com.amakart.servicetest;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.amakart.model.Category;
import com.amakart.model.Product;
import com.amakart.repository.CategoryRepository;
import com.amakart.repository.ProductRepository;
import com.amakart.service.ShoppingServiceImpl;

class ShoppingServiceTest {

	@Mock
	CategoryRepository categoryRepository;

	@Mock
	ProductRepository productRepository;

	@InjectMocks
	ShoppingServiceImpl shoppingServiceImpl;

	@BeforeEach
	void initialize() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	void testgetCategories() {

		Category category = new Category("Electronics", 3, "Electronics.jpg", true, "ElectronicsPromotedBanner.jpg");
		List<Category> categoryList = new ArrayList<>();
		categoryList.add(category);

		when(categoryRepository.findByparentId(3)).thenReturn(categoryList);
		assertEquals(categoryList, shoppingServiceImpl.getCategories(3));

	}

	@Test
	void testgetProducts() {

		Product product = new Product("M1", "Redmi Note 8", 12999.00, 9999.00, 50, 4.5, "RedmiNote8.jpg");
		List<Product> productList = new ArrayList<>();

		Category category = new Category("Electronics", 3, "Electronics.jpg", true, "ElectronicsPromotedBanner.jpg");
		category.addProduct(product);
		List<Category> categoryList = new ArrayList<>();
		categoryList.add(category);

		productList.add(product);

		when(categoryRepository.findById(4)).thenReturn(categoryList);
		assertEquals(productList, shoppingServiceImpl.getProducts(4));

	}
	
	
	@Test
	void testgetProductDetail() {
	
		Product product = new Product("M1", "Redmi Note 8", 12999.00, 9999.00, 50, 4.5, "RedmiNote8.jpg");
		
		
		when(productRepository.findByProductId("M1")).thenReturn(product);
		assertEquals(product, shoppingServiceImpl.getProductDetail("M1"));

	
	}
	
	
	@Test
	void testgetFirstPromoted() {
	
		Category category = new Category("Electronics", 3, "Electronics.jpg", true, "ElectronicsPromotedBanner.jpg");
		
		
		when(categoryRepository.findFirstPromotedCategory()).thenReturn(category);
		assertEquals(category, shoppingServiceImpl.getFirstPromoted());

	
	}
	
	
	
	
	
	
	@Test
	void testgetSecondPromoted() {
	
		Category category = new Category("Electronics", 3, "Electronics.jpg", true, "ElectronicsPromotedBanner.jpg");
		
		
		when(categoryRepository.findSecondPromotedCategory()).thenReturn(category);
		assertEquals(category, shoppingServiceImpl.getSecondPromoted());

	
	}

}
