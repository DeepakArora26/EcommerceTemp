package com.amakart.exception;

@SuppressWarnings("serial")
public class SecondPromotedCategoryNotFoundException extends Exception {

	public SecondPromotedCategoryNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
