package com.amakart.service;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.amakart.exception.CategoriesNotFoundException;
import com.amakart.exception.FirstPromotedCategoryNotFoundException;
import com.amakart.exception.SecondPromotedCategoryNotFoundException;
import com.amakart.model.Category;
import com.amakart.model.Product;
import com.amakart.repository.CategoryRepository;
import com.amakart.repository.ProductRepository;

@Service
public class ShoppingServiceImpl implements ShoppingService {

	private static final Logger LOGGER = LogManager.getLogger(ShoppingServiceImpl.class);

	@Autowired
	CategoryRepository categoryRepository;

	@Autowired
	ProductRepository productRepository;

	@Override
	public List<Category> getCategories(int parentId) throws CategoriesNotFoundException {

		LOGGER.info("--------In Get Categories Function----------");

		List<Category> categories = categoryRepository.findByparentId(parentId);

		if (categories.isEmpty())
		{

			LOGGER.error("--------Categories Not Found Exception Thrown----------");

			throw new CategoriesNotFoundException("Categories Not Found");
			
			
		}

		return categories;

	}

	@Override
	public List<Product> getProducts(int subCategoryId) {

		return categoryRepository.findById(subCategoryId).get(0).getProducts();

	}

	@Override
	public Product getProductDetail(String productId) {
		return productRepository.findByProductId(productId);
	}

	@Override
	public Category getFirstPromoted() {

		LOGGER.info("--------In Get First Promoted Function----------");

		Category category = categoryRepository.findFirstPromotedCategory();

		if (category == null) 
		{

			LOGGER.error("--------First Promoted Category Not Found Exception Thrown----------");

			category = categoryRepository.findFirstCategory();
		}

		return category;
	}

	@Override
	public Category getSecondPromoted() throws SecondPromotedCategoryNotFoundException {
		
		
		LOGGER.info("--------In Get Second Promoted Function----------");
		
		Category category = categoryRepository.findSecondPromotedCategory();

		if (category == null) 
		{

			LOGGER.error("--------Second Promoted Category Not Found Exception Thrown----------");

			throw new SecondPromotedCategoryNotFoundException("Category Not Found");
			
		}
		return category;
	}

}
