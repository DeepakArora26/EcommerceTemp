package com.amakart.exception;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CategoriesNotFoundExceptionTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
