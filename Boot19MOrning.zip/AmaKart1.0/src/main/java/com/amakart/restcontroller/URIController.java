package com.amakart.restcontroller;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.amakart.Restmodel.CategoryRest;
import com.amakart.Restmodel.ProductRest;
import com.amakart.exception.CategoriesNotFoundException;
import com.amakart.exception.InsufficientQuantityException;
import com.amakart.exception.ProductNotFoundException;
import com.amakart.model.Category;
import com.amakart.model.Product;
import com.amakart.service.CartService;
import com.amakart.service.ShoppingService;

@RestController
public class URIController {

	private static final Logger LOGGER = LogManager.getLogger(URIController.class);

	@Autowired
	ShoppingService shopping;

	@Autowired
	CartService cartService;

	List<CategoryRest> categoryList;

	List<CategoryRest> subCategoryList;

	CategoryRest categoryRest;

	ProductRest productRest;

	List<ProductRest> productList;

	@SuppressWarnings("rawtypes")
	@GetMapping("/displayCategories")
	public ResponseEntity displayCategories() {

		categoryList = new ArrayList<>();

		try {

			for (Category category : shopping.getCategories(0)) {
				categoryRest = new CategoryRest();
				categoryRest.setId(category.getId());
				categoryRest.setName(category.getName());
				categoryList.add(categoryRest);
			}
			return ResponseEntity.ok().body(categoryList);

		} catch (CategoriesNotFoundException e) {

			return new ResponseEntity<>("No Categories Found", HttpStatus.NOT_FOUND);
		}

	}

	@SuppressWarnings("rawtypes")
	@GetMapping("/displaySubCategories/{id}")
	public ResponseEntity displaySubCategories(@PathVariable(value = "id") int parentId) {

		subCategoryList = new ArrayList<>();

		try {

			for (Category category : shopping.getCategories(parentId)) {

				categoryRest = new CategoryRest();
				categoryRest.setId(category.getId());
				categoryRest.setName(category.getName());
				subCategoryList.add(categoryRest);

			}

			return ResponseEntity.ok().body(subCategoryList);

		} catch (CategoriesNotFoundException e) {

			return new ResponseEntity<>("No Subcategories Found", HttpStatus.NOT_FOUND);

		}

	}

	@SuppressWarnings("rawtypes")
	@GetMapping("/displayProducts/{subCategoryid}")
	public ResponseEntity displayProducts(@PathVariable(value = "subCategoryid") int subcategoryId) {

		productList = new ArrayList<>();

		try {
			for (Product product : shopping.getProducts(subcategoryId)) {

				productRest = new ProductRest();
				productRest.setProductId(product.getProductId());
				productRest.setDiscountedPrice(product.getProductDiscountedPrice());
				productRest.setMrp(product.getProductMrp());
				productRest.setName(product.getProductName());
				productRest.setStock(product.getProductAvailableStock());
				productList.add(productRest);
			}

			return ResponseEntity.ok().body(productList);
		}

		catch (ProductNotFoundException e) {

			return new ResponseEntity<>("No Products Found", HttpStatus.NOT_FOUND);

		}

	}

	@SuppressWarnings("rawtypes")
	@PostMapping("/addtocart/{productId}")
	public ResponseEntity addProductToCart(@PathVariable(value = "productId") String productId,
			@RequestParam int productQuantity) {

		try {

			cartService.addToCart(productId, productQuantity, false);

			return ResponseEntity.ok().body("Product Added Successfully");

		} catch (InsufficientQuantityException e) {
			return new ResponseEntity<>("Insufficient Quantity In the Stock", HttpStatus.NOT_ACCEPTABLE);

		}

	}

	@SuppressWarnings("rawtypes")
	@DeleteMapping("/delete/{productId}")
	public ResponseEntity removeProductFromCart(@PathVariable(value = "productId") String productId) {

		cartService.deleteCartItem(productId);

		return ResponseEntity.ok().body("Product Removed Successfully");

	}

	@SuppressWarnings("rawtypes")
	@PutMapping("/updatecart/{productId}")
	public ResponseEntity updateCart(@PathVariable(value = "productId") String productId,
			@RequestParam int updatedProductQuantity) {

		try {

			if(cartService.productExistInCart(productId))
			{
			cartService.addToCart(productId, updatedProductQuantity, true);

			return ResponseEntity.ok().body("Product Updated Successfully");
			}
			
			else
			{
				return ResponseEntity.ok().body("Product Is Not Present In Cart");
						
			}
			
		} catch (InsufficientQuantityException e) {
			return new ResponseEntity<>("Insufficient Quantity In the Stock", HttpStatus.NOT_ACCEPTABLE);

		}

	}

	@SuppressWarnings("rawtypes")
	@GetMapping("/showcart")
	public ResponseEntity showCart() {

		if (cartService.getCart().getCartTotal() > 0) {
			return ResponseEntity.ok().body(cartService.getCart());

		} else {
			return new ResponseEntity<>("Cart Is Empty", HttpStatus.OK);

		}

	}

	@SuppressWarnings("rawtypes")
	@GetMapping("/checkoutrest")
	public ResponseEntity checkout() {

		if (cartService.getCart().getCartTotal() > 0) {
			try {

				return ResponseEntity.ok().body(cartService.checkout());

			}

			catch (InsufficientQuantityException e) {

				return new ResponseEntity<>("Insufficient Quantity In the Stock", HttpStatus.NOT_ACCEPTABLE);

			}

		} else {
			return new ResponseEntity<>("Cart Is Empty", HttpStatus.OK);

		}

	}

}
