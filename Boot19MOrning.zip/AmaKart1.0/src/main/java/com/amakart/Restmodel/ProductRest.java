package com.amakart.Restmodel;

public class ProductRest {

	private String name;
	private double mrp;
	private int stock;
	private double discountedPrice;
	private String productId;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getMrp() {
		return mrp;
	}

	public void setMrp(double mrp) {
		this.mrp = mrp;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

	public double getDiscountedPrice() {
		return discountedPrice;
	}

	public void setDiscountedPrice(double discountedPrice) {
		this.discountedPrice = discountedPrice;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	@Override
	public String toString() {
		return "ProductRest [name=" + name + ", mrp=" + mrp + ", stock=" + stock + ", discountedPrice="
				+ discountedPrice + ", productId=" + productId + "]";
	}

}
