package com.amakart.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Entity
@Component
public class Product {

	@Id
	private String productId;
	private String productName;
	private Double productMrp;
	private Double productDiscountedPrice;
	@Column(columnDefinition = "INT(11) UNSIGNED")
	private int productAvailableStock;
	private Double productAverageRating;
	private String thumbnail;
	@OneToMany(mappedBy = "product", cascade = CascadeType.ALL)
	private List<ProductAttribute> attrbiutes = new ArrayList<>();
	@ElementCollection
	private List<String> productImages = new ArrayList<>();
	@ManyToOne
	@JoinColumn(name = "subCategoryId")
	private Category category;

	
	public Product() {
		super();
	}

	public Product(String productId, String productName, Double productMrp, Double productDiscountedPrice,
			int productAvailableStock, Double productAverageRating, String thumbnail) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productMrp = productMrp;
		this.productDiscountedPrice = productDiscountedPrice;
		this.productAvailableStock = productAvailableStock;
		this.productAverageRating = productAverageRating;
		this.thumbnail = thumbnail;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public Double getProductMrp() {
		return productMrp;
	}

	public void setProductMrp(Double productMrp) {
		this.productMrp = productMrp;
	}

	public Double getProductDiscountedPrice() {
		return productDiscountedPrice;
	}

	public void setProductDiscountedPrice(Double productDiscountedPrice) {
		this.productDiscountedPrice = productDiscountedPrice;
	}

	public int getProductAvailableStock() {
		return productAvailableStock;
	}

	public void setProductAvailableStock(int productAvailableStock) {
		this.productAvailableStock = productAvailableStock;
	}

	public Double getProductAverageRating() {
		return productAverageRating;
	}

	public void setProductAverageRating(Double productAverageRating) {
		this.productAverageRating = productAverageRating;
	}

	public String getThumbnail() {
		return thumbnail;
	}

	public void setThumbnail(String thumbnail) {
		this.thumbnail = thumbnail;
	}

	public List<ProductAttribute> getAttrbiutes() {
		return attrbiutes;
	}


	public List<String> getProductImages() {
		return productImages;
	}

	public void addAttribute(ProductAttribute productAttribute) {
		productAttribute.setProduct(this);
		attrbiutes.add(productAttribute);
	}

	public void addImage(String imagePath) {
		productImages.add(imagePath);
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", productMrp=" + productMrp
				+ ", productDiscountedPrice=" + productDiscountedPrice + ", productAvailableStock="
				+ productAvailableStock + ", productAverageRating=" + productAverageRating + ", thumbnail=" + thumbnail
				+ ", attrbiutes=" + attrbiutes + ", productImages=" + productImages + "]";
	}

}
