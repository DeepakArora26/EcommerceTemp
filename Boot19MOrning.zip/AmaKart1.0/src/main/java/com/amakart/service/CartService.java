package com.amakart.service;

import com.amakart.exception.InsufficientQuantityException;
import com.amakart.exception.ProductNotFoundException;
import com.amakart.model.Cart;
import com.amakart.model.Orders;

public interface CartService {

	boolean addToCart(String productId, int productQuantity,boolean updateCart) throws InsufficientQuantityException;

	boolean checkProductQuantity(String productId, int productQuantity);

	void calculateCartTotal();

	boolean productExistInCart(String productId);
	
	int checkExistingProductQuantity(String productId);

	Orders checkout() throws InsufficientQuantityException;
	
	Cart getCart();
	
	void initializeCart();
	
	boolean deleteCartItem(String productId);
	
	boolean updateProductQuantity(String productId, int productQuantity) throws InsufficientQuantityException;
	
	boolean addNewProduct(String productId, int productQuantity) throws ProductNotFoundException, InsufficientQuantityException;
	
	

}
