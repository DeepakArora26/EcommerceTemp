package com.amakart.service;

import java.util.List;

import com.amakart.exception.CategoriesNotFoundException;
import com.amakart.exception.FirstPromotedCategoryNotFoundException;
import com.amakart.exception.ProductNotFoundException;
import com.amakart.exception.SecondPromotedCategoryNotFoundException;
import com.amakart.model.Category;
import com.amakart.model.Product;

public interface ShoppingService {

	List<Category> getCategories(int parentId) throws CategoriesNotFoundException;

	List<Product> getProducts(int subCategoryId) throws ProductNotFoundException;

	Product getProductDetail(String productId) throws ProductNotFoundException;

	Category getFirstPromoted();

	Category getSecondPromoted() throws SecondPromotedCategoryNotFoundException;

}
