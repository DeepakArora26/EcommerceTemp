package com.amakart.exception;

@SuppressWarnings("serial")
public class EmptyCart extends RuntimeException {

	public EmptyCart(String message) {
		super(message);
	}

}
