package com.amakart.exception;

@SuppressWarnings("serial")
public class SubCategoriesNotFoundException extends Exception {

	public SubCategoriesNotFoundException(String message) {
		super(message);
	}

}
