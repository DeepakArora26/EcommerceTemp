package com.amakart.exception;

public class SubCategoryNotFoundException extends Exception {
    public SubCategoryNotFoundException(String message) {
        super(message);
    }
}
