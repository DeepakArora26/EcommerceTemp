package com.amakart.exception;

public class ProductNotInCartException extends Exception {
    public ProductNotInCartException(String message) {
        super(message);
    }
}
