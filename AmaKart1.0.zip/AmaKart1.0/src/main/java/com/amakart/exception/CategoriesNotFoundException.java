
package com.amakart.exception;

@SuppressWarnings("serial")
public class CategoriesNotFoundException extends Exception {

	public CategoriesNotFoundException(String message) {
		super(message);
	}

}
