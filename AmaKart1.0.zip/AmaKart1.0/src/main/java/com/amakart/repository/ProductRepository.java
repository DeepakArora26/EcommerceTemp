package com.amakart.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.amakart.model.Product;

public interface ProductRepository extends JpaRepository<Product, String> {

	Product findByProductId(String productId);


}
