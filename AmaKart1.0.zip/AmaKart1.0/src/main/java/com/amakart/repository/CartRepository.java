package com.amakart.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.amakart.model.Cart;

public interface CartRepository extends JpaRepository<Cart, Integer> {

	Cart findById(int id);

}
