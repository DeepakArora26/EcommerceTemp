package com.amakart.config;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.amakart.exception.CategoriesNotFoundException;
import com.amakart.service.ShoppingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.amakart.service.CartService;

@Component
public class RequestInterceptor implements HandlerInterceptor {

	

	@Autowired
	CartService cartService;

	@Autowired
	ShoppingService shopping;



	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {


			if(response.getStatus() != HttpStatus.NOT_FOUND.value() && modelAndView.isReference()) {

				modelAndView.addObject("CartTotal", cartService.getCart().getCartTotal());

				modelAndView.addObject("Cart", cartService.getCart().getCartItems());


			try {

				modelAndView.addObject("categoriesList", shopping.getCategories());

			} catch (CategoriesNotFoundException exception) {
				modelAndView.setViewName("coming_soon");
			}
		}
		HandlerInterceptor.super.postHandle(request, response, handler, modelAndView);
	}
	
	

}
