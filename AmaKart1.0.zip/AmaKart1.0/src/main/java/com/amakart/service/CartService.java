package com.amakart.service;

import com.amakart.exception.*;
import com.amakart.model.Cart;
import com.amakart.model.Orders;

public interface CartService {

	boolean addToCart(String productId, int productQuantity,boolean updateCart) throws InsufficientQuantityException, ProductNotFoundException, ProductNotInCartException, InvalidQuantityException;

	boolean checkProductQuantity(String productId, int productQuantity);

	void calculateCartTotal();

	boolean productExistInCart(String productId) throws ProductNotInCartException;
	
	int checkExistingProductQuantity(String productId);

	Orders checkout() throws InsufficientQuantityException, EmptyCart;
	
	Cart getCart() throws EmptyCart;
	
	void initializeCart();
	
	boolean deleteCartItem(String productId) throws ProductNotInCartException;
	
	boolean updateProductQuantity(String productId, int productQuantity) throws InsufficientQuantityException;
	
	boolean addNewProduct(String productId, int productQuantity) throws ProductNotFoundException, InsufficientQuantityException;

}
