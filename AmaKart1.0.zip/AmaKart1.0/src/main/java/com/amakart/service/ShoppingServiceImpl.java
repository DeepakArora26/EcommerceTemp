package com.amakart.service;

import java.util.List;

import com.amakart.exception.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.amakart.model.Category;
import com.amakart.model.Product;
import com.amakart.repository.CategoryRepository;
import com.amakart.repository.ProductRepository;

@Service
public class ShoppingServiceImpl implements ShoppingService {

	private static final Logger LOGGER = LogManager.getLogger(ShoppingServiceImpl.class);

	@Autowired
	CategoryRepository categoryRepository;

	@Autowired
	ProductRepository productRepository;

	@Override
	public List<Category> getCategories() throws CategoriesNotFoundException {

		LOGGER.info("--------In Get Categories Function----------");

		List<Category> categories = categoryRepository.findByparentId(0);

		if (categories.isEmpty()) {

			LOGGER.error("--------Categories Not Found Exception Thrown----------");

			throw new CategoriesNotFoundException("Categories Not Found");

		}

		return categories;

	}


	@Override
	public List<Category> getSubCategories(int parentId) throws SubCategoriesNotFoundException, CategoryNotFoundException {

		LOGGER.info("--------In Get Sub-Categories Function----------");


		if(!checkCategoryAvailability(parentId))
		{

			throw new CategoryNotFoundException("Category Not Found");

		}

			List<Category> categories = categoryRepository.findByparentId(parentId);

			if (categories.isEmpty()) {

				LOGGER.error("--------Sub-Categories Not Found Exception Thrown----------");

				throw new SubCategoriesNotFoundException("Sub-Categories Not Found");

			}

		return categories;

	}

	@Override
	public boolean checkCategoryAvailability(int parentId)  {

		boolean result = true;

		Category category = categoryRepository.findIfCategoryOrNot(parentId);

		if(category == null)
		{
			result = false;

		}

		return result;

	}

	@Override
	public List<Product> getProducts(int subCategoryId) throws ProductNotFoundException, SubCategoryNotFoundException {

		LOGGER.info("--------In Get Products Function----------");

		Category category = categoryRepository.findById(subCategoryId);
		
		if(category == null)
		{
			throw new SubCategoryNotFoundException("Sub Category Not Found WIth Given Id");
		}
		
		List<Product> productList = category.getProducts();
		
		if (productList.isEmpty()) {

			LOGGER.error("--------Product Not Found Exception Thrown----------");

			throw new ProductNotFoundException("Products Not Found");

		}

		return productList;

	}

	@Override
	public Product getProductDetail(String productId) throws ProductNotFoundException {

		LOGGER.info("--------In Get Product Details Function----------");

		Product product = productRepository.findByProductId(productId);

		if (product == null) {

			LOGGER.error("--------Product Not Found Exception Thrown----------");

			throw new ProductNotFoundException("Products Not Found");

		}

		return product;
	}

	@Override
	public String getCategoryName(int id) {

		return categoryRepository.findById(id).getName();

	}


	@Override
	public Category getFirstPromoted() {

		LOGGER.info("--------In Get First Promoted Function----------");

		Category category = categoryRepository.findFirstPromotedCategory();

		if (category == null) {

			LOGGER.info("--------First Promoted Category Not Found Returning First Category----------");

			category = categoryRepository.findFirstCategory();
		}

		return category;
	}

	@Override
	public List<Category> getFirstPromotedSubCategories() throws SubCategoriesNotFoundException, CategoryNotFoundException {

			return getSubCategories(getFirstPromoted().getId());

	}

	@Override
	public Category getSecondPromoted() throws SecondPromotedCategoryNotFoundException {

		LOGGER.info("--------In Get Second Promoted Function----------");

		Category category = categoryRepository.findSecondPromotedCategory();

		if (category == null) {

			LOGGER.error("--------Second Promoted Category Not Found Exception Thrown----------");

			throw new SecondPromotedCategoryNotFoundException("Category Not Found");

		}
		return category;
	}

	@Override
	public List<Category> getSecondPromotedSubCategories() throws SubCategoriesNotFoundException, SecondPromotedCategoryNotFoundException, CategoryNotFoundException {

		return getSubCategories(getSecondPromoted().getId());

	}

	@Override
	public String getCategoryNameOfSubCategory(int subCategoryId) {

		int id = categoryRepository.findById(subCategoryId).getParentId();

		return categoryRepository.findById(id).getName();

	}

    @Override
    public String getSubCategoryNameFromProductId(String productId) {

		return productRepository.findById(productId).get().getCategory().getName();

    }

	@Override
	public String getCategoryNameFromProductId(String productId) {

		int categoryId =  productRepository.findById(productId).get().getCategory().getParentId();

		return getCategoryName(categoryId);

	}

}
