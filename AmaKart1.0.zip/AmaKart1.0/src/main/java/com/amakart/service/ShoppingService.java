package com.amakart.service;

import java.util.List;

import com.amakart.exception.*;
import com.amakart.model.Category;
import com.amakart.model.Product;

public interface ShoppingService {

	List<Category> getCategories() throws CategoriesNotFoundException;

	List<Category> getSubCategories(int parentId) throws SubCategoriesNotFoundException, CategoryNotFoundException;

	boolean checkCategoryAvailability(int parentId) throws CategoryNotFoundException;

	List<Product> getProducts(int subCategoryId) throws ProductNotFoundException, SubCategoryNotFoundException;

	Product getProductDetail(String productId) throws ProductNotFoundException;

	String getCategoryName(int id);

	Category getFirstPromoted();

	List<Category> getFirstPromotedSubCategories() throws SubCategoriesNotFoundException, CategoryNotFoundException;

	Category getSecondPromoted() throws SecondPromotedCategoryNotFoundException;

	List<Category> getSecondPromotedSubCategories() throws SubCategoriesNotFoundException, SecondPromotedCategoryNotFoundException, CategoryNotFoundException;

	String getCategoryNameOfSubCategory(int subCategoryId);

    String getSubCategoryNameFromProductId(String productId);

	String getCategoryNameFromProductId(String productId);

}
