package com.amakart.controller;

import com.amakart.exception.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;

import com.amakart.service.CartService;
import com.amakart.service.ShoppingService;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.io.IOException;

@Controller
public class UserController {

	private static final Logger LOGGER = LogManager.getLogger(UserController.class);

	@Autowired
	ShoppingService shopping;

	@Autowired
	CartService cartService;

	@GetMapping("/")
	public ModelAndView showHome(ModelAndView model) throws CategoryNotFoundException {

		LOGGER.info("--------In showHome Controller----------");

		model.setViewName("Home");

		try {

			model.addObject("firstPromoted", shopping.getFirstPromoted());

			model.addObject("firstPromotedSubcategories", shopping.getFirstPromotedSubCategories());

			model.addObject("FirstPromoSubCatMessage", "Available");

		}


		catch (SubCategoriesNotFoundException e) {

			LOGGER.error("--------First Promoted Sub-Categories Not Found Exception in showHome Controller----------");

		}


		try
		{
			model.addObject("secondPromoted", shopping.getSecondPromoted());

			model.addObject("secondPromotedSubcategories",shopping.getSecondPromotedSubCategories());

			model.addObject("SecondPromoSubCatMessage", "Available");
		}

		catch (SecondPromotedCategoryNotFoundException e) {
			LOGGER.error("--------SecondPromotedCategoryNotFoundException in showHome Controller----------");
		}


		catch (SubCategoriesNotFoundException e) {

			LOGGER.error("--------First Promoted Sub-Categories Not Found Exception in showHome Controller----------");

		}


		return model;

	}


	@GetMapping("/subcategory")
	public ModelAndView showSubCategory(@RequestParam  @Valid int parentId, ModelAndView model, RedirectAttributes redir) {

		LOGGER.info("--------In showSubCategory Controller----------");
		model.setViewName("subcategories");
		try {
			model.addObject("subCategoriesList", shopping.getSubCategories(parentId));
			model.addObject("categoryName", shopping.getCategoryName(parentId));
			redir.addFlashAttribute("categoryName",shopping.getCategoryName(parentId));
			model.addObject("Message", "Available");
		}

		catch (SubCategoriesNotFoundException e) {

			LOGGER.error("--------CategoriesNotFoundException in showSubCategory Controller----------");

			model.addObject("Message", "New Categories Coming Soon !!!!");

		}

		catch (CategoryNotFoundException e) {

			model.setViewName("Error_404");
		}


		return model;

	}

	@GetMapping("/products")
	public ModelAndView showPoducts(@RequestParam int subCategoryId,ModelAndView model) {

		LOGGER.info("--------In products Controller----------");

		try {

			model.addObject("productsList", shopping.getProducts(subCategoryId));

		}

		catch (SubCategoryNotFoundException e) {

			LOGGER.error("--------CategoriesNotFoundException in products Controller----------");
			model.setViewName("coming_soon");
		}

		catch (ProductNotFoundException e) {
			LOGGER.error("--------ProductNotFoundException in products Controller----------");
			model.addObject("Message", "No Products. Coming Soon!!");
		}

		model.addObject("categoryName", shopping.getCategoryNameOfSubCategory(subCategoryId));
		model.addObject("subCategoryName", shopping.getCategoryName(subCategoryId));


		model.setViewName("products");

		return model;

	}

	@GetMapping("/productDetail")
	public ModelAndView showPoductDetails(@RequestParam String productId, ModelAndView model) {

		LOGGER.info("--------In productDetail Controller----------");
		model.setViewName("productDetails");



		try {
			model.addObject("productDetail", shopping.getProductDetail(productId));
			model.addObject("categoryName", shopping.getCategoryNameFromProductId(productId));
			model.addObject("subCategoryName", shopping.getSubCategoryNameFromProductId(productId));


		}

		catch (ProductNotFoundException e)
		{
			LOGGER.error("--------ProductNotFoundException in productDetail Controller----------");

			model.setViewName("Error_404");
		}


		return model;

	}

	@PostMapping("/addtocart")
	public RedirectView addToCart(@RequestParam String productId, @RequestParam int productQuantity, RedirectAttributes redir) throws ProductNotFoundException, ProductNotInCartException, InvalidQuantityException {

		LOGGER.info("--------In addtocart Controller----------");

		try {
			cartService.addToCart(productId, productQuantity, false);

			redir.addFlashAttribute("ProductAdditionMessage", "Product Has Been Successfully Added Into The Cart");

		} catch (InsufficientQuantityException e) {

			LOGGER.error("--------InsufficientQuantityException in addtocart Controller----------");

			redir.addFlashAttribute("ProductAdditionMessage",
					"Sorry It Seems We Don't Have That Much Stock Right Now. Try Again With The Lesser Quantity");
		}

		RedirectView redirectView = new RedirectView();
		redirectView.setUrl("/productDetail");
		redirectView.addStaticAttribute("productId", productId);

		redirectView.getAttributesMap();
		return redirectView;




	}

	@GetMapping("/cart")
	public ModelAndView showCart(ModelAndView model) {

		LOGGER.info("--------In cart Controller----------");

		model.setViewName("cart");

		return model;

	}

	@PostMapping("/checkout")
	public RedirectView checkout(ModelAndView model, RedirectAttributes redir) {

		LOGGER.info("--------In checkout Controller----------");

		try {
			redir.addFlashAttribute("OrderHistory", cartService.checkout());
		} catch (InsufficientQuantityException e) {

			LOGGER.error("--------InsufficientQuantityException in checkout Controller----------");
			e.printStackTrace();
		}

		RedirectView redirectView = new RedirectView();
		redirectView.setUrl("/orders");
		return redirectView;

	}

	@GetMapping("/orders")
	public ModelAndView order(ModelAndView model) {

		LOGGER.info("--------In orders Controller----------");

		model.setViewName("Orders");
		return model;

	}

	@PostMapping("/deleteItem")
	public RedirectView deleteProduct(@RequestParam String productId, ModelAndView model,RedirectView redirectView) throws ProductNotInCartException {

		LOGGER.info("--------In deleteItem Controller----------");

		cartService.deleteCartItem(productId);

		redirectView.setUrl("/cart");

		return redirectView;

	}

	@PostMapping("/updateCart")
	public RedirectView updateCart(@RequestParam String productId, @RequestParam int productQuantity,
			ModelAndView model, RedirectAttributes redir) throws ProductNotFoundException, ProductNotInCartException, InvalidQuantityException {

		LOGGER.info("--------In updateCart Controller----------");

		try {
			cartService.addToCart(productId, productQuantity, true);
			redir.addFlashAttribute("ProductAdditionMessage", "Product Has Been Successfully Added Into The Cart");

		} catch (InsufficientQuantityException e) {

			LOGGER.error("--------InsufficientQuantityException in updateCart Controller----------");

			redir.addFlashAttribute("ProductAdditionMessage",
					"Sorry It Seems We Don't Have That Much Stock Right Now. Try Again With The Lesser Quantity");
		}

		RedirectView redirectView = new RedirectView();
		redirectView.setUrl("/cart");
		return redirectView;

	}

	
	@GetMapping("/contactUs")
	public ModelAndView contactUs(ModelAndView model) {

		LOGGER.info("--------In contactUs Controller----------");


		model.setViewName("contactUs");
		return model;

	}


	@ExceptionHandler
	void handleIllegalArgumentException(IllegalArgumentException e, HttpServletResponse response) throws IOException {
		response.sendError(HttpStatus.BAD_REQUEST.value());
	}


	@ExceptionHandler
	void handleIllegalArgumentException(MissingServletRequestParameterException e, HttpServletResponse response) throws IOException {
		response.sendError(HttpStatus.BAD_REQUEST.value());
	}



}
