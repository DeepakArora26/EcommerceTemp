package com.amakart.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;

import org.springframework.context.annotation.Scope;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Component
@NamedQuery(query = "Select c from Category c where c.parentId = null", name = "find all categories")
public class Category {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@NonNull
	private String name;
	private int parentId;
	@NonNull
	private String image;
	@Column(columnDefinition = "boolean default false")
	private boolean promoted;
	private String promotedThumbnail;
	@OneToMany(mappedBy = "category", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JsonBackReference
	private List<Product> products = new ArrayList<>();

	public Category() {
	}

	public Category(String name, int parentId, String image, String promotedThumbnail) {
		super();
		this.name = name;
		this.parentId = parentId;
		this.image = image;
		this.promotedThumbnail = promotedThumbnail;
	}

	public Category(String name, int parentId, String image, boolean promoted, String promotedThumbnail) {
		super();
		this.name = name;
		this.parentId = parentId;
		this.image = image;
		this.promoted = promoted;
		this.promotedThumbnail = promotedThumbnail;

	}

	public Category(String name, int parentId, String image) {
		super();
		this.name = name;
		this.parentId = parentId;
		this.image = image;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getParentId() {
		return parentId;
	}

	public void setParentId(int parentId) {
		this.parentId = parentId;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public boolean isPromoted() {
		return promoted;
	}

	public void setPromoted(boolean promoted) {
		this.promoted = promoted;
	}

	public String getPromotedThumbnail() {
		return promotedThumbnail;
	}

	public void setPromotedThumbnail(String promotedThumbnail) {
		this.promotedThumbnail = promotedThumbnail;
	}

	public List<Product> getProducts() {
		return products;
	}

	public void addProduct(Product product) {
		product.setCategory(this);
		products.add(product);

	}

	@Override
	public String toString() {
		return "Category [id=" + id + ", name=" + name + ", parentId=" + parentId + ", image=" + image + ", promoted="
				+ promoted + ", promotedThumbnail=" + promotedThumbnail + "]";
	}

}
