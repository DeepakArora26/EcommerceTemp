package com.amakart.restcontroller;

import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.Map;

import com.amakart.exception.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;



@ControllerAdvice
public class ControllerAdvisor extends ResponseEntityExceptionHandler {
	
	
	 @ExceptionHandler(CategoriesNotFoundException.class)
	    public ResponseEntity<Map<String, Object>> handleCategoriesNotFound(CategoriesNotFoundException exception, WebRequest request)
	    {
	        Map<String,Object> body = new LinkedHashMap<>();
	        body.put("timestamp", LocalDate.now());
	        body.put("message","Categories Not  Found. Coming Soon");
	        return new ResponseEntity<Map<String, Object>>(body, HttpStatus.NOT_FOUND);
	    }




	@ExceptionHandler(CategoryNotFoundException.class)
	public ResponseEntity<Map<String, Object>> handleCategoryNotFound(CategoryNotFoundException exception, WebRequest request)
	{
		Map<String,Object> body = new LinkedHashMap<>();
		body.put("timestamp", LocalDate.now());
		body.put("message","Category Not Found Wiith Given Id");
		return new ResponseEntity<Map<String, Object>>(body, HttpStatus.NOT_FOUND);
	}



	@ExceptionHandler(SubCategoriesNotFoundException.class)
	public ResponseEntity<Map<String, Object>> handleSubCategoriesNotFound(SubCategoriesNotFoundException exception, WebRequest request)
	{
		Map<String,Object> body = new LinkedHashMap<>();
		body.put("timestamp", LocalDate.now());
		body.put("message","Sub Categories Not Found. Coming Soon");
		return new ResponseEntity<Map<String, Object>>(body, HttpStatus.NOT_FOUND);
	}



	@ExceptionHandler(SubCategoryNotFoundException.class)
	public ResponseEntity<Map<String, Object>> handleSubCategoryNotFound(SubCategoryNotFoundException exception, WebRequest request)
	{
		Map<String,Object> body = new LinkedHashMap<>();
		body.put("timestamp", LocalDate.now());
		body.put("message","Sub Category Not Found With Given Id");
		return new ResponseEntity<Map<String, Object>>(body, HttpStatus.NOT_FOUND);
	}




	@ExceptionHandler(ProductNotFoundException.class)
	    public ResponseEntity<Map<String, Object>> handleBookNotFound(ProductNotFoundException exception, WebRequest request)
	    {
	        Map<String,Object> body = new LinkedHashMap<>();
	        body.put("timestamp", LocalDate.now());
	        body.put("message","Products Not Found. Coming Soon");
	        return new ResponseEntity<Map<String, Object>>(body, HttpStatus.NOT_FOUND);
	    }



	@ExceptionHandler(ProductNotInCartException.class)
	public ResponseEntity<Map<String, Object>> handleProductNotInCart(ProductNotInCartException exception, WebRequest request)
	{
		Map<String,Object> body = new LinkedHashMap<>();
		body.put("timestamp", LocalDate.now());
		body.put("message","Products Not Found In Cart.");
		return new ResponseEntity<Map<String, Object>>(body, HttpStatus.NOT_FOUND);
	}




	@ExceptionHandler(InsufficientQuantityException.class)
	    public ResponseEntity<Map<String, Object>> handleBookNotFound(InsufficientQuantityException exception, WebRequest request)
	    {
	        Map<String,Object> body = new LinkedHashMap<>();
	        body.put("timestamp", LocalDate.now());
	        body.put("message","Sorry. We don't have this much quantity in stock now.");
	        return new ResponseEntity<Map<String, Object>>(body, HttpStatus.NOT_FOUND);
	    }



	@ExceptionHandler(InvalidQuantityException.class)
	public ResponseEntity<Map<String, Object>> handleInvalidQuantityFound(InvalidQuantityException exception, WebRequest request)
	{
		Map<String,Object> body = new LinkedHashMap<>();
		body.put("timestamp", LocalDate.now());
		body.put("message","Sorry. Quantity Cannot be in Negative.");
		return new ResponseEntity<Map<String, Object>>(body, HttpStatus.NOT_FOUND);
	}





	@ExceptionHandler(EmptyCart.class)
	    public ResponseEntity<Map<String, Object>> handleBookNotFound(EmptyCart exception, WebRequest request)
	    {
	        Map<String,Object> body = new LinkedHashMap<>();
	        body.put("timestamp", LocalDate.now());
	        body.put("message","Cart Is Empty");
	        return new ResponseEntity<Map<String, Object>>(body, HttpStatus.OK);
	    }







}
