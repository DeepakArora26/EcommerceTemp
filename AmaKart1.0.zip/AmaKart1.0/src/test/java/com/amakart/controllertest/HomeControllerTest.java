package com.amakart.controllertest;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.amakart.controller.UserController;
import com.amakart.model.Cart;
import com.amakart.model.CartItem;
import com.amakart.model.Category;
import com.amakart.model.Product;
import com.amakart.model.ProductAttribute;
import com.amakart.service.CartService;
import com.amakart.service.ShoppingService;

class HomeControllerTest {

	private MockMvc mockMvc;

	@InjectMocks
	UserController homeController;

	@Mock
	ShoppingService shopping;
	
	static List<Category> categoryList = new ArrayList<>();
	
	static Category category;
	
	static List<CartItem> cartItemList = new ArrayList<>();
	
	static Cart cart;
	
	@Mock
	CartService cartservice;

	@BeforeEach
	public void setup() {
		MockitoAnnotations.initMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(homeController).build();
	}

	@BeforeAll
	public static void init() {
		
		
		category = new Category("Electronics", 3, "Electronics.jpg", true, "ElectronicsPromotedBanner.jpg");

		categoryList.add(category);

		category = new Category("Electronics", 3, "Electronics.jpg", true, "ElectronicsPromotedBanner.jpg");

		categoryList.add(category);
		
		cart = new Cart();
		
		cart.setCartId(1);
		cart.setCartTotal(0.0);
		cart.setUserId("Dummy");
				
		CartItem cartItem = new CartItem();
		cartItem.setProductId("1");
		cartItem.setProductImage("Try");
		cartItem.setProductName("Mobile");
		cartItem.setProductPrice(200.0);
		cartItem.setProductPurchasedQuantity(10);
		cartItem.setProductTotalPrice();
		cart.addCartItem(cartItem);
		

	}

	@Test
	void testHomePage() throws Exception {
		Mockito.when(shopping.getCategories()).thenReturn(categoryList);
		Mockito.when(shopping.getFirstPromoted()).thenReturn(category);
		Mockito.when(shopping.getFirstPromotedSubCategories()).thenReturn(categoryList);
		Mockito.when(shopping.getSecondPromoted()).thenReturn(category);
		Mockito.when(cartservice.getCart()).thenReturn(cart);
		
		this.mockMvc.perform(get("/")).andExpect(status().is2xxSuccessful()).andExpect(view().name("Home"))
				.andExpect(model().attribute("categoriesList", categoryList));
	}

	
	@Test
	void testHomePage1() throws Exception {
		this.mockMvc.perform(get("/fdfdf")).andExpect(status().is4xxClientError());
	}

}
