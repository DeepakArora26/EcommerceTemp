package com.amakart.servicetest;

import static org.hamcrest.CoreMatchers.everyItem;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.amakart.exception.InvalidQuantityException;
import com.amakart.exception.ProductNotFoundException;
import com.amakart.exception.ProductNotInCartException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.amakart.exception.InsufficientQuantityException;
import com.amakart.model.Cart;
import com.amakart.model.CartItem;
import com.amakart.model.Product;
import com.amakart.repository.CartItemRepository;
import com.amakart.repository.CartRepository;
import com.amakart.repository.ProductRepository;
import com.amakart.service.CartServiceImpl;

class CartServiceTest {

	@InjectMocks
	CartServiceImpl cartServiceImpl;

	@Mock
	ProductRepository productRepository;
	
	@Mock
	CartItemRepository cartItemRepository;
	
	
	@Mock
	CartRepository cartRepository;
	
	@Mock
	Cart cart;

	@Mock
	Product product;

	@BeforeEach
	void initialize() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	void testProductQuantityTrue() {

		product = new Product();
		product.setProductAvailableStock(10);
		product.setProductId("M1");

		String productId = "M1";
		when(productRepository.findByProductId(productId)).thenReturn(product);

		assertEquals(true, cartServiceImpl.checkProductQuantity(productId, 5));
	}

	@Test
	void testProductQuantityFalse() {

		product = new Product();
		product.setProductAvailableStock(1);
		product.setProductId("M1");

		String productId = "M1";
		when(productRepository.findByProductId(productId)).thenReturn(product);

		assertEquals(false, cartServiceImpl.checkProductQuantity(productId, 5));
	}

	@Test
	void testaddToCart() throws InsufficientQuantityException, ProductNotFoundException, ProductNotInCartException, InvalidQuantityException {

		product = new Product();
		product.setProductId("M1");
		product.setThumbnail("ABC.jpg");
		product.setProductName("Sports");
		product.setProductDiscountedPrice(1100.00);
		product.setProductAvailableStock(100);

		CartItem cartProduct = new CartItem();
		cartProduct.setProductId("M1");
		cartProduct.setProductPurchasedQuantity(1);
		cart.addCartItem(cartProduct);

		String productId = "M1";

		when(cartServiceImpl.productExistInCart(productId)).thenReturn(false);
		when(productRepository.findByProductId(productId)).thenReturn(product);
		assertEquals(true, cartServiceImpl.addToCart(productId, 10,false));
	
	}

	
	@Test
	void testaddToCartFalse() throws InsufficientQuantityException, ProductNotFoundException, ProductNotInCartException, InvalidQuantityException {

		product = new Product();
		product.setProductId("M1");
		product.setThumbnail("ABC.jpg");
		product.setProductName("Sports");
		product.setProductDiscountedPrice(1100.00);
		product.setProductAvailableStock(100);

		CartItem cartProduct = new CartItem();
		cartProduct.setProductId("M1");
		cartProduct.setProductPurchasedQuantity(1);
		cart.addCartItem(cartProduct);

		String productId = "M1";

		when(productRepository.findByProductId(productId)).thenReturn(product);
		assertEquals(false, cartServiceImpl.addToCart(productId, 1000,false));
		
	}

	
	
	@Test
	void testproductExistInCartWithNull() throws ProductNotInCartException {
		when(cartItemRepository.findById("M1")).thenReturn(Optional.ofNullable(null));
		assertEquals(false, cartServiceImpl.productExistInCart("M1"));
	}
	
	
	@Test
	void testproductExistInCart() throws ProductNotInCartException {

		CartItem cartProduct = new CartItem();
		cartProduct.setProductId("M1");
		cartProduct.setProductPurchasedQuantity(1);
		
		when(cartItemRepository.findById("M1")).thenReturn(Optional.ofNullable(cartProduct));
		assertEquals(true, cartServiceImpl.productExistInCart("M1"));
	}
	
	
	
	@Test
	void testcheckExistingProductQuantity()
	{
		CartItem cartProduct = new CartItem();
		cartProduct.setProductId("M1");
		cartProduct.setProductPurchasedQuantity(1);
		
		when(cartItemRepository.findById("M1")).thenReturn(Optional.ofNullable(cartProduct));
		assertEquals(1,cartServiceImpl.checkExistingProductQuantity("M1"));
	}
	
	
	@Test
	void testcalculateCartTotal()
	{
		
		cart = new Cart();
		cart.setCartTotal(0.0);
		cart.setCartId(1);
		cart.setUserId("Dummy");
		CartItem cartProduct = new CartItem();
		cartProduct.setProductId("M1");
		cartProduct.setProductPurchasedQuantity(1);
		cartProduct.setProductPrice(100.0);
		cartProduct.setProductTotalPrice();
		cart.addCartItem(cartProduct);
		
		
		cartProduct = new CartItem();
		cartProduct.setProductId("M2");
		cartProduct.setProductPurchasedQuantity(10);
		cartProduct.setProductPrice(200.0);
		cartProduct.setProductTotalPrice();
		cart.addCartItem(cartProduct);
		
		
		when(cartItemRepository.findAll()).thenReturn(cart.getCartItems());
		cartServiceImpl.calculateCartTotal();
		cartRepository.save(cart);
		assertEquals(0.0,cart.getCartTotal());
	}
	
	
	
	
	@Test
	void testcheckout()
	{
		
		
		when(cartServiceImpl.getCart()).thenReturn(cart);
		
	}
	

}
