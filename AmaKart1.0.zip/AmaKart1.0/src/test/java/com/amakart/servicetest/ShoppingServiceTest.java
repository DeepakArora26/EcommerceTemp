package com.amakart.servicetest;

import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.amakart.exception.CategoriesNotFoundException;
import com.amakart.exception.ProductNotFoundException;
import com.amakart.exception.SecondPromotedCategoryNotFoundException;
import com.amakart.model.Cart;
import com.amakart.model.CartItem;
import com.amakart.model.Category;
import com.amakart.model.Product;
import com.amakart.repository.CategoryRepository;
import com.amakart.repository.ProductRepository;
import com.amakart.service.CartService;
import com.amakart.service.ShoppingServiceImpl;

class ShoppingServiceTest {

	@Mock
	CategoryRepository categoryRepository;

	@Mock
	ProductRepository productRepository;

	@InjectMocks
	ShoppingServiceImpl shoppingServiceImpl;

	@BeforeEach
	void initialize() {
		MockitoAnnotations.initMocks(this);
	}

	static List<Category> categoryList = new ArrayList<>();

	static Category category;

	static List<CartItem> cartItemList = new ArrayList<>();

	static Cart cart;

	static List<Product> productList = new ArrayList<>();

	static Product product;

	@Mock
	CartService cartservice;

	@BeforeAll
	public static void init() {

		category = new Category("Electronics", 0, "Electronics.jpg", true, "ElectronicsPromotedBanner.jpg");
		category.setId(1);
		product = new Product("M1", "Redmi Note 8", 12999.00, 9999.00, 50, 4.5, "RedmiNote8.jpg");
		category.addProduct(product);
		productList.add(product);

		product = new Product("M2", "Realme U1", 112999.00, 19999.00, 50, 3.5, "realMe.jpg");
		category.addProduct(product);
		productList.add(product);

		categoryList.add(category);

		category = new Category("Sports", 0, "Sports.jpg", true, "SportsPromotedBanner.jpg");
		category.setId(2);

		categoryList.add(category);

		cart = new Cart();

		cart.setCartId(1);
		cart.setCartTotal(0.0);
		cart.setUserId("Dummy");

		CartItem cartItem = new CartItem();
		cartItem.setProductId("1");
		cartItem.setProductImage("Try");
		cartItem.setProductName("Mobile");
		cartItem.setProductPrice(200.0);
		cartItem.setProductPurchasedQuantity(10);
		cartItem.setProductTotalPrice();
		cart.addCartItem(cartItem);

	}

	@Test
	void testgetCategories() throws CategoriesNotFoundException {

		when(categoryRepository.findByparentId(0)).thenReturn(categoryList);
		assertEquals(categoryList, shoppingServiceImpl.getCategories());

	}

	@Test
	void testgetCategoriesWithEmptyList() throws CategoriesNotFoundException {

		when(categoryRepository.findByparentId(0)).thenReturn(new ArrayList<Category>());
		assertThatExceptionOfType(CategoriesNotFoundException.class)
				.isThrownBy(() -> shoppingServiceImpl.getCategories()).withMessage("Categories Not Found");

	}

	@Test
	void testgetProducts() throws ProductNotFoundException {

		//when(categoryRepository.findById(1)).thenReturn(categoryList);
		//assertEquals(productList, shoppingServiceImpl.getProducts(1));

	}

	@Test
	void testgetProductsWithEmptyList() throws ProductNotFoundException {

		categoryList = new ArrayList<Category>();
		categoryList.add(category);

		//when(categoryRepository.findById(1)).thenReturn(categoryList);
		assertThatExceptionOfType(ProductNotFoundException.class).isThrownBy(() -> shoppingServiceImpl.getProducts(1))
				.withMessage("Products Not Found");

	}

	@Test
	void testgetProductDetail() throws ProductNotFoundException {

		when(productRepository.findByProductId("M2")).thenReturn(product);
		assertEquals(product, shoppingServiceImpl.getProductDetail("M2"));

	}

	@Test
	void testgetProductDetailWithNullProduct() throws ProductNotFoundException {

		when(productRepository.findByProductId("M2")).thenReturn(null);

		assertThatExceptionOfType(ProductNotFoundException.class)
				.isThrownBy(() -> shoppingServiceImpl.getProductDetail("M2")).withMessage("Products Not Found");

	}

	@Test
	void testgetFirstPromoted() {

		when(categoryRepository.findFirstPromotedCategory()).thenReturn(category);
		assertEquals(category, shoppingServiceImpl.getFirstPromoted());

	}
	
	
	@Test
	void testgetFirstPromotedWithNull() {


		when(categoryRepository.findFirstPromotedCategory()).thenReturn(null);
		when(categoryRepository.findFirstCategory()).thenReturn(category);
		assertEquals(category, shoppingServiceImpl.getFirstPromoted());

	}
	

	@Test
	void testgetSecondPromoted() throws SecondPromotedCategoryNotFoundException {


		when(categoryRepository.findSecondPromotedCategory()).thenReturn(category);
		assertEquals(category, shoppingServiceImpl.getSecondPromoted());

	}
	
	

	@Test
	void testgetSecondPromotedWithNull() throws SecondPromotedCategoryNotFoundException {


		when(categoryRepository.findSecondPromotedCategory()).thenReturn(null);
		assertThatExceptionOfType(SecondPromotedCategoryNotFoundException.class)
		.isThrownBy(() -> shoppingServiceImpl.getSecondPromoted()).withMessage("Category Not Found");

	}
	

}
