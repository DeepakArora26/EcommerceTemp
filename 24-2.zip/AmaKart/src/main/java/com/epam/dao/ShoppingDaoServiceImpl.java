package com.epam.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.epam.jdbc.Jdbc;
import com.epam.model.Cart;
import com.epam.model.Categories;
import com.epam.model.Product;
import com.epam.model.SubCategories;

public class ShoppingDaoServiceImpl implements ShoppingDaoService {

	public static Connection con = Jdbc.getDBConnection();
	ResultSet rs = null;
	Categories categoryDetail;
	SubCategories subCategoryDetail;
	Product productDetail;
	List<Categories> categoryList;

	@Override
	public List<Categories> getCategories() {

		categoryList = new ArrayList<>();

		try {

			
			Statement stmt = con.createStatement();
			
			rs = stmt.executeQuery("select * from categories");

			while (rs.next()) {

				categoryDetail = new Categories();
				categoryDetail.setcategoryId(rs.getString(1));
				categoryDetail.setcategoryName(rs.getString(2));
				categoryDetail.setcategoryImage(rs.getString(3));
				categoryList.add(categoryDetail);

			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return categoryList;

	}

	@Override
	public ResultSet getSubCategories(String categoryId) {

		try {
			Statement stmt = con.createStatement();
			rs = stmt.executeQuery("select * from sub_categories where category_id = '" + categoryId + "'");

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return rs;
	}

	@Override
	public ResultSet getProducts(String subCategoryId) {

		try {
			Statement stmt = con.createStatement();
			rs = stmt.executeQuery("select * from product where sub_category_id = '" + subCategoryId + "'");

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return rs;
	}

	@Override
	public ResultSet getProductDetails(String productId) {

		try {
			Statement stmt = con.createStatement();
			rs = stmt.executeQuery("select * from product where product_id = '" + productId + "'");

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return rs;
	}

	@Override
	public void checkout(String customerName, List<Cart> currentCart) {
		String insertValues;

		try {
			Statement stmt = con.createStatement();

			String insertData = "insert into order_history (CUSTOMER_NAME , CART_TOTAL , ORDER_DATE ) values ( '"
					+ customerName + "','" + Cart.cartTotal + "','" + java.time.LocalDate.now() + " ') ";
			stmt.executeUpdate(insertData);

			rs = stmt.executeQuery("SELECT * FROM order_history ORDER BY orderId DESC LIMIT 1");
			rs.next();

			int orderId = rs.getInt(1);

			for (Cart currentProduct : currentCart) {

				insertValues = " insert into order_details values (  " + orderId + " ,'"
						+ currentProduct.getProductName() + "'," + currentProduct.getProductQuantity() + ","
						+ currentProduct.getProductPrice() + "," + currentProduct.getTotalPrice() + " ) ";
				stmt.executeUpdate(insertValues);

			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
