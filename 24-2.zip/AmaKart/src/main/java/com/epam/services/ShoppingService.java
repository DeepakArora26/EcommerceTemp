package com.epam.services;

import java.util.List;

import com.epam.model.Categories;
import com.epam.model.Product;
import com.epam.model.SubCategories;

public interface ShoppingService {


	List<Categories> getCategoriesList();
	
	List<SubCategories> getSubCategoriesList(String categoryId);
	
	List<Product> getProductsList(String subCategoryId);
	
	Product getproductDetails(String productId);
	
	


}
