package com.epam.services;

import java.util.List;

import com.epam.jdbc.Jdbc;
import com.epam.model.Cart;
import com.epam.model.Product;

public class CartServiceImpl implements CartService {
	
	Cart currentProduct;
	Jdbc data = new Jdbc();
	ShoppingService shopping;
	Product product;
	
	@Override
	public void addToCart(String productId,int productQuantity) {
		
		
		shopping = new ShoppingServiceImpl();
		product = new Product();
		
		product = shopping.getproductDetails(productId);
		

		
		currentProduct = new Cart(productId, product.getproductName(), product.getproductPrice(), productQuantity, product.getproductImage());
		
		Jdbc.cart.add(currentProduct);
		
	}

	
	
	@Override
	public List<Cart> getCart() {
		
		
		return Jdbc.cart;
		
		
	}



	@Override
	public void calculateCartTotal() {
		
		Double cartTotal=0.0;
		
		for (Cart currentProduct : Jdbc.cart) {
			cartTotal = cartTotal + currentProduct.getTotalPrice();
        }
		Cart.cartTotal = cartTotal;
	}

	

}
