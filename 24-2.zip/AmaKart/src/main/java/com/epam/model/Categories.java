package com.epam.model;

public class Categories {

	private String categoryId;
	private String categoryName;
	private String categoryImage;

	public String getcategoryId() {
		return categoryId;
	}

	public void setcategoryId(String categoryId) {
		this.categoryId = categoryId;
	}

	public String getcategoryName() {
		return categoryName;
	}

	public void setcategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public String getcategoryImage() {
		return categoryImage;
	}

	public void setcategoryImage(String categoryImage) {
		this.categoryImage = categoryImage;
	}

	@Override
	public String toString() {
		return "Categories [categoryId=" + categoryId + ", categoryName=" + categoryName + "]";
	}

}
