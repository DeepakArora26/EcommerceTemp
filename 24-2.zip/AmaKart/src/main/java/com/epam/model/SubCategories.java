package com.epam.model;

public class SubCategories {

	private String categoryId;
	private String subCategoryId;
	private String subCategoryName;
	private String subCategoryImage;

	public String getcategoryId() {
		return categoryId;
	}

	public void setcategoryId(String categoryId) {
		this.categoryId = categoryId;
	}

	public String getsubCategoryId() {
		return subCategoryId;
	}

	public void setsubCategoryId(String subCategoryId) {
		this.subCategoryId = subCategoryId;
	}

	public String getsubCategoryName() {
		return subCategoryName;
	}

	public void setsubCategoryName(String subCategoryName) {
		this.subCategoryName = subCategoryName;
	}
	
	
	
	public String getsubCategoryImage() {
		return subCategoryImage;
	}

	public void setsubCategoryImage(String subCategoryImage) {
		this.subCategoryImage = subCategoryImage;
	}

	@Override
	public String toString() {
		return "Sub_Categories [categoryId=" + categoryId + ", subCategoryId=" + subCategoryId
				+ ", subCategoryName=" + subCategoryName + "]";
	}

}
