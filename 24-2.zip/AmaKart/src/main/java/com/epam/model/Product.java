package com.epam.model;

public class Product {

	private String categoryId;
	private String subCategoryId;
	private String productId;
	private String productName;
	private Double productPrice;
	private int productQuantity;
	private String productImage;

	public String getcategoryId() {
		return categoryId;
	}

	public void setcategoryId(String categoryId) {
		this.categoryId = categoryId;
	}

	public String getsubCategoryId() {
		return subCategoryId;
	}

	public void setsubCategoryId(String subCategoryId) {
		this.subCategoryId = subCategoryId;
	}

	public String getproductId() {
		return productId;
	}

	public void setproductId(String productId) {
		this.productId = productId;
	}

	public String getproductName() {
		return productName;
	}

	public void setproductName(String productName) {
		this.productName = productName;
	}

	public Double getproductPrice() {
		return productPrice;
	}

	public void setproductPrice(Double productPrice) {
		this.productPrice = productPrice;
	}

	public int getproductQuantity() {
		return productQuantity;
	}

	public void setproductQuantity(int productQuantity) {
		this.productQuantity = productQuantity;
	}
	
	
	public String getproductImage() {
		return productImage;
	}

	public void setproductImage(String productImage) {
		this.productImage = productImage;
	}

	@Override
	public String toString() {
		return "Product [categoryId=" + categoryId + ", subCategoryId=" + subCategoryId + ", productId="
				+ productId + ", productName=" + productName + ", productPrice=" + productPrice
				+ ", productQuantity=" + productQuantity + "]";
	}

}
