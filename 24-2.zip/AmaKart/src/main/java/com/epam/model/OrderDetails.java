package com.epam.model;

public class OrderDetails {

	private String orderId;
	private String productName;
	private int productQuantity;
	private Double productPrice;
	private Double productTotalPrice;

	public String getorderId() {
		return orderId;
	}

	public void setorderId(String orderId) {
		this.orderId = orderId;
	}

	public String getproductName() {
		return productName;
	}

	public void setproductName(String productName) {
		this.productName = productName;
	}

	public int getproductQuantity() {
		return productQuantity;
	}

	public void setproductQuantity(int productQuantity) {
		this.productQuantity = productQuantity;
	}

	public Double getproductPrice() {
		return productPrice;
	}

	public void setproductPrice(Double productPrice) {
		this.productPrice = productPrice;
	}

	public Double getproductTotalPrice() {
		return productTotalPrice;
	}

	public void setproductTotalPrice(Double productTotalPrice) {
		this.productTotalPrice = productTotalPrice;
	}

	@Override
	public String toString() {
		return "Order_Details [orderId=" + orderId + ", productName=" + productName + ", productQuantity="
				+ productQuantity + ", productPrice=" + productPrice + ", productTotalPrice=" + productTotalPrice
				+ "]";
	}

}
