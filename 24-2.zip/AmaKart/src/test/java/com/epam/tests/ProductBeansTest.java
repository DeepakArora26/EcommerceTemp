package com.epam.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.epam.model.Cart;
import com.epam.model.Product;

class ProductBeansTest {

	Product productDetail;

	@BeforeEach
	void init() {

		productDetail = new Product();

	}

	@Test
	void checkproductIdWithNull() {

		assertEquals(null, productDetail.getproductId());
	}

	@Test
	void checkproductId() {
		productDetail.setproductId("EM1");
		assertEquals("EM1", productDetail.getproductId());
	}

	@Test
	void checkproductNameWithNull() {

		assertEquals(null, productDetail.getproductName());
	}

	@Test
	void checkproductName() {
		productDetail.setproductName("Redmi Note 8");

		assertEquals("Redmi Note 8", productDetail.getproductName());
	}

	@Test
	void checkCategoryIdWithNull() {

		assertEquals(null, productDetail.getcategoryId());
	}

	@Test
	void checkCategoryId() {
		productDetail.setcategoryId("1");

		assertEquals("1", productDetail.getcategoryId());
	}

	@Test
	void checkSubCategoryIdWithNull() {

		assertEquals(null, productDetail.getsubCategoryId());
	}

	@Test
	void checkSubCategoryId() {
		productDetail.setsubCategoryId("FW");

		assertEquals("13ef", productDetail.getsubCategoryId());
	}

	@Test
	void checkproductPriceWithNull() {

		assertEquals(null, productDetail.getproductPrice());
	}

	@Test
	void checkproductPrice() {
		productDetail.setproductPrice(9999.0);

		assertEquals(9999.0, productDetail.getproductPrice());
	}

	@Test
	void checkproductQuantityWithNull() {

		assertEquals(0, productDetail.getproductQuantity());
	}

	@Test
	void checkproductQuantity() {
		productDetail.setproductQuantity(10);

		assertEquals(10, productDetail.getproductQuantity());
	}

	@Test
	void checkproductImageWithNull() {

		assertEquals(null, productDetail.getproductImage());
	}

	@Test
	void checkproductImage() {
		productDetail.setproductImage("RedmiNote8.jpg");

		assertEquals("RedmiNote8.jpg", productDetail.getproductImage());
	}

	@Test
	void checktoStringWithNull() {

		assertEquals(
				"Product [categoryId=null, subCategoryId=null, productId=null, productName=null, productPrice=null, productQuantity=0]",
				productDetail.toString());
	}

	@Test
	void checktoString1() {
		productDetail.setcategoryId("1");
		productDetail.setsubCategoryId("EM");
		productDetail.setproductId("EM1");
		productDetail.setproductName("Redmi Note 8");
		productDetail.setproductPrice(9999.0);
		productDetail.setproductQuantity(75);

		assertEquals(
				"Product [categoryId=1, subCategoryId=EM, productId=EM1, productName=Redmi Note 8, productPrice=9999.0, productQuantity=75]",
				productDetail.toString());
	}

}
