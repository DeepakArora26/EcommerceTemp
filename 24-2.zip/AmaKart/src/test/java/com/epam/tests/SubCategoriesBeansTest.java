package com.epam.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.epam.model.SubCategories;

class SubCategoriesBeansTest {

	SubCategories subcategory;

	@BeforeEach
	void init() {

		subcategory = new SubCategories();

	}

	@Test
	void checkCategoryIdWithNull() {

		assertEquals(null, subcategory.getcategoryId());
	}

	@Test
	void checkCategoryId() {
		subcategory.setcategoryId("1");

		assertEquals("1", subcategory.getcategoryId());
	}

	@Test
	void checkSubCategoryIdWithNull() {

		assertEquals(null, subcategory.getsubCategoryId());
	}

	@Test
	void checkSubCategoryId() {
		subcategory.setsubCategoryId("FW");

		assertEquals("FW", subcategory.getsubCategoryId());
	}

	

	@Test
	void checkSubCategoryNameWithNull() {

		assertEquals(null, subcategory.getsubCategoryName());
	}

	@Test
	void checkSubCategoryName() {
		subcategory.setsubCategoryName("Mobiles");

		assertEquals("Mobiles", subcategory.getsubCategoryName());
	}

	
	@Test
	void checkSubCategoryImageWithNull() {

		assertEquals(null, subcategory.getsubCategoryImage());
	}

	@Test
	void checkSubCategoryImage() {
		subcategory.setsubCategoryImage("Mens.jpg");

		assertEquals("Mens.jpg", subcategory.getsubCategoryImage());
	}
	
	
	
	
	@Test
	void checktoStringWithNull() {

		assertEquals("Sub_Categories [categoryId=null, subCategoryId=null, subCategoryName=null]", subcategory.toString());
	}

	@Test
	void checktoString() {

		subcategory.setcategoryId("2");
		subcategory.setsubCategoryId("FM");
		subcategory.setsubCategoryImage("Mens.jpg");
		subcategory.setsubCategoryName("Men's Fashion");

		assertEquals("Sub_Categories [categoryId=2, subCategoryId=FM, subCategoryName=Men's Fashion]", subcategory.toString());

	}
	
	

}
