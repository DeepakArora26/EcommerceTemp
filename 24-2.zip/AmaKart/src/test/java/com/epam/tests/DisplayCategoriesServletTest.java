package com.epam.tests;

import static org.junit.jupiter.api.Assertions.*;

import javax.servlet.RequestDispatcher;

import org.junit.jupiter.api.Test;
import org.mockito.Mock;

import com.epam.services.ShoppingService;

class DisplayCategoriesServletTest {

	
	

	@Mock
	ShoppingService shopping;
	
	@Mock
	RequestDispatcher rd;

	
	

}
