package com.amakart.modeltest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.amakart.model.SubCategory;

class SubCategoryTest {
	
	SubCategory subCategory;

	@BeforeEach
	void initialize() {
		subCategory = new SubCategory();
	}

	@Test
	void checkCategoryIdWithNull() {

		assertEquals(null, subCategory.getCategoryId());

	}

	@Test
	void checkCategoryIdWithValue() {

		subCategory.setCategoryId("1");
		assertEquals("1", subCategory.getCategoryId());

	}
	
	
	@Test
	void checkSubCategoryIdWithNull() {

		assertEquals(null, subCategory.getSubCategoryId());

	}

	@Test
	void checkSubCategoryIdWithValue() {

		subCategory.setSubCategoryId("EM");
		assertEquals("EM", subCategory.getSubCategoryId());

	}
	
	@Test
	void checkSubCategoryNameWithNull() {

		assertEquals(null, subCategory.getSubCategoryName());

	}

	@Test
	void checkSubCategoryNameWithValue() {

		subCategory.setSubCategoryName("Mobiles");
		assertEquals("Mobiles", subCategory.getSubCategoryName());

	}
	
	
	
	@Test
	void checkSubCategoryImageWithNull() {

		assertEquals(null, subCategory.getSubCategoryImage());

	}

	@Test
	void checkSubCategoryImageWithValue() {

		subCategory.setSubCategoryImage("Mobiles.jpg");
		assertEquals("Mobiles.jpg", subCategory.getSubCategoryImage());

	}
	
	
	
	
	@Test
	void checktoStringWithNull() {

		assertEquals("SubCategory [categoryId=null, subCategoryId=null, subCategoryName=null, subCategoryImage=null]", subCategory.toString());

	}

	@Test
	void checktoStringWithValue() {
		
		subCategory.setCategoryId("1");
		subCategory.setSubCategoryId("EM");
		subCategory.setSubCategoryName("Mobiles");
		subCategory.setSubCategoryImage("Mobiles.jpg");
		assertEquals("SubCategory [categoryId=1, subCategoryId=EM, subCategoryName=Mobiles, subCategoryImage=Mobiles.jpg]", subCategory.toString());

	}
	
}
