package com.amakart.modeltest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.amakart.model.Product;

class ProductTest {

	Product product;

	@BeforeEach
	void initialize() {
		product = new Product();
	}

	@Test
	void checkProductIdWithNull() {

		assertEquals(null, product.getProductId());

	}

	@Test
	void checkProductIdWithValue() {

		product.setProductId("EM1");
		assertEquals("EM1", product.getProductId());

	}

	@Test
	void checkSubCategoryIdWithNull() {

		assertEquals(null, product.getSubCategoryId());

	}

	@Test
	void checkSubCategoryIdWithValue() {

		product.setSubCategoryId("ET");
		assertEquals("ET", product.getSubCategoryId());

	}

	@Test
	void checkProductNameWithNull() {

		assertEquals(null, product.getProductName());

	}

	@Test
	void checkProductNameWithValue() {

		product.setProductName("Realme U1 Ambitious Black");
		assertEquals("Realme U1 Ambitious Black", product.getProductName());

	}

	@Test
	void checkProductMRPWithNull() {

		assertEquals(null, product.getProductMRP());

	}

	@Test
	void checkProductMRPWithValue() {

		product.setProductMRP(15999.0);
		assertEquals(15999.0, product.getProductMRP());

	}

	@Test
	void checkProductDiscountedPriceWithNull() {

		assertEquals(null, product.getProductDiscountedPrice());

	}

	@Test
	void checkProductDiscountedPriceWithValue() {

		product.setProductDiscountedPrice(5999.0);
		assertEquals(5999.0, product.getProductDiscountedPrice());

	}

	@Test
	void checkProductAvailableStockWithNull() {

		assertEquals(0, product.getProductAvailableStock());

	}

	@Test
	void checkProductAvailableStockWithValue() {

		product.setProductAvailableStock(50);
		assertEquals(50, product.getProductAvailableStock());

	}

	@Test
	void checkProductAverageRatingWithNull() {

		assertEquals(null, product.getProductAverageRating());

	}

	@Test
	void checkProductAverageRatingWithValue() {

		product.setProductAverageRating(3.0);
		assertEquals(3.0, product.getProductAverageRating());

	}

	@Test
	void checktoStringWithNull() {

		assertEquals("Product [productId=null, subCategoryId=null, productName=null, productMRP=null, productDiscountedPrice=null, productAvailableStock=0, productAverageRating=null]", product.toString());

	}

	@Test
	void checktoStringWithValue() {
		product.setProductId("EM1");
		product.setSubCategoryId("ET");
		product.setProductName("Realme U1 Ambitious Black");
		product.setProductMRP(15999.0);
		product.setProductDiscountedPrice(5999.0);
		product.setProductAvailableStock(50);
		product.setProductAverageRating(3.0);
		assertEquals("Product [productId=EM1, subCategoryId=ET, productName=Realme U1 Ambitious Black, productMRP=15999.0, productDiscountedPrice=5999.0, productAvailableStock=50, productAverageRating=3.0]", product.toString());

	}

}
