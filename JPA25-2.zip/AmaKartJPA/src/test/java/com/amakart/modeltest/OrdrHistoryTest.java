package com.amakart.modeltest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.amakart.model.OrderHistory;

class OrdrHistoryTest {

	OrderHistory orderDetail;

	@BeforeEach
	void initialize() {
		orderDetail = new OrderHistory();
	}

	@Test
	void checkOrderIdWithNull() {

		assertEquals(null, orderDetail.getOrderId());

	}

	@Test
	void checkOrderIdWithValue() {

		orderDetail.setOrderId("20");
		assertEquals("20", orderDetail.getOrderId());

	}

	@Test
	void checkCustomerIdWithNull() {

		assertEquals(null, orderDetail.getCustomerId());

	}

	@Test
	void checkCustomerIdWithValue() {

		orderDetail.setCustomerId("Deepak26");
		assertEquals("Deepak26", orderDetail.getCustomerId());

	}

	@Test
	void checkCartTotalWithNull() {

		assertEquals(null, orderDetail.getCartTotal());

	}

	@Test
	void checkCartTotalWithValue() {

		orderDetail.setCartTotal(20014.6);
		assertEquals(20014.6, orderDetail.getCartTotal());

	}

	@Test
	void checkOrderDateWithNull() {

		assertEquals(null, orderDetail.getOrderDate());

	}

	@Test
	void checkOrderDateWithValue() {

		orderDetail.setOrderDate("2020-02-25");
		assertEquals("2020-02-25", orderDetail.getOrderDate());

	}

	@Test
	void checkOrderAddressWithNull() {

		assertEquals(null, orderDetail.getOrderAddress());

	}

	@Test
	void checkOrderAddressWithValue() {

		orderDetail.setOrderAddress("Epam Knowledge City");
		assertEquals("Epam Knowledge City", orderDetail.getOrderAddress());

	}

	@Test
	void checktoStringWithNull() {

		assertEquals("OrderHistory [orderId=null, customerId=null, cartTotal=null, orderDate=null, orderAddress=null]", orderDetail.toString());

	}

	@Test
	void checktoStringWithValue() {

		orderDetail.setOrderId("20");
		orderDetail.setCustomerId("Deepak26");
		orderDetail.setCartTotal(20014.6);
		orderDetail.setOrderDate("2020-02-25");
		orderDetail.setOrderAddress("Epam Knowledge City");
		assertEquals("OrderHistory [orderId=20, customerId=Deepak26, cartTotal=20014.6, orderDate=2020-02-25, orderAddress=Epam Knowledge City]", orderDetail.toString());

	}

}
