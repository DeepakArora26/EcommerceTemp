package com.amakart.modeltest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.amakart.model.CartProduct;

class CartProductTest {

	CartProduct cartProduct;

	@BeforeEach
	void initialize() {
		cartProduct = new CartProduct();
	}

	@Test
	void checkProductIdWithNull() {

		assertEquals(null, cartProduct.getProductId());

	}

	@Test
	void checkProductIdWithValue() {

		cartProduct.setProductId("EM1");
		assertEquals("EM1", cartProduct.getProductId());

	}

	@Test
	void checkProductNameWithNull() {

		assertEquals(null, cartProduct.getProductName());

	}

	@Test
	void checkProductNameWithValue() {

		cartProduct.setProductName("Redmi Note 8");
		assertEquals("Redmi Note 8", cartProduct.getProductName());

	}

	@Test
	void checkProductPriceWithNull() {

		assertEquals(null, cartProduct.getProductPrice());

	}

	@Test
	void checkProductPriceWithValue() {

		cartProduct.setProductPrice(9999.0);
		assertEquals(9999.0, cartProduct.getProductPrice());

	}

	@Test
	void checkProductPurchasedQuantityWithNull() {

		assertEquals(0.0, cartProduct.getProductPurchasedQuantity());

	}

	@Test
	void checkProductPurchasedQuantityWithValue() {

		cartProduct.setProductPurchasedQuantity(10);
		assertEquals(10, cartProduct.getProductPurchasedQuantity());

	}

	@Test
	void checkProductImageWithNull() {

		assertEquals(null, cartProduct.getProductImage());

	}

	@Test
	void checkProductImageWithValue() {

		cartProduct.setProductImage("Note8.jpg");
		assertEquals("Note8.jpg", cartProduct.getProductImage());

	}

	@Test
	void checkProductTotalPriceWithNull() {

		assertEquals(null, cartProduct.getProductTotalPrice());

	}

	@Test
	void checkProductTotalPriceWithValue() {

		cartProduct.setProductTotalPrice(18999.20);
		assertEquals(18999.20, cartProduct.getProductTotalPrice());

	}

	@Test
	void checktoStringWithNull() {

		assertEquals(
				"CartProduct [productId=null, productName=null, productPrice=null, productPurchasedQuantity=0, productImage=null, productTotalPrice=null]",
				cartProduct.toString());

	}

	@Test
	void checktoStringWithValue() {
		cartProduct.setProductId("EM1");
		cartProduct.setProductName("Redmi Note 8");
		cartProduct.setProductPrice(9999.0);
		cartProduct.setProductPurchasedQuantity(10);
		cartProduct.setProductImage("Note8.jpg");
		cartProduct.setProductTotalPrice(18999.20);
		assertEquals(
				"CartProduct [productId=EM1, productName=Redmi Note 8, productPrice=9999.0, productPurchasedQuantity=10, productImage=Note8.jpg, productTotalPrice=18999.2]",
				cartProduct.toString());

	}

}
