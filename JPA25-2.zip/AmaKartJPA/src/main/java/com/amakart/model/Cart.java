package com.amakart.model;

import java.util.List;

public class Cart {

	private List<CartProduct> cartItems;
	private Double cartTotal;

	public List<CartProduct> getCartItems() {
		return cartItems;
	}

	public void setCartItems(List<CartProduct> cartItems) {
		this.cartItems = cartItems;
	}

	public Double getCartTotal() {
		return cartTotal;
	}

	public void setCartTotal(Double cartTotal) {
		this.cartTotal = cartTotal;
	}

	@Override
	public String toString() {
		return "Cart [cartItems=" + cartItems + ", cartTotal=" + cartTotal + "]";
	}

}
