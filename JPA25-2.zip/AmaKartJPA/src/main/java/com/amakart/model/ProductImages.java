package com.amakart.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class ProductImages {

	
	
	@Id
	String productId;
	String productImage;

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getProductImage() {
		return productImage;
	}

	public void setProductImage(String productImage) {
		this.productImage = productImage;
	}

	@Override
	public String toString() {
		return "ProductImages [productId=" + productId + ", productImage=" + productImage + "]";
	}
	
	
	
	

}
