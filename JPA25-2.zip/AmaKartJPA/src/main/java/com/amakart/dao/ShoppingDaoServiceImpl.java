package com.amakart.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.amakart.model.Category;

public class ShoppingDaoServiceImpl implements ShoppingDaoService {
	
	
	
	EntityManagerFactory emFactory = Persistence.createEntityManagerFactory("my-local-mysql");
	
	
	 EntityManager eManager;
	

	@Override
	public List<Category> getCategories() {
		
	 eManager = emFactory.createEntityManager();

	 eManager.
	 
	}

}
