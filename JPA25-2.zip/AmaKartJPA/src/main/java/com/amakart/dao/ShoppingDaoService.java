package com.amakart.dao;

import java.sql.SQLException;
import java.util.List;

import com.amakart.model.Category;


public interface ShoppingDaoService {

	
	
	List<Category> getCategories();

	
	
}
