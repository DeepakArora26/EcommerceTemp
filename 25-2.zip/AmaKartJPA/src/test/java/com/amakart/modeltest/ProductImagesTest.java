package com.amakart.modeltest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.amakart.model.ProductImages;

class ProductImagesTest {

	
	ProductImages productImages;
	
	@BeforeEach
	void initialize()
	{
		productImages = new ProductImages();
	}
	
	
	
	
	@Test
	void checkProductIdWithNull()
	{
		
		assertEquals(null, productImages.getProductId());
		
	}
	
	
	@Test
	void checkProductIdWithValue()
	{
		
		productImages.setProductId("EM1");
		assertEquals("EM1", productImages.getProductId());
		
	}
	
	
	
	
	@Test
	void checkproductImageWithNull()
	{
		
		assertEquals(null, productImages.getProductImage());
		
	}
	
	
	@Test
	void checkproductImageWithValue()
	{
		
		productImages.setProductImage("RedmiNote8.jpg");
		assertEquals("RedmiNote8.jpg", productImages.getProductImage());
		
	}
	
	
	
}
