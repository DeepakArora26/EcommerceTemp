package com.amakart.modeltest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.amakart.model.Product;

class ProductTest {


	Product product;
	
	@BeforeEach
	void initialize()
	{
		product = new Product();
	}
	
	
	
	@Test
	void checkProductIdWithNull()
	{
		
		assertEquals(null, productImages.getProductId());
		
	}
	
	
	@Test
	void checkProductIdWithValue()
	{
		
		productImages.setProductId("EM1");
		assertEquals("EM1", productImages.getProductId());
		
	}
	
	
	
	

}
