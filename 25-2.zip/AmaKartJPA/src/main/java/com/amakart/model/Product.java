package com.amakart.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Product {
	
	
	@Id
	String productId;
	String categoryId;
	String subCategoryId;
	String productName;
	String productShortDescription;
	String productSize;
	String productColor;
	String productLongDescription;
	int productMrp;
	int productDiscountedPrice;
	int productStock;
	int productCustomerRating;
	Double productWeight;
	@OneToMany(targetEntity=ProductImages.class)  
	ProductImages productImages;
	
	
	
	
	
	
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}
	public String getSubCategoryId() {
		return subCategoryId;
	}
	public void setSubCategoryId(String subCategoryId) {
		this.subCategoryId = subCategoryId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductShortDescription() {
		return productShortDescription;
	}
	public void setProductShortDescription(String productShortDescription) {
		this.productShortDescription = productShortDescription;
	}
	public String getProductSize() {
		return productSize;
	}
	public void setProductSize(String productSize) {
		this.productSize = productSize;
	}
	public String getProductColor() {
		return productColor;
	}
	public void setProductColor(String productColor) {
		this.productColor = productColor;
	}
	public String getProductLongDescription() {
		return productLongDescription;
	}
	public void setProductLongDescription(String productLongDescription) {
		this.productLongDescription = productLongDescription;
	}
	public int getProductMrp() {
		return productMrp;
	}
	public void setProductMrp(int productMrp) {
		this.productMrp = productMrp;
	}
	public int getProductDiscountedPrice() {
		return productDiscountedPrice;
	}
	public void setProductDiscountedPrice(int productDiscountedPrice) {
		this.productDiscountedPrice = productDiscountedPrice;
	}
	public int getProductStock() {
		return productStock;
	}
	public void setProductStock(int productStock) {
		this.productStock = productStock;
	}
	public int getProductCustomerRating() {
		return productCustomerRating;
	}
	public void setProductCustomerRating(int productCustomerRating) {
		this.productCustomerRating = productCustomerRating;
	}
	public Double getProductWeight() {
		return productWeight;
	}
	public void setProductWeight(Double productWeight) {
		this.productWeight = productWeight;
	}
	public ProductImages getProductImages() {
		return productImages;
	}
	public void setProductImages(ProductImages productImages) {
		this.productImages = productImages;
	}
	@Override
	public String toString() {
		return "UpdatedProduct [productId=" + productId + ", categoryId=" + categoryId + ", subCategoryId="
				+ subCategoryId + ", productName=" + productName + ", productShortDescription="
				+ productShortDescription + ", productSize=" + productSize + ", productColor=" + productColor
				+ ", productLongDescription=" + productLongDescription + ", productMrp=" + productMrp
				+ ", productDiscountedPrice=" + productDiscountedPrice + ", productStock=" + productStock
				+ ", productCustomerRating=" + productCustomerRating + ", productWeight=" + productWeight
				+ ", productImages=" + productImages + "]";
	}

	
	
	
	
	
	
	
	
	

}
