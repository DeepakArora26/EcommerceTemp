package com.example.servies;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.model.Category;
import com.example.model.Product;
import com.example.repo.crudrepo;
import com.example.repo.prodrepo;

@Service
public class ShoppingServiceImpl implements ShoppingService {

	@Autowired
	crudrepo catg;

	@Autowired
	prodrepo product;

	@Override
	public List<Category> getCategories(int parentId) {
		return catg.findByparentId(parentId);
	}

	@Override
	public List<Product> getProducts(int subCategoryId) {
		return product.findBySubCategoryId(subCategoryId);
	}

	@Override
	public Product getProductDetail(String productId) {
		return product.findByProductId(productId);
	}

}
