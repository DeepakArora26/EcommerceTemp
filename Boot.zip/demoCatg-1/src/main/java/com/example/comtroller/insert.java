package com.example.comtroller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.model.Category;
import com.example.model.Product;
import com.example.model.ProductAttribute;
import com.example.repo.crudrepo;
import com.example.repo.prodrepo;

@Controller
public class insert {

	@Autowired
	Category c;

	@Autowired
	crudrepo repo;

	@Autowired
	Product p;

	@Autowired
	prodrepo prod;

	@RequestMapping("ad")
	public String data() {

		/*
		 * c = new Category("Electronics", 0, "Electronics.jpg"); repo.save(c);
		 * 
		 * c = new Category("Men's Fashion", 0, "MensFashion.jpg"); repo.save(c);
		 * 
		 * c = new Category("Sports", 0, "Sports.jpg"); repo.save(c);
		 * 
		 * c = new Category("Mobiles", 1, "Mobiles.jpg"); repo.save(c);
		 * 
		 * c = new Category("TV", 1, "TV.jpg"); repo.save(c);
		 * 
		 * c = new Category("Shirts", 2, "Shrits.jpg"); repo.save(c);
		 * 
		 * c = new Category("Watches", 2, "Watches.jpg"); repo.save(c);
		 * 
		 * c = new Category("Badmintion", 3, "Badmintion.jpg"); repo.save(c);
		 * 
		 * c = new Category("Cricket", 3, "Cricket.jpg"); repo.save(c);
		 * 
		 * p = new Product("M1", 4, "Redmi Note 8", 12999.00, 9999.00, 50, 4.5,
		 * "RedmiNote8.jpg");
		 * 
		 * p.addAttribute(new ProductAttribute("Battery Capacity", "4000 mAH"));
		 * 
		 * p.addAttribute(new ProductAttribute("ROM Size", "64 GB"));
		 * 
		 * p.addAttribute(new ProductAttribute("Ram Size", "4 GB"));
		 * 
		 * p.addAttribute(new ProductAttribute("Screen Size", "6.4 Inch"));
		 * 
		 * p.addAttribute(new ProductAttribute("Processor",
		 * "2.0GHz Qualcomm Snapdragon 665 octa core processor"));
		 * 
		 * p.addImage("RedmiNote8.jpg"); p.addImage("RedmiNote81.jpg");
		 * p.addImage("RedmiNote82.jpg");
		 * 
		 * prod.save(p);
		 * 
		 * p = new Product("M2", 4, "Realme U1 Ambitious Black", 9999.00, 7999.00, 24,
		 * 4.0, "RealmeU1.jpg");
		 * 
		 * p.addAttribute(new ProductAttribute("Battery Capacity", "3500 mAH"));
		 * 
		 * p.addAttribute(new ProductAttribute("ROM Size", "32 GB"));
		 * 
		 * p.addAttribute(new ProductAttribute("Ram Size", "3 GB"));
		 * 
		 * p.addAttribute(new ProductAttribute("Screen Size", "6.3 Inch"));
		 * 
		 * p.addAttribute(new ProductAttribute("Processor",
		 * "2.1GHz MediaTek Helio P70 octa core processor"));
		 * 
		 * p.addImage("RealmeU1.jpg"); p.addImage("RealmeU12.jpg");
		 * p.addImage("RealmeU13.jpg");
		 * 
		 * prod.save(p);
		 * 
		 * 
		 * 
		 * 
		 * 
		 * p = new Product("M3", 4, "Vivo U20 Blazing Blue", 11499.00, 9990.00, 124,
		 * 4.5, "VivoU20.jpg");
		 * 
		 * p.addAttribute(new ProductAttribute("Battery Capacity", "5000 mAH"));
		 * 
		 * p.addAttribute(new ProductAttribute("ROM Size", "64 GB"));
		 * 
		 * p.addAttribute(new ProductAttribute("Ram Size", "4 GB"));
		 * 
		 * p.addAttribute(new ProductAttribute("Screen Size", "6.53 Inch"));
		 * 
		 * p.addAttribute(new ProductAttribute("Processor",
		 * "Qualcomm Snapdragon 675 AIE octa core processor"));
		 * 
		 * p.addImage("VivoU20.jpg"); p.addImage("VivoU202.jpg");
		 * p.addImage("VivoU203.jpg"); p.addImage("VivoU204.jpg");
		 * 
		 * prod.save(p);
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * p = new Product("T1", 5, "OnePlus 55 Inch 4K TV", 74999.00, 69899.00, 14,
		 * 4.0, "OnePlusQ1.jpg");
		 * 
		 * p.addAttribute(new ProductAttribute("No Of HDMI Ports", "4"));
		 * 
		 * p.addAttribute(new ProductAttribute("No Of USB Ports", "4"));
		 * 
		 * p.addAttribute(new ProductAttribute("Refresh Rate",
		 * "Motion Rate 480 Hertz"));
		 * 
		 * p.addAttribute(new ProductAttribute("Resolution",
		 * "4K Ultra HD (3840x2160)"));
		 * 
		 * p.addAttribute(new ProductAttribute("Screen Size", "55 Inch"));
		 * 
		 * p.addImage("OnePlusQ1.jpg"); p.addImage("OnePlusQ12.jpg");
		 * p.addImage("OnePlusQ13.jpg"); p.addImage("OnePlusQ14.jpg");
		 * 
		 * prod.save(p);
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * p = new Product("T2", 5, "Mi LED TV 4C PRO 80 cm", 21999.00, 15499.00, 41,
		 * 3.0, "Mi4cPro.jpg");
		 * 
		 * p.addAttribute(new ProductAttribute("No Of HDMI Ports", "3"));
		 * 
		 * p.addAttribute(new ProductAttribute("No Of USB Ports", "3"));
		 * 
		 * p.addAttribute(new ProductAttribute("Refresh Rate", "60 hertz"));
		 * 
		 * p.addAttribute(new ProductAttribute("Resolution", "Full HD (1920x1080)"));
		 * 
		 * p.addAttribute(new ProductAttribute("Screen Size", "43 Inch"));
		 * 
		 * p.addImage("Mi4cPro.jpg"); p.addImage("Mi4cPro2.jpg");
		 * p.addImage("Mi4cPro3.jpg"); p.addImage("Mi4cPro4.jpg");
		 * 
		 * prod.save(p);
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * p = new Product("T3", 5, "Vu 80 cm UltraAndroid LED TV 32GA", 13799.00,
		 * 10999.00, 80, 4.0, "Vu32GA.jpg");
		 * 
		 * p.addAttribute(new ProductAttribute("No Of HDMI Ports", "2"));
		 * 
		 * p.addAttribute(new ProductAttribute("No Of USB Ports", "2"));
		 * 
		 * p.addAttribute(new ProductAttribute("Refresh Rate", "60 hertz"));
		 * 
		 * p.addAttribute(new ProductAttribute("Resolution", "HD Ready (1366x768)"));
		 * 
		 * p.addAttribute(new ProductAttribute("Screen Size", "32 Inch"));
		 * 
		 * p.addImage("Vu32GA.jpg"); p.addImage("Vu32GA2.jpg");
		 * p.addImage("Vu32GA3.jpg"); p.addImage("Vu32GA4.jpg");
		 * 
		 * prod.save(p);
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * p = new Product("MS1", 6, "Jack & Jones Men's Printed Slim Fit Formal Shirt",
		 * 3999.00, 1599.00, 200, 3.2, "Jack&JonesB1.jpg");
		 * 
		 * p.addAttribute(new ProductAttribute("Color Name", "Light Grey Melange"));
		 * 
		 * p.addAttribute(new ProductAttribute("Fit Type", "Slim Fit"));
		 * 
		 * p.addAttribute(new ProductAttribute("Material", "Cotton"));
		 * 
		 * p.addAttribute(new ProductAttribute("Pattern", "Printed"));
		 * 
		 * p.addImage("Jack&JonesB1.jpg"); p.addImage("Jack&JonesB12.jpg");
		 * p.addImage("Jack&JonesB13.jpg"); p.addImage("Jack&JonesB14.jpg");
		 * 
		 * prod.save(p);
		 * 
		 * 
		 * 
		 * 
		 * p = new Product("W1", 7, "Fastrack Casual Analog Black Dial Men's Watch",
		 * 2100.00, 1399.00, 110, 4.1, "FastrackNL1.jpg");
		 * 
		 * p.addAttribute(new ProductAttribute("Band Color", "Silver"));
		 * 
		 * p.addAttribute(new ProductAttribute("Case Material", "Metal"));
		 * 
		 * p.addAttribute(new ProductAttribute("Dial Color", "Black"));
		 * 
		 * p.addAttribute(new ProductAttribute("Water Resistance Depth", "50 meters"));
		 * 
		 * p.addImage("FastrackNL1.jpg"); p.addImage("FastrackNL12.jpg");
		 * p.addImage("FastrackNL13.jpg"); p.addImage("FastrackNL14.jpg");
		 * 
		 * prod.save(p);
		 * 
		 * 
		 * 
		 * 
		 * 
		 * p = new Product("W2", 7, "Fastrack Essentials Analog Grey Dial Men's Watch",
		 * 1950.00, 1650.00, 78, 4.3, "FastrackNK1.jpg");
		 * 
		 * p.addAttribute(new ProductAttribute("Band Color", "Black"));
		 * 
		 * p.addAttribute(new ProductAttribute("Case Material", "Aluminuim"));
		 * 
		 * p.addAttribute(new ProductAttribute("Dial Color", "Grey"));
		 * 
		 * p.addAttribute(new ProductAttribute("Water Resistance Depth", "50 meters"));
		 * 
		 * p.addImage("FastrackNK1.jpg"); p.addImage("FastrackNK12.jpg");
		 * p.addImage("FastrackNk13.jpg"); p.addImage("FastrackNK14.jpg");
		 * 
		 * prod.save(p);
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * p = new Product("W3", 7,
		 * "Fastrack Black Magic Analog Black Dial Men's Watch", 4359.00, 3495.00, 56,
		 * 4.7, "FastrackBM1.jpg");
		 * 
		 * p.addAttribute(new ProductAttribute("Band Color", "Black"));
		 * 
		 * p.addAttribute(new ProductAttribute("Case Material", "Aluminuim"));
		 * 
		 * p.addAttribute(new ProductAttribute("Dial Color", "Grey"));
		 * 
		 * p.addAttribute(new ProductAttribute("Water Resistance Depth", "50 meters"));
		 * 
		 * p.addImage("FastrackBM1.jpg"); p.addImage("FastrackBM12.jpg");
		 * p.addImage("FastrackBM13.jpg"); p.addImage("FastrackBM14.jpg");
		 * 
		 * prod.save(p);
		 * 
		 * 
		 */		
		
		
		
		
		// p = prod.findByProductId("M1");

//		 System.out.println(repo.findByparentId(0));

		// System.out.println(prod.findBySubCategoryId(4));
		return "Home.jsp";

	}

}
