package com.example.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.model.ProductAttribute;

public interface atrepo extends JpaRepository<ProductAttribute, Integer> {

}
