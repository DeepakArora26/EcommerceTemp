package com.amakart.model;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class Cart {

	
	public static List<CartProduct> cartItems = new ArrayList<>();

	public static Double cartTotal;

	public List<CartProduct> getCartItems() {
		return cartItems;
	}

	public Double getCartTotal() {
		return cartTotal;
	}

	public void setCartTotal(Double cartTotal) {
		Cart.cartTotal = cartTotal;
	}

	@Override
	public String toString() {
		return "Cart [cartItems=" + cartItems + ", cartTotal=" + cartTotal + "]";
	}

}
