package com.amakart.service;

import java.util.List;

import com.amakart.model.Category;
import com.amakart.model.Product;

public interface ShoppingService {

	List<Category> getCategories(int parentId);

	List<Product> getProducts(int subCategoryId);

	Product getProductDetail(String productId);

	Category getFirstPromoted();

	Category getSecondPromoted();
	
	boolean checkOut();

}
