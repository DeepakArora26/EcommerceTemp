package com.amakart.service;

public interface CartService {
	
	
	

	boolean addToCart(String productId,int productQuantity);
	
	boolean checkProductQuantity(String productId,int productQuantity);
	
	void calculateCartTotal();

	int productExistInCart(String productId);
	
	boolean checkout();
	
	
}
