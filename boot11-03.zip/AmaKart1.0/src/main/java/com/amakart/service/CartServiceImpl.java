package com.amakart.service;

import java.util.Iterator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.amakart.model.Cart;
import com.amakart.model.CartProduct;
import com.amakart.model.Product;
import com.amakart.repository.ProductRepository;

@Service
public class CartServiceImpl implements CartService {

	@Autowired
	CartProduct productInCart;

	@Autowired
	ProductRepository productRepository;

	@Autowired
	Product product;

	@Autowired
	Cart cart;
	
	
	

	@Override
	public boolean addToCart(String productId, int productQuantity) {

		boolean flag = false;

		productInCart = new CartProduct();

		productQuantity += productExistInCart(productId);

		if (checkProductQuantity(productId, productQuantity)) {

			product = productRepository.findByProductId(productId);

			productInCart.setProductId(product.getProductId());
			productInCart.setProductImage(product.getThumbnail());
			productInCart.setProductName(product.getProductName());
			productInCart.setProductPrice(product.getProductDiscountedPrice());

			productInCart.setProductPurchasedQuantity(productQuantity);

			productInCart.setProductTotalPrice();

			Cart.cartItems.add(productInCart);

			flag = true;

		}

		calculateCartTotal();
		return flag;

	}

	@Override
	public void calculateCartTotal() {

		Double cartTotal = 0.0;

		for (CartProduct currentProduct : Cart.cartItems) {
			cartTotal = cartTotal + currentProduct.getProductTotalPrice();
		}

		Cart.cartTotal = cartTotal;

	}

	@Override
	public boolean checkProductQuantity(String productId, int productQuantity) {

		return (productRepository.findByProductId(productId).getProductAvailableStock() >= productQuantity);

	}

	@Override
	public int productExistInCart(String productId) {

		int count = 0;

		Iterator<CartProduct> i = Cart.cartItems.iterator();

		while (i.hasNext()) {

			CartProduct cartProduct = i.next();

			if (cartProduct.getProductId().equals(productId)) {

				count = cartProduct.getProductPurchasedQuantity();

				i.remove();

			}

		}

		return count;

	}

	
	
	
	@Override
	public boolean checkout() {
		return false;
	}

}
