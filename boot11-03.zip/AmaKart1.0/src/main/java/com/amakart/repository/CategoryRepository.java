package com.amakart.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.amakart.model.Category;

public interface CategoryRepository extends JpaRepository<Category, Integer> {

	List<Category> findByparentId(int parendId);
	
	List<Category> findById(int id);

	@Query(value = " SELECT * FROM category where promoted=1 LIMIT 1 offset 0", nativeQuery = true)
	Category findFirstPromotedCategory();

	@Query(value = " SELECT * FROM category where promoted=1 LIMIT 1 offset 1", nativeQuery = true)
	Category findSecondPromotedCategory();

}
