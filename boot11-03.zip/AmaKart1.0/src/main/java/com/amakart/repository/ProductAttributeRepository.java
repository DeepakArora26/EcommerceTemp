package com.amakart.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.amakart.model.Product;
import com.amakart.model.ProductAttribute;

public interface ProductAttributeRepository extends JpaRepository<ProductAttribute, Integer> {
	
	
	

}
