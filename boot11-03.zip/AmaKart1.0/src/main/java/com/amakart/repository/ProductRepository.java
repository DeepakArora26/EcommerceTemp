package com.amakart.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.amakart.model.Category;
import com.amakart.model.Product;

public interface ProductRepository extends JpaRepository<Product, String> {

	Product findByProductId(String productId);


}
