package com.amakart.modeltest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.amakart.model.ProductImages;

class ProductImagesTest {

	
	ProductImages productImages;
	
	@BeforeEach
	void initialize()
	{
		productImages = new ProductImages();
	}
	
	
	
	
	@Test
	void checkProductIdWithNull()
	{
		
		assertEquals(null, productImages.getProductId());
		
	}
	
	
	@Test
	void checkProductIdWithValue()
	{
		
		productImages.setProductId("EM1");
		assertEquals("EM1", productImages.getProductId());
		
	}
	
	
	
	
	@Test
	void checkProductImageWithNull()
	{
		
		assertEquals(null, productImages.getProductImage());
		
	}
	
	
	@Test
	void checkProductImageWithValue()
	{
		
		productImages.setProductImage("RedmiNote8.jpg");
		assertEquals("RedmiNote8.jpg", productImages.getProductImage());
		
	}
	
	
	
	@Test
	void checktoStringWithNull()
	{
		
		assertEquals("ProductImages [productId=null, productImage=null]", productImages.toString());
		
	}
	
	
	@Test
	void checktoStringWithValue()
	{
		productImages.setProductId("EM1");
		productImages.setProductImage("RedmiNote8.jpg");
		assertEquals("ProductImages [productId=EM1, productImage=RedmiNote8.jpg]", productImages.toString());
		
	}
	
	
	
}
