/*
 * package com.amakart.services;
 * 
 * import java.sql.ResultSet; import java.sql.SQLException; import
 * java.util.ArrayList; import java.util.List; import java.util.Scanner;
 * 
 * import com.epam.dao.ShoppingDaoService; import
 * com.epam.dao.ShoppingDaoServiceImpl; import com.epam.model.Categories; import
 * com.epam.model.Product; import com.epam.model.SubCategories;
 * 
 * public class ShoppingServiceImpl implements ShoppingService {
 * 
 * ShoppingDaoService shopping = new ShoppingDaoServiceImpl();
 * 
 * static Scanner input = new Scanner(System.in); String userSelection; static
 * final String WARNING =
 * "Wrong Selection. Please Select from the above Options only"; ResultSet rs;
 * Categories categoryDetail; SubCategories subCategoryDetail; Product
 * productDetail;
 * 
 * @Override public List<Categories> getCategoriesList() {
 * 
 * List<Categories> categoriesList = new ArrayList<>();
 * 
 * try { categoriesList = shopping.getCategories(); } catch (SQLException e) {
 * e.printStackTrace(); }
 * 
 * System.out.println(categoriesList);
 * 
 * return categoriesList;
 * 
 * }
 * 
 * @Override public List<SubCategories> getSubCategoriesList(String categoryId)
 * {
 * 
 * List<SubCategories> subCategoryList = new ArrayList<>();
 * 
 * try {
 * 
 * rs = shopping.getSubCategories(categoryId);
 * 
 * while (rs.next()) {
 * 
 * subCategoryDetail = new SubCategories();
 * subCategoryDetail.setcategoryId(rs.getString(1));
 * subCategoryDetail.setsubCategoryId(rs.getString(2));
 * subCategoryDetail.setsubCategoryName(rs.getString(3));
 * subCategoryDetail.setsubCategoryImage(rs.getString(4));
 * 
 * subCategoryList.add(subCategoryDetail);
 * 
 * }
 * 
 * } catch (SQLException e) { e.printStackTrace(); }
 * 
 * return subCategoryList; }
 * 
 * @Override public List<Product> getProductsList(String subCategoryId) {
 * 
 * List<Product> productList = new ArrayList<>();
 * 
 * try {
 * 
 * rs = shopping.getProducts(subCategoryId);
 * 
 * while (rs.next()) {
 * 
 * productDetail = new Product(); productDetail.setcategoryId(rs.getString(1));
 * productDetail.setsubCategoryId(rs.getString(2));
 * productDetail.setproductId(rs.getString(3));
 * productDetail.setproductName(rs.getString(4));
 * productDetail.setproductPrice(rs.getDouble(5));
 * productDetail.setproductQuantity(rs.getInt(6));
 * productDetail.setproductImage(rs.getString(7));
 * 
 * productList.add(productDetail);
 * 
 * }
 * 
 * } catch (SQLException e) { e.printStackTrace(); }
 * 
 * return productList; }
 * 
 * @Override public Product getproductDetails(String productId) {
 * 
 * productDetail = new Product();
 * 
 * try {
 * 
 * rs = shopping.getProductDetails(productId);
 * 
 * while (rs.next()) {
 * 
 * productDetail = new Product(); productDetail.setcategoryId(rs.getString(1));
 * productDetail.setsubCategoryId(rs.getString(2));
 * productDetail.setproductId(rs.getString(3));
 * productDetail.setproductName(rs.getString(4));
 * productDetail.setproductPrice(rs.getDouble(5));
 * productDetail.setproductQuantity(rs.getInt(6));
 * productDetail.setproductImage(rs.getString(7));
 * 
 * }
 * 
 * } catch (SQLException e) { e.printStackTrace(); }
 * 
 * return productDetail; }
 * 
 * }
 */