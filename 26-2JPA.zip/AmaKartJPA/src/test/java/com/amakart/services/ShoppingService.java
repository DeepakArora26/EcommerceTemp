/*
 * package com.amakart.services;
 * 
 * import java.util.List;
 * 
 * import com.amakart.model.Category;
 * 
 * public interface ShoppingService {
 * 
 * 
 * List<Category> getCategoriesList();
 * 
 * List<SubCategories> getSubCategoriesList(String categoryId);
 * 
 * List<Product> getProductsList(String subCategoryId);
 * 
 * Product getproductDetails(String productId);
 * 
 * 
 * 
 * 
 * }
 */