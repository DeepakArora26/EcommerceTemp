package com.amakart.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.amakart.services.ShoppingService;
import com.amakart.services.ShoppingServiceImpl;






@WebServlet(urlPatterns ="/index")
public class DisplayCategories extends HttpServlet {
	private static final long serialVersionUID = 1L;

	static ShoppingService shopping;
	static RequestDispatcher requestDispatcher;

	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		shopping = new ShoppingServiceImpl();

		request.setAttribute("categoriesList", shopping.getCategoriesList());

		requestDispatcher = request.getRequestDispatcher("jsp/Home.jsp");

		requestDispatcher.forward(request, response);

	}

}
