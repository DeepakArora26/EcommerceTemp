package com.amakart.services;

import java.util.List;

import com.amakart.model.Category;
import com.amakart.model.Product;
import com.amakart.model.ProductImages;
import com.amakart.model.SubCategory;

public interface ShoppingService {

	List<Category> getCategoriesList();

	List<SubCategory> getSubCategoriesList(String categoryId);

	List<Product> getProductsList(String subCategoryId);

	Product getProductDetails(String productId);

	List<ProductImages> getProductsImagesList(String productId);

}
