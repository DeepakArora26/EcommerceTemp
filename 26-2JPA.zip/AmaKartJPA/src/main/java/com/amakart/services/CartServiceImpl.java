package com.amakart.services;

import com.amakart.model.Cart;
import com.amakart.model.CartProduct;
import com.amakart.model.Product;

public class CartServiceImpl implements CartService {

	
	CartProduct productInCart;
	ShoppingService shopping;
	Product product;
	
	
	
	
	
	@Override
	public void addToCart(String productId, int productQuantity) {


		shopping = new ShoppingServiceImpl();
		
		product = new Product();
		
		product = shopping.getProductDetails(productId);
		
		productInCart.setProductId(product.getProductId());
		productInCart.setProductImage(product.getThumbNail());
		productInCart.setProductName(product.getProductName());
		productInCart.setProductPrice(product.getProductDiscountedPrice());
		productInCart.setProductPurchasedQuantity(productQuantity);
		productInCart.setProductTotalPrice();
		
		
		Cart.cartItems.add(productInCart);
		
		System.out.println(product);
		
		
	}

}
