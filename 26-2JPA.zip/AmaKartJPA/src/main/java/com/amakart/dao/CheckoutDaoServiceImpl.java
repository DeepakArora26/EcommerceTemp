package com.amakart.dao;

public class CheckoutDaoServiceImpl implements CheckoutDaoService {

}
