package com.amakart.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;

@Entity
@NamedQuery(query = "Select e from SubCategory e where e.categoryId = :categoryId", name = "find employee by categoryId")
public class SubCategory {
	
	
	
	private String categoryId;
	@Id
	private String subCategoryId;
	private String subCategoryName;
	private String subCategoryImage;
	
	
	
	public String getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}
	public String getSubCategoryId() {
		return subCategoryId;
	}
	public void setSubCategoryId(String subCategoryId) {
		this.subCategoryId = subCategoryId;
	}
	public String getSubCategoryName() {
		return subCategoryName;
	}
	public void setSubCategoryName(String subCategoryName) {
		this.subCategoryName = subCategoryName;
	}
	public String getSubCategoryImage() {
		return subCategoryImage;
	}
	public void setSubCategoryImage(String subCategoryImage) {
		this.subCategoryImage = subCategoryImage;
	}
	
	
	
	@Override
	public String toString() {
		return "SubCategory [categoryId=" + categoryId + ", subCategoryId=" + subCategoryId + ", subCategoryName="
				+ subCategoryName + ", subCategoryImage=" + subCategoryImage + "]";
	}

}
