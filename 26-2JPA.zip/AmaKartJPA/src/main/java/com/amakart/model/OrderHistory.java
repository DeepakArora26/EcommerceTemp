package com.amakart.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class OrderHistory {
	
	
	@Id
	private String orderId;
	private String customerId;
	private Double cartTotal;
	private String orderDate;
	private String orderAddress;
	
	
	
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public Double getCartTotal() {
		return cartTotal;
	}
	public void setCartTotal(Double cartTotal) {
		this.cartTotal = cartTotal;
	}
	public String getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}
	public String getOrderAddress() {
		return orderAddress;
	}
	public void setOrderAddress(String orderAddress) {
		this.orderAddress = orderAddress;
	}
	
	@Override
	public String toString() {
		return "OrderHistory [orderId=" + orderId + ", customerId=" + customerId + ", cartTotal=" + cartTotal
				+ ", orderDate=" + orderDate + ", orderAddress=" + orderAddress + "]";
	}

}
