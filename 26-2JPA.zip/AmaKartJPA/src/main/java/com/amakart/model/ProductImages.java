package com.amakart.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;

@Entity
@NamedQuery(query = "Select e from ProductImages e where e.productId = :productId", name = "find employee by productId")
public class ProductImages {

	
	@Id
	private String imageId;
	private String productId;
	private String productImage;
	

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getProductImage() {
		return productImage;
	}

	public void setProductImage(String productImage) {
		this.productImage = productImage;
	}
	
	

	public String getImageId() {
		return imageId;
	}

	public void setImageId(String imageId) {
		this.imageId = imageId;
	}

	@Override
	public String toString() {
		return "ProductImages [imageId=" + imageId + ", productId=" + productId + ", productImage=" + productImage
				+ "]";
	}

	
	
	

}
