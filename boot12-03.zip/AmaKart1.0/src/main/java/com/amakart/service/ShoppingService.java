package com.amakart.service;

import java.util.List;

import com.amakart.exception.CategoriesNotFoundException;
import com.amakart.exception.FirstPromotedCategoryNotFoundException;
import com.amakart.exception.SecondPromotedCategoryNotFoundException;
import com.amakart.model.Category;
import com.amakart.model.Product;

public interface ShoppingService {

	List<Category> getCategories(int parentId) throws CategoriesNotFoundException;

	List<Product> getProducts(int subCategoryId);

	Product getProductDetail(String productId);

	Category getFirstPromoted() throws FirstPromotedCategoryNotFoundException;

	Category getSecondPromoted() throws SecondPromotedCategoryNotFoundException;

}
