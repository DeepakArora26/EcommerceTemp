package com.amakart.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import org.springframework.stereotype.Component;

@Component

public class Cart {

	
	private static List<CartProduct> cartItems = new ArrayList<>();
	private static Double cartTotal;

	/*
	 * @OneToOne private User user;
	 */
	
	
	public static List<CartProduct> getCartItems() {
		return cartItems;
	}

	public static void setCartItems(List<CartProduct> cartItems) {
		Cart.cartItems = cartItems;
	}

	public static Double getCartTotal() {
		return cartTotal;
	}

	public static void setCartTotal(Double cartTotal) {
		Cart.cartTotal = cartTotal;
	}

	public static void addCartItem(CartProduct cartProduct) {
		cartItems.add(cartProduct);
	}

	@Override
	public String toString() {
		return "Cart [getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString()
				+ "]";
	}

}
