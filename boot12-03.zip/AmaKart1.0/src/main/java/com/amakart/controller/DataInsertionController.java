package com.amakart.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.amakart.model.Category;
import com.amakart.model.Product;
import com.amakart.model.ProductAttribute;
import com.amakart.repository.CategoryRepository;
import com.amakart.repository.ProductRepository;

@Controller
public class DataInsertionController {

	@Autowired
	Category category;

	@Autowired
	CategoryRepository categoryRepository;

	@Autowired
	Product product;

	@Autowired
	ProductRepository productRepository;

	@RequestMapping("insertdata")
	public String data() {
		
		

		category = new Category("Electronics", 0, "Electronics.jpg", true, "ElectronicsPromotedBanner.jpg");
		categoryRepository.save(category);

		category = new Category("Men's Fashion", 0, "MensFashion.jpg", true, "MensFashionPromotedBanner.jpg");
		categoryRepository.save(category);

		category = new Category("Sports", 0, "Sports.jpg", "MensFashionPromotedBanner.jpg");
		categoryRepository.save(category);

		category = new Category("Mobiles", 1, "Mobiles.jpg");

		product = new Product("M1", "Redmi Note 8", 12999.00, 9999.00, 50, 4.5, "RedmiNote8.jpg");

		product.addAttribute(new ProductAttribute("Battery Capacity", "4000 mAH"));

		product.addAttribute(new ProductAttribute("ROM Size", "64 GB"));

		product.addAttribute(new ProductAttribute("Ram Size", "4 GB"));

		product.addAttribute(new ProductAttribute("Screen Size", "6.4 Inch"));

		product.addAttribute(new ProductAttribute("Processor", "2.0GHz Qualcomm Snapdragon 665 octa core processor"));

		product.addImage("RedmiNote8.jpg");
		product.addImage("RedmiNote81.jpg");
		product.addImage("RedmiNote82.jpg");

		category.addProduct(product);

		product = new Product("M2", "Realme U1 Ambitious Black", 9999.00, 7999.00, 24, 4.0, "RealmeU1.jpg");

		product.addAttribute(new ProductAttribute("Battery Capacity", "3500 mAH"));

		product.addAttribute(new ProductAttribute("ROM Size", "32 GB"));

		product.addAttribute(new ProductAttribute("Ram Size", "3 GB"));

		product.addAttribute(new ProductAttribute("Screen Size", "6.3 Inch"));

		product.addAttribute(new ProductAttribute("Processor", "2.1GHz MediaTek Helio P70 octa core processor"));

		product.addImage("RealmeU1.jpg");
		product.addImage("RealmeU12.jpg");
		product.addImage("RealmeU13.jpg");

		category.addProduct(product);

		product = new Product("M3", "Vivo U20 Blazing Blue", 11499.00, 9990.00, 124, 4.5, "VivoU20.jpg");

		product.addAttribute(new ProductAttribute("Battery Capacity", "5000 mAH"));

		product.addAttribute(new ProductAttribute("ROM Size", "64 GB"));

		product.addAttribute(new ProductAttribute("Ram Size", "4 GB"));

		product.addAttribute(new ProductAttribute("Screen Size", "6.53 Inch"));

		product.addAttribute(new ProductAttribute("Processor", "Qualcomm Snapdragon 675 AIE octa core processor"));

		product.addImage("VivoU20.jpg");
		product.addImage("VivoU202.jpg");
		product.addImage("VivoU203.jpg");
		product.addImage("VivoU204.jpg");

		category.addProduct(product);

		categoryRepository.save(category);

		category = new Category("TV", 1, "TV.jpg");

		product = new Product("T1", "OnePlus 55 Inch 4K TV", 74999.00, 69899.00, 14, 4.0, "OnePlusQ1.jpg");

		product.addAttribute(new ProductAttribute("No Of HDMI Ports", "4"));

		product.addAttribute(new ProductAttribute("No Of USB Ports", "4"));

		product.addAttribute(new ProductAttribute("Refresh Rate", "Motion Rate 480 Hertz"));

		product.addAttribute(new ProductAttribute("Resolution", "4K Ultra HD (3840x2160)"));

		product.addAttribute(new ProductAttribute("Screen Size", "55 Inch"));

		product.addImage("OnePlusQ1.jpg");
		product.addImage("OnePlusQ12.jpg");
		product.addImage("OnePlusQ13.jpg");
		product.addImage("OnePlusQ14.jpg");

		category.addProduct(product);

		product = new Product("T2", "Mi LED TV 4C PRO 80 cm", 21999.00, 15499.00, 41, 3.0, "Mi4cPro.jpg");

		product.addAttribute(new ProductAttribute("No Of HDMI Ports", "3"));

		product.addAttribute(new ProductAttribute("No Of USB Ports", "3"));

		product.addAttribute(new ProductAttribute("Refresh Rate", "60 hertz"));

		product.addAttribute(new ProductAttribute("Resolution", "Full HD (1920x1080)"));

		product.addAttribute(new ProductAttribute("Screen Size", "43 Inch"));

		product.addImage("Mi4cPro.jpg");
		product.addImage("Mi4cPro2.jpg");
		product.addImage("Mi4cPro3.jpg");
		product.addImage("Mi4cPro4.jpg");

		category.addProduct(product);

		product = new Product("T3", "Vu 80 cm UltraAndroid LED TV 32GA", 13799.00, 10999.00, 80, 4.0, "Vu32GA.jpg");

		product.addAttribute(new ProductAttribute("No Of HDMI Ports", "2"));

		product.addAttribute(new ProductAttribute("No Of USB Ports", "2"));

		product.addAttribute(new ProductAttribute("Refresh Rate", "60 hertz"));

		product.addAttribute(new ProductAttribute("Resolution", "HD Ready (1366x768)"));

		product.addAttribute(new ProductAttribute("Screen Size", "32 Inch"));

		product.addImage("Vu32GA.jpg");
		product.addImage("Vu32GA2.jpg");
		product.addImage("Vu32GA3.jpg");
		product.addImage("Vu32GA4.jpg");

		category.addProduct(product);

		categoryRepository.save(category);

		category = new Category("Shirts", 2, "Shrits.jpg");

		product = new Product("MS1", "Jack & Jones Men's Printed Slim Fit Formal Shirt", 3999.00, 1599.00, 200, 3.2,
				"Jack&JonesB1.jpg");

		product.addAttribute(new ProductAttribute("Color Name", "Light Grey Melange"));

		product.addAttribute(new ProductAttribute("Fit Type", "Slim Fit"));

		product.addAttribute(new ProductAttribute("Material", "Cotton"));

		product.addAttribute(new ProductAttribute("Pattern", "Printed"));

		product.addImage("Jack&JonesB1.jpg");
		product.addImage("Jack&JonesB12.jpg");
		product.addImage("Jack&JonesB13.jpg");
		product.addImage("Jack&JonesB14.jpg");

		category.addProduct(product);

		categoryRepository.save(category);

		category = new Category("Watches", 2, "Watches.jpg");

		product = new Product("W1", "Fastrack Casual Analog Black Dial Men's Watch", 2100.00, 1399.00, 110, 4.1,
				"FastrackNL1.jpg");

		product.addAttribute(new ProductAttribute("Band Color", "Silver"));

		product.addAttribute(new ProductAttribute("Case Material", "Metal"));

		product.addAttribute(new ProductAttribute("Dial Color", "Black"));

		product.addAttribute(new ProductAttribute("Water Resistance Depth", "50 meters"));

		product.addImage("FastrackNL1.jpg");
		product.addImage("FastrackNL12.jpg");
		product.addImage("FastrackNL13.jpg");
		product.addImage("FastrackNL14.jpg");

		category.addProduct(product);

		product = new Product("W2", "Fastrack Essentials Analog Grey Dial Men's Watch", 1950.00, 1650.00, 78, 4.3,
				"FastrackNK1.jpg");

		product.addAttribute(new ProductAttribute("Band Color", "Black"));

		product.addAttribute(new ProductAttribute("Case Material", "Aluminuim"));

		product.addAttribute(new ProductAttribute("Dial Color", "Grey"));

		product.addAttribute(new ProductAttribute("Water Resistance Depth", "50 meters"));

		product.addImage("FastrackNK1.jpg");
		product.addImage("FastrackNK12.jpg");
		product.addImage("FastrackNk13.jpg");
		product.addImage("FastrackNK14.jpg");

		category.addProduct(product);

		product = new Product("W3", "Fastrack Black Magic Analog Black Dial Men's Watch", 4359.00, 3495.00, 56, 4.7,
				"FastrackBM1.jpg");

		product.addAttribute(new ProductAttribute("Band Color", "Black"));

		product.addAttribute(new ProductAttribute("Case Material", "Aluminuim"));

		product.addAttribute(new ProductAttribute("Dial Color", "Grey"));

		product.addAttribute(new ProductAttribute("Water Resistance Depth", "50 meters"));

		product.addImage("FastrackBM1.jpg");
		product.addImage("FastrackBM12.jpg");
		product.addImage("FastrackBM13.jpg");
		product.addImage("FastrackBM14.jpg");

		category.addProduct(product);

		categoryRepository.save(category);

		category = new Category("Badmintion", 3, "Badmintion.jpg");
		categoryRepository.save(category);

		category = new Category("Cricket", 3, "Cricket.jpg");
		categoryRepository.save(category);

		return "success";

	}
}