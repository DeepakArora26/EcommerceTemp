package com.amakart.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.amakart.exception.CategoriesNotFoundException;
import com.amakart.exception.FirstPromotedCategoryNotFoundException;
import com.amakart.exception.SecondPromotedCategoryNotFoundException;
import com.amakart.model.Cart;
import com.amakart.service.CartService;
import com.amakart.service.ShoppingService;

@Controller
public class HomeController {

	private static final Logger LOGGER = LogManager.getLogger(HomeController.class);

	@Autowired
	ShoppingService shopping;

	@Autowired
	CartService cartService;

	@GetMapping("/")
	public ModelAndView showHome(ModelAndView model) {

		LOGGER.info("--------In showHome Controller----------");

		try {
			model.addObject("categoriesList", shopping.getCategories(0));

			model.addObject("firstPromoted", shopping.getFirstPromoted());

			model.addObject("firstPromotedSubcategories", shopping.getCategories(shopping.getFirstPromoted().getId()));

			model.addObject("secondPromoted", shopping.getSecondPromoted());

			model.addObject("Cart", Cart.getCartItems());
			model.addObject("CartTotal", Cart.getCartTotal());

			model.addObject("secondPromotedSubcategories",
					shopping.getCategories(shopping.getSecondPromoted().getId()));
		}

		catch (CategoriesNotFoundException e) {

			LOGGER.info("--------Exception in showHome Controller----------");

			model.addObject("CategoriesMessage", "Coming Soon !");
		}

		catch (FirstPromotedCategoryNotFoundException e) {

			LOGGER.info("--------Exception in showHome Controller----------");

			model.addObject("FirstPromotedCategoryMessage", "Coming Soon !");
		}

		catch (SecondPromotedCategoryNotFoundException e) {

			LOGGER.info("--------Exception in showHome Controller----------");

			model.addObject("SecondPromotedCategoryMessage", "Coming Soon !");
		}

		model.setViewName("Home");
		return model;

	}

	@PostMapping("/subcategory")
	public ModelAndView showSubCategory(@RequestParam int parentId, ModelAndView model) {

		LOGGER.info("--------In showSubCategory Controller----------");

		try {

			model.addObject("subCategoriesList", shopping.getCategories(parentId));

		}

		catch (CategoriesNotFoundException e) {

			LOGGER.info("--------Exception in showSubCategory Controller----------");

			model.addObject("Message", "New Categories Coming Soon !!!!");
		}

		model.setViewName("subcategories");
		return model;

	}

	@PostMapping("/products")
	public ModelAndView showPoducts(@RequestParam int subCategoryId, ModelAndView model) {

		model.setViewName("products");
		model.addObject("productsList", shopping.getProducts(subCategoryId));
		return model;

	}

	@PostMapping("/productDetail")
	public ModelAndView showPoductDetails(@RequestParam String productId, ModelAndView model) {

		model.setViewName("productDetails");
		model.addObject("productDetail", shopping.getProductDetail(productId));
		return model;

	}

	@PostMapping("/addtocart")
	public ModelAndView addToCart(@RequestParam String productId, @RequestParam int productQuantity,
			ModelAndView model) {

		if (cartService.addToCart(productId, productQuantity)) {
			model.addObject("ProductAdditionMessage", "Product Has Been Successfully Added Into The Cart");
		}

		else {
			model.addObject("ProductAdditionMessage",
					"Sorry It Seems We Don't Have That Much Stock Right Now. Try Again With The Lesser Quantity");
		}
		model.addObject("productDetail", shopping.getProductDetail(productId));
		model.setViewName("productDetails");
		return model;

	}

	@GetMapping("/cart")
	public ModelAndView showCart(ModelAndView model) {

		model.setViewName("cart");
		model.addObject("Cart", Cart.getCartItems());
		model.addObject("CartTotal", Cart.getCartTotal());
		return model;

	}

	@PostMapping("/checkout")
	public ModelAndView checkout(ModelAndView model) {

		model.setViewName("Orders");
		model.addObject("OrderHistory", cartService.checkout());
		return model;

	}

}
