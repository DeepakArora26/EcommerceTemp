package com.amakart.servicetest;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.amakart.model.Cart;
import com.amakart.model.CartProduct;
import com.amakart.model.Product;
import com.amakart.repository.ProductRepository;
import com.amakart.service.CartServiceImpl;

class CartServiceTest {

	@InjectMocks
	CartServiceImpl cartServiceImpl;

	@Mock
	ProductRepository productRepository;

	Product product;

	@BeforeEach
	void initialize() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	void testProductQuantityTrue() {

		product = new Product();
		product.setProductAvailableStock(10);
		product.setProductId("M1");

		String productId = "M1";
		when(productRepository.findByProductId(productId)).thenReturn(product);

		assertEquals(true, cartServiceImpl.checkProductQuantity(productId, 5));
	}

	@Test
	void testProductQuantityFalse() {

		product = new Product();
		product.setProductAvailableStock(1);
		product.setProductId("M1");

		String productId = "M1";
		when(productRepository.findByProductId(productId)).thenReturn(product);

		assertEquals(false, cartServiceImpl.checkProductQuantity(productId, 5));
	}

	@Test
	void testaddToCart() {

		product = new Product();
		product.setProductId("M1");
		product.setThumbnail("ABC.jpg");
		product.setProductName("Sports");
		product.setProductDiscountedPrice(1100.00);
		product.setProductAvailableStock(100);

		CartProduct cartProduct = new CartProduct();
		cartProduct.setProductId("M1");
		cartProduct.setProductPurchasedQuantity(1);
		Cart.addCartItem(cartProduct);

		String productId = "M1";

		when(productRepository.findByProductId(productId)).thenReturn(product);
		assertEquals(true, cartServiceImpl.addToCart(productId, 10));
	}

	@Test
	void testaddToCartFalse() {

		product = new Product();
		product.setProductId("M1");
		product.setThumbnail("ABC.jpg");
		product.setProductName("Sports");
		product.setProductDiscountedPrice(1100.00);
		product.setProductAvailableStock(100);

		CartProduct cartProduct = new CartProduct();
		cartProduct.setProductId("M1");
		cartProduct.setProductPurchasedQuantity(1);
		Cart.addCartItem(cartProduct);

		String productId = "M1";

		when(productRepository.findByProductId(productId)).thenReturn(product);
		assertEquals(false, cartServiceImpl.addToCart(productId, 1000));
	}

	

}
