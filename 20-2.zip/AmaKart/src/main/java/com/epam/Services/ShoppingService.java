package com.epam.Services;

import java.util.List;

import com.epam.model.Categories;
import com.epam.model.Product;
import com.epam.model.Sub_Categories;

public interface ShoppingService {

	//void displayMenu() throws SQLException;

	List<Categories> getCategoriesList();
	
	List<Sub_Categories> getSubCategoriesList(String categoryId);
	
	List<Product> getProductsList(String subCategoryId);
	
	Product getproductDetails(String productId);
	


	//void checkout();

}
