package com.epam.model;

public class Categories {

	private String Category_Id;
	private String Category_Name;
	private String Category_Image;

	public String getCategory_Id() {
		return Category_Id;
	}

	public void setCategory_Id(String category_Id) {
		Category_Id = category_Id;
	}

	public String getCategory_Name() {
		return Category_Name;
	}

	public void setCategory_Name(String category_Name) {
		Category_Name = category_Name;
	}

	
	
	
	public String getCategory_Image() {
		return Category_Image;
	}

	public void setCategory_Image(String category_Image) {
		Category_Image = category_Image;
	}

	
	@Override
	public String toString() {
		return "Categories [Category_Id=" + Category_Id + ", Category_Name=" + Category_Name + "]";
	}

}
