package com.epam.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import com.epam.jdbc.Jdbc;
import com.epam.model.Cart;

public class ShoppingDaoServiceImpl implements ShoppingDaoService {

	public static Connection con = Jdbc.getDBConnection();
	ResultSet rs = null;
	


	@Override
	public ResultSet getCategories() throws SQLException {
		
		
		

		Statement stmt = con.createStatement();
		rs = stmt.executeQuery("select * from categories");

		return rs;
	}

	@Override
	public ResultSet getSubCategories(String categoryId) {

		try {
			Statement stmt = con.createStatement();
			rs = stmt.executeQuery("select * from sub_categories where category_id = '" + categoryId + "'");

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return rs;
	}

	@Override
	public ResultSet getProducts(String subCategoryId) {

		try {
			Statement stmt = con.createStatement();
			rs = stmt.executeQuery("select * from product where sub_category_id = '" + subCategoryId + "'");

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return rs;
	}

	@Override
	public ResultSet getProductDetails(String productId) {

		try {
			Statement stmt = con.createStatement();
			rs = stmt.executeQuery("select * from product where product_id = '" + productId + "'");

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return rs;
	}

	@Override
	public void checkout(String customerName , List<Cart> currentCart) {
		String insertValues;

		try {
			Statement stmt = con.createStatement();
			
			
		
			String insertData = "insert into order_history (CUSTOMER_NAME , CART_TOTAL , ORDER_DATE ) values ( '" + customerName + "','" + Cart.getCartTotal() + "','" + java.time.LocalDate.now() + " ') ";
			stmt.executeUpdate(insertData);
			
			
			rs = stmt.executeQuery("SELECT * FROM order_history ORDER BY Order_id DESC LIMIT 1");
			rs.next();
			
			int order_id = rs.getInt(1);
			
			for(Cart currentProduct : currentCart)
			{
			

				insertValues = " insert into order_details values (  " + order_id + " ,'" + currentProduct.getProductName() + "'," + currentProduct.getProductQuantity() + "," + currentProduct.getProductPrice() + "," + currentProduct.getTotalPrice() + " ) ";
				stmt.executeUpdate(insertValues);
				
			}
			
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
