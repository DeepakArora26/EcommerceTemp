package com.epam.Services;

import java.util.List;

import com.epam.model.Cart;

public interface CartService {
	
	
	
	void addToCart(String productId,int productQuantity);
	
	List<Cart> getCart();
	
	void calculateCartTotal();
	

}
