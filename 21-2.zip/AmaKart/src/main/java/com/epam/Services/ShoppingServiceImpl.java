package com.epam.Services;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.epam.dao.ShoppingDaoService;
import com.epam.dao.ShoppingDaoServiceImpl;
import com.epam.jdbc.Jdbc;
import com.epam.model.Cart;
import com.epam.model.Categories;
import com.epam.model.Product;
import com.epam.model.Sub_Categories;

public class ShoppingServiceImpl implements ShoppingService {

	ShoppingDaoService Shopping = new ShoppingDaoServiceImpl();

	//static Logger logger = LogManager.getLogger(ShoppingServiceImpl.class);
	
	static Scanner input = new Scanner(System.in);
	String userSelection;
	static final String WARNING = "Wrong Selection. Please Select from the above Options only";
	ResultSet rs;
	//CartService cart = new CartServiceImpl();

	
	Categories categoryDetail;
	Sub_Categories subCategoryDetail;
	Product productDetail;
	

	
	
	
	
	
	@Override
	public List<Categories> getCategoriesList() {

		List<Categories> categoryList = new ArrayList<>();
		

		try {

			rs = Shopping.getCategories();
			
			
			while (rs.next()) {
				
				
				categoryDetail = new Categories();
				categoryDetail.setCategory_Id(rs.getString(1));
				categoryDetail.setCategory_Name(rs.getString(2));
				categoryDetail.setCategory_Image(rs.getString(3));
				
				categoryList.add(categoryDetail);
				
			}


			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		

		return categoryList;

	}






	@Override
	public List<Sub_Categories> getSubCategoriesList(String categoryId) {

		List<Sub_Categories> subCategoryList = new ArrayList<>();
		

		try {

			rs = Shopping.getSubCategories(categoryId);
			
			
			while (rs.next()) {
				
				
				subCategoryDetail = new Sub_Categories();
				subCategoryDetail.setCategory_Id(rs.getString(1));
				subCategoryDetail.setSub_Category_Id(rs.getString(2));
				subCategoryDetail.setSub_Category_Name(rs.getString(3));
				subCategoryDetail.setSub_Category_Image(rs.getString(4));
				
				subCategoryList.add(subCategoryDetail);
				
			}


			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		

		return subCategoryList;
	}






	@Override
	public List<Product> getProductsList(String subCategoryId) {

		List<Product> productList = new ArrayList<>();
		

		try {

			rs = Shopping.getProducts(subCategoryId);
			
			
			while (rs.next()) {
				
				
				productDetail = new Product();
				productDetail.setCategory_Id(rs.getString(1));
				productDetail.setSub_Category_Id(rs.getString(2));
				productDetail.setProduct_Id(rs.getString(3));
				productDetail.setProduct_Name(rs.getString(4));
				productDetail.setProduct_Price(rs.getDouble(5));
				productDetail.setProduct_Quantity(rs.getInt(6));
				productDetail.setProduct_Image(rs.getString(7));
				
				productList.add(productDetail);
				
			}


			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		

		return productList;
	}






	@Override
	public Product getproductDetails(String productId) {
		
		productDetail = new Product();
		
		
		
		try {

			rs = Shopping.getProductDetails(productId);
			
			
			while (rs.next()) {
				
				
				productDetail = new Product();
				productDetail.setCategory_Id(rs.getString(1));
				productDetail.setSub_Category_Id(rs.getString(2));
				productDetail.setProduct_Id(rs.getString(3));
				productDetail.setProduct_Name(rs.getString(4));
				productDetail.setProduct_Price(rs.getDouble(5));
				productDetail.setProduct_Quantity(rs.getInt(6));
				productDetail.setProduct_Image(rs.getString(7));
				
				
			}


			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		
		
		return productDetail;
	}






	
	
	
	
	
	
	
	
	/*
	 * 
	 * @Override public void displayMenu() throws SQLException {
	 * logger.info("-----------------------------------");
	 * logger.info("Welcome to AmaKart Shopping Portal");
	 * logger.info("-----------------------------------");
	 * logger.info("Choose your Option \n"); logger.info("1.Shopping");
	 * logger.info("2.View Cart"); logger.info("3.Modify Cart");
	 * logger.info("4.Exit / CheckOut");
	 * 
	 * userSelection = input.next();
	 * 
	 * switch (userSelection) {
	 * 
	 * case "1": getCategoriesList(); break; case "2": cart.displayCart(1); break;
	 * case "3": cart.modifyCart(); break; case "4": checkout(); break; default:
	 * logger.info(WARNING + "\n"); displayMenu(); }
	 * 
	 * }
	 * 
	 * 
	 * @Override public void displaySubCategories(String categoryId) {
	 * 
	 * logger.info("Choose The Sub Category \n");
	 * 
	 * rs = Shopping.getSubCategories(categoryId); try {
	 * 
	 * if (rs.next() == false) {
	 * 
	 * logger.info(WARNING + "\n"); getCategoriesList();
	 * 
	 * }
	 * 
	 * else { rs.beforeFirst(); logger.info("Sub-Category Id    Sub-Category Name");
	 * 
	 * while (rs.next()) { System.out.println(rs.getString(2) + "                 "
	 * + rs.getString(3)); } }
	 * 
	 * } catch (SQLException e) { e.printStackTrace(); }
	 * 
	 * displayProducts(categoryId, input.next());
	 * 
	 * }
	 * 
	 * @Override public void displayProducts(String categoryId, String
	 * subCategoryId) {
	 * 
	 * logger.info("Choose The Product Id\n");
	 * 
	 * rs = Shopping.getProducts(subCategoryId); try {
	 * 
	 * if (rs.next() == false) {
	 * 
	 * logger.info(WARNING + "\n"); displaySubCategories(categoryId);
	 * 
	 * }
	 * 
	 * else { rs.beforeFirst();
	 * 
	 * logger.info(
	 * "Product Id    Product Name                                                     Product Price          Product Quantity"
	 * );
	 * 
	 * while (rs.next()) { logger.info(rs.getString(3) + "           " +
	 * rs.getString(4) + "                         " + rs.getString(5) +
	 * "                 " + rs.getString(6)); } } } catch (SQLException e) {
	 * e.printStackTrace(); }
	 * 
	 * cart.addProductToCart(categoryId, subCategoryId, input.next());
	 * 
	 * }
	 * 
	 * @Override public void checkout() {
	 * 
	 * if (Data.getCart().isEmpty()) {
	 * 
	 * logger.
	 * info("Your is Cart is EMPTY. Would you like to continue Shopping or Exit. : Y -> Continue Shopping : N -> Exit Portal"
	 * ); userSelection = input.next(); if (userSelection.equalsIgnoreCase("Y")) {
	 * try { displayMenu(); } catch (SQLException e) { e.printStackTrace(); } } else
	 * if (userSelection.equalsIgnoreCase("N")) {
	 * 
	 * 
	 * logger.info("Thanks for Visiting AmaKart");
	 * 
	 * }
	 * 
	 * else logger.info("Wrong Input");
	 * 
	 * }
	 * 
	 * else {
	 * 
	 * 
	 * 
	 * cart.displayCart(0);
	 * 
	 * logger.
	 * info("Would you like to Checkout : Y/N ?  Y -> Order will be placed : N -> Contniue Shopping"
	 * );
	 * 
	 * userSelection = input.next();
	 * 
	 * if (userSelection.equalsIgnoreCase("Y")) {
	 * 
	 * 
	 * logger.info("Enter You Name"); userSelection = input.next();
	 * 
	 * Shopping.checkout(userSelection, Data.getCart());
	 * 
	 * logger.info("Thanks for Shopping with AmaKart");
	 * logger.info("Here are your Order Details"); cart.displayCart(0);
	 * System.exit(0);
	 * 
	 * }
	 * 
	 * else if (userSelection.equalsIgnoreCase("N")) {
	 * 
	 * try { displayMenu(); } catch (SQLException e) { e.printStackTrace(); } }
	 * 
	 * 
	 * else logger.info("Wrong Input");
	 * 
	 * }
	 * 
	 * }
	 */
}
