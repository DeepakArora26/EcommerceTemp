package com.epam.Services;

import java.util.List;

import com.epam.jdbc.Jdbc;
import com.epam.model.Cart;
import com.epam.model.Product;

public class CartServiceImpl implements CartService {
	
	Cart currentProduct;
	Jdbc Data = new Jdbc();
	ShoppingService Shopping;
	Product product;
	
	@Override
	public void addToCart(String productId,int productQuantity) {
		
		
		Shopping = new ShoppingServiceImpl();
		product = new Product();
		
		product = Shopping.getproductDetails(productId);
		

		
		currentProduct = new Cart(productId, product.getProduct_Name(), product.getProduct_Price(), productQuantity, product.getProduct_Image());
		
		Jdbc.cart.add(currentProduct);
		
	}

	
	
	@Override
	public List<Cart> getCart() {
		
		
		return Jdbc.cart;
		
		
	}



	@Override
	public void calculateCartTotal() {
		
		Double cartTotal=0.0;
		
		for (Cart currentProduct : Jdbc.cart) {
			cartTotal = cartTotal + currentProduct.getTotalPrice();
        }
		Cart.cartTotal = cartTotal;
	}

	

}
