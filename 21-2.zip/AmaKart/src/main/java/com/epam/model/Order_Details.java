package com.epam.model;

public class Order_Details {

	private String Order_Id;
	private String Product_Name;
	private int Product_Quantity;
	private Double Product_Price;
	private Double Product_Total_Price;

	public String getOrder_Id() {
		return Order_Id;
	}

	public void setOrder_Id(String order_Id) {
		Order_Id = order_Id;
	}

	public String getProduct_Name() {
		return Product_Name;
	}

	public void setProduct_Name(String product_Name) {
		Product_Name = product_Name;
	}

	public int getProduct_Quantity() {
		return Product_Quantity;
	}

	public void setProduct_Quantity(int product_Quantity) {
		Product_Quantity = product_Quantity;
	}

	public Double getProduct_Price() {
		return Product_Price;
	}

	public void setProduct_Price(Double product_Price) {
		Product_Price = product_Price;
	}

	public Double getProduct_Total_Price() {
		return Product_Total_Price;
	}

	public void setProduct_Total_Price(Double product_Total_Price) {
		Product_Total_Price = product_Total_Price;
	}

	@Override
	public String toString() {
		return "Order_Details [Order_Id=" + Order_Id + ", Product_Name=" + Product_Name + ", Product_Quantity="
				+ Product_Quantity + ", Product_Price=" + Product_Price + ", Product_Total_Price=" + Product_Total_Price
				+ "]";
	}

}
