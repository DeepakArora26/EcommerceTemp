package com.epam.model;

public class Sub_Categories {

	private String Category_Id;
	private String Sub_Category_Id;
	private String Sub_Category_Name;
	private String Sub_Category_Image;

	public String getCategory_Id() {
		return Category_Id;
	}

	public void setCategory_Id(String category_Id) {
		Category_Id = category_Id;
	}

	public String getSub_Category_Id() {
		return Sub_Category_Id;
	}

	public void setSub_Category_Id(String sub_Category_Id) {
		Sub_Category_Id = sub_Category_Id;
	}

	public String getSub_Category_Name() {
		return Sub_Category_Name;
	}

	public void setSub_Category_Name(String sub_Category_Name) {
		Sub_Category_Name = sub_Category_Name;
	}
	
	
	
	public String getSub_Category_Image() {
		return Sub_Category_Image;
	}

	public void setSub_Category_Image(String sub_Category_Image) {
		Sub_Category_Image = sub_Category_Image;
	}

	@Override
	public String toString() {
		return "Sub_Categories [Category_Id=" + Category_Id + ", Sub_Category_Id=" + Sub_Category_Id
				+ ", Sub_Category_Name=" + Sub_Category_Name + "]";
	}

}
