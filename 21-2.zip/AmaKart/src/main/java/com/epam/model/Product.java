package com.epam.model;

public class Product {

	private String Category_Id;
	private String Sub_Category_Id;
	private String Product_Id;
	private String Product_Name;
	private Double Product_Price;
	private int Product_Quantity;
	private String Product_Image;

	public String getCategory_Id() {
		return Category_Id;
	}

	public void setCategory_Id(String category_Id) {
		Category_Id = category_Id;
	}

	public String getSub_Category_Id() {
		return Sub_Category_Id;
	}

	public void setSub_Category_Id(String sub_Category_Id) {
		Sub_Category_Id = sub_Category_Id;
	}

	public String getProduct_Id() {
		return Product_Id;
	}

	public void setProduct_Id(String product_Id) {
		Product_Id = product_Id;
	}

	public String getProduct_Name() {
		return Product_Name;
	}

	public void setProduct_Name(String product_Name) {
		Product_Name = product_Name;
	}

	public Double getProduct_Price() {
		return Product_Price;
	}

	public void setProduct_Price(Double product_Price) {
		Product_Price = product_Price;
	}

	public int getProduct_Quantity() {
		return Product_Quantity;
	}

	public void setProduct_Quantity(int product_Quantity) {
		Product_Quantity = product_Quantity;
	}
	
	
	public String getProduct_Image() {
		return Product_Image;
	}

	public void setProduct_Image(String product_Image) {
		Product_Image = product_Image;
	}

	@Override
	public String toString() {
		return "Product [Category_Id=" + Category_Id + ", Sub_Category_Id=" + Sub_Category_Id + ", Product_Id="
				+ Product_Id + ", Product_Name=" + Product_Name + ", Product_Price=" + Product_Price
				+ ", Product_Quantity=" + Product_Quantity + "]";
	}

}
