package com.epam.model;

public class Cart {

	private String productId;
	private String productName;
	private double productPrice;
	private int productQuantity;
	private double totalPrice;
	public static double cartTotal;
	private String ProductImage;
	
	
	

	public Cart(String productId, String productName, double productPrice, int productQuantity, String ProductImage) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productPrice = productPrice;
		this.productQuantity = productQuantity;
		this.totalPrice = productPrice * productQuantity;
		this.ProductImage = ProductImage;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public double getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}

	public int getProductQuantity() {
		return productQuantity;
	}

	public void setProductQuantity(int productQuantity) {
		this.productQuantity = productQuantity;
		totalPrice = productPrice * productQuantity;
	}

	public double getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}


	public String getProductImage() {
		return ProductImage;
	}

	public void setProductImage(String product_Image) {
		ProductImage = product_Image;
	}

	
	

	@Override
	public String toString() {
		return productId + "             " +  productName + productPrice +  "                    " + productQuantity + "                 "+ totalPrice;
	}

}
