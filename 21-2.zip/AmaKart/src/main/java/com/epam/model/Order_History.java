package com.epam.model;

import java.util.Date;

public class Order_History {

	private String Order_Id;
	private String Customer_Name;
	private Double Cart_Total;
	private Date Order_Date;

	public String getOrder_Id() {
		return Order_Id;
	}

	public void setOrder_Id(String order_Id) {
		Order_Id = order_Id;
	}

	public String getCustomer_Name() {
		return Customer_Name;
	}

	public void setCustomer_Name(String customer_Name) {
		Customer_Name = customer_Name;
	}

	public Double getCart_Total() {
		return Cart_Total;
	}

	public void setCart_Total(Double cart_Total) {
		Cart_Total = cart_Total;
	}

	public Date getOrder_Date() {
		return Order_Date;
	}

	public void setOrder_Date(Date order_Date) {
		Order_Date = order_Date;
	}

	@Override
	public String toString() {
		return "Order_History [Order_Id=" + Order_Id + ", Customer_Name=" + Customer_Name + ", Cart_Total=" + Cart_Total
				+ ", Order_Date=" + Order_Date + "]";
	}

}
