package com.epam.jdbc;

import java.io.File;
import java.io.FileInputStream;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.epam.model.Cart;

public class Jdbc {

	public static List<Cart> cart = new ArrayList<>();

	public List<Cart> getCart() {
		return cart;
	}

      static Connection connection ;

	public static Connection getDBConnection() {

		if (connection == null) {
			//Properties dbProperties = new Properties();

			try {

				//dbProperties.load(new FileInputStream(new File("jdbc.properties")));
				String driver = "com.mysql.cj.jdbc.Driver";
				String url = "jdbc:mysql://localhost:3306/ecommerce";
				String user = "root";
				String password = "Epam1234$";

				Class.forName(driver);

				connection = DriverManager.getConnection(url, user, password);

			}

			catch (Exception e) {
				e.printStackTrace();
			}

		}
		return connection;

	}

}
