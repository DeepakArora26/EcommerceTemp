package com.epam.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.epam.Services.ShoppingService;
import com.epam.Services.ShoppingServiceImpl;


@WebServlet("/DisplayProducts")
public class DisplayProducts extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	
	ShoppingService Shopping;
	RequestDispatcher rd;
	
	
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		Shopping = new ShoppingServiceImpl();
		
		request.setAttribute("productList", Shopping.getProductsList(request.getParameter("subCategoryId")));
		
		//System.out.println(Shopping.getProductsList(request.getParameter("subCategoryId")));
		
		rd = request.getRequestDispatcher("jsp/products.jsp");
		
		rd.forward(request, response);
		
		
	
	}

}
