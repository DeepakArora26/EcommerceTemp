package com.epam.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.epam.Services.ShoppingService;
import com.epam.Services.ShoppingServiceImpl;


@WebServlet("/DisplayProductDetails")
public class DisplayProductDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	
	
	ShoppingService Shopping;
	RequestDispatcher rd;
	
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		Shopping = new ShoppingServiceImpl();
		
		request.setAttribute("productDetail", Shopping.getproductDetails(request.getParameter("productId")));
		
		
		
		//System.out.println(request.getParameter("productId"));
		
		
		
		rd = request.getRequestDispatcher("jsp/productDetails.jsp");
		
		rd.forward(request, response);
		
		
	}

}
