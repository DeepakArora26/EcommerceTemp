package com.epam.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.epam.Services.CartService;
import com.epam.Services.CartServiceImpl;
import com.epam.Services.ShoppingService;
import com.epam.jdbc.Jdbc;
import com.epam.model.Cart;



@WebServlet("/addtocart")
public class AddToCart extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	CartService cartShopping;
	RequestDispatcher rd;

	

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	
	
	
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		cartShopping = new CartServiceImpl();
		
		
		cartShopping.addToCart(request.getParameter("productIds"), Integer.parseInt(request.getParameter("productQuantity")));
		
		System.out.println(request.getParameter("productIds"));
	
	
	
	}

}
