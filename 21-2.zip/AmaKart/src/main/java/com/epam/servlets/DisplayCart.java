package com.epam.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.epam.Services.CartService;
import com.epam.Services.CartServiceImpl;
import com.epam.Services.ShoppingService;
import com.epam.Services.ShoppingServiceImpl;
import com.epam.model.Cart;


@WebServlet("/cart")
public class DisplayCart extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	

	CartService CartShopping;
	RequestDispatcher rd;
	
	
	

	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		CartShopping = new CartServiceImpl();
		CartShopping.calculateCartTotal();
		
		
		request .setAttribute("CartDetail", CartShopping.getCart());
		request.setAttribute("CartTotal", Cart.cartTotal);
		rd = request.getRequestDispatcher("jsp/cart.jsp");
		rd.forward(request, response);
		
	}



	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		//request.setAttribute("productDetail", Shopping.getproductDetails(request.getParameter("productId")));
		
		
		
		//System.out.println(request.getParameter("productId"));
		
		
		
		rd = request.getRequestDispatcher("jsp/cart.jsp");
		
		rd.forward(request, response);
		
		
	}

}
