package com.epam.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.epam.Services.ShoppingService;
import com.epam.Services.ShoppingServiceImpl;



@WebServlet("/DisplaySubCategories")
public class DisplaySubCategories extends HttpServlet {
	private static final long serialVersionUID = 1L;


	ShoppingService Shopping;
	RequestDispatcher rd;
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Shopping = new ShoppingServiceImpl();
		
		request.setAttribute("subCategoryList", Shopping.getSubCategoriesList(request.getParameter("categoryId")));
		
		//System.out.println(Shopping.getSubCategoriesList(request.getParameter("categoryId")));
		
		rd = request.getRequestDispatcher("jsp/subCategories.jsp");
		
		rd.forward(request, response);
		
		
		
		
		
	}
	
	
	
	
	

}
