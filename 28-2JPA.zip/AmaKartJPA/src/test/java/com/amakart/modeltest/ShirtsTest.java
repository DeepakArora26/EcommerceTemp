package com.amakart.modeltest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.amakart.model.Shirts;

class ShirtsTest {


	Shirts shirt;
	
	@BeforeEach
	void initialize()
	{
		shirt = new Shirts();
	}
	
	
	
	
	@Test
	void checkProductIdWithNull()
	{
		
		assertEquals(null, shirt.getProductId());
		
	}
	
	
	@Test
	void checkProductIdWithValue()
	{
		
		shirt.setProductId("EM1");
		assertEquals("EM1", shirt.getProductId());
		
	}
	
	
	
	@Test
	void checkColorNameWithNull()
	{
		
		assertEquals(null, shirt.getColorName());
		
	}
	
	
	@Test
	void checkColorNameWithValue()
	{
		
		shirt.setColorName("Light Pink");
		assertEquals("Light Pink", shirt.getColorName());
		
	}
	

	@Test
	void checkMaterialWithNull()
	{
		
		assertEquals(null, shirt.getMaterial());
		
	}
	
	
	@Test
	void checkMaterialWithValue()
	{
		
		shirt.setMaterial("Cotton");
		assertEquals("Cotton", shirt.getMaterial());
		
	}
	
	

	@Test
	void checkPatternWithNull()
	{
		
		assertEquals(null, shirt.getPattern());
		
	}
	
	
	@Test
	void checkPatternWithValue()
	{
		
		shirt.setPattern("Printed");
		assertEquals("Printed", shirt.getPattern());
		
	}
	
	
	
	@Test
	void checkFitTypeWithNull()
	{
		
		assertEquals(null, shirt.getFitType());
		
	}
	
	
	@Test
	void checkFitTypeWithValue()
	{
		
		shirt.setFitType("Slim Fit");
		assertEquals("Slim Fit", shirt.getFitType());
		
	}
	
	
	
	@Test
	void checktoStringWithNull()
	{
		
		assertEquals("Shirts [productId=null, colorName=null, material=null, pattern=null, fitType=null]", shirt.toString());
		
	}
	
	
	@Test
	void checktoStringWithValue()
	{
		shirt.setProductId("EM1");
		shirt.setColorName("Light Pink");
		shirt.setMaterial("Cotton");
		shirt.setPattern("Printed");
		shirt.setFitType("Slim Fit");
		assertEquals("Shirts [productId=EM1, colorName=Light Pink, material=Cotton, pattern=Printed, fitType=Slim Fit]", shirt.toString());
		
	}
	
}
