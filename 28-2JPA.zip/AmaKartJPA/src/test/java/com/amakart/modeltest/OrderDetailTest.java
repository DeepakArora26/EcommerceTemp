package com.amakart.modeltest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.amakart.model.OrderDetail;

class OrderDetailTest {


	OrderDetail orderDetail;
	
	@BeforeEach
	void initialize()
	{
		orderDetail = new OrderDetail();
	}
	
	
	
	
	@Test
	void checkOrderIdWithNull()
	{
		assertEquals(null, orderDetail.getOrderId());
	}
	
	
	@Test
	void checkOrderIdWithValue()
	{
		orderDetail.setOrderId("57");
		assertEquals("57", orderDetail.getOrderId());
	}
	
	
	
	
	@Test
	void checkProductNameWithNull()
	{
		assertEquals(null, orderDetail.getProductName());
	}
	
	
	@Test
	void checkProductNameWithValue()
	{
		orderDetail.setProductName("Realme U1 Pro");
		assertEquals("Realme U1 Pro", orderDetail.getProductName());
	}

	
	@Test
	void checkProductPurchasedQuantityWithNull()
	{
		assertEquals(0, orderDetail.getProductPurchasedQuantity());
	}
	
	
	@Test
	void checkProductPurchasedQuantityWithValue()
	{
		orderDetail.setProductPurchasedQuantity(12);
		assertEquals(12, orderDetail.getProductPurchasedQuantity());
	}

	@Test
	void checkProductPerQuantityPriceWithNull()
	{
		assertEquals(null, orderDetail.getProductPerQuantityPrice());
	}
	
	
	@Test
	void checkProductPerQuantityPriceWithValue()
	{
		orderDetail.setProductPerQuantityPrice(5999.0);
		assertEquals(5999.0, orderDetail.getProductPerQuantityPrice());
	}

	
	
	@Test
	void checkProductTotalPriceWithNull()
	{
		assertEquals(null, orderDetail.getProductTotalPrice());
	}
	
	
	@Test
	void checkProductTotalPriceWithValue()
	{
		orderDetail.setProductTotalPrice(15999.0);
		assertEquals(15999.0, orderDetail.getProductTotalPrice());
	}

	
	
	

	@Test
	void checktoStringWithNull()
	{
		assertEquals("OrderDetail [orderId=null, productname=null, productPurchasedQuantity=0, productPerQuantityPrice=null, productTotalPrice=null]", orderDetail.toString());
	}
	
	
	@Test
	void checktoStringWithValue()
	{
		orderDetail.setOrderId("57");
		orderDetail.setProductName("Realme U1 Pro");
		orderDetail.setProductPurchasedQuantity(12);
		orderDetail.setProductPerQuantityPrice(5999.0);
		orderDetail.setProductPerQuantityPrice(15999.0);
		assertEquals("OrderDetail [orderId=57, productname=Realme U1 Pro, productPurchasedQuantity=12, productPerQuantityPrice=15999.0, productTotalPrice=null]", orderDetail.toString());
	}

	
	
}

