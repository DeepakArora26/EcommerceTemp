package com.amakart.modeltest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.amakart.model.Watches;

class WatchesTest {

	Watches watch;
	
	@BeforeEach
	void initialize()
	{
		watch = new Watches();
	}
	
	
	
	
	@Test
	void checkProductIdWithNull()
	{
		
		assertEquals(null, watch.getProductId());
		
	}
	
	
	@Test
	void checkProductIdWithValue()
	{
		
		watch.setProductId("EM1");
		assertEquals("EM1", watch.getProductId());
		
	}
	
	
	@Test
	void checkDialColorWithNull()
	{
		
		assertEquals(null, watch.getDialColor());
		
	}
	
	
	@Test
	void checkDialColorWithValue()
	{
		
		watch.setDialColor("Black");
		assertEquals("Black", watch.getDialColor());
		
	}
	
	
	
	
	@Test
	void checkBandColorWithNull()
	{
		
		assertEquals(null, watch.getBandColor());
		
	}
	
	
	@Test
	void checkBandColorWithValue()
	{
		
		watch.setBandColor("Grey");
		assertEquals("Grey", watch.getBandColor());
		
	}
	
	
	
	@Test
	void checkCaseMaterialWithNull()
	{
		
		assertEquals(null, watch.getCaseMaterial());
		
	}
	
	
	@Test
	void checkCaseMaterialWithValue()
	{
		
		watch.setCaseMaterial("Aluminuium");
		assertEquals("Aluminuium", watch.getCaseMaterial());
		
	}
	
	
	
	@Test
	void checkWaterResistanceDepthWithNull()
	{
		
		assertEquals(null, watch.getWaterResistanceDepth());
		
	}
	
	
	@Test
	void checkWaterResistanceDepthWithValue()
	{
		
		watch.setWaterResistanceDepth("50 Meter");
		assertEquals("50 Meter", watch.getWaterResistanceDepth());
		
	}
	
	
	
	
	
	@Test
	void checktoStringWithNull()
	{
		
		assertEquals("Watches [productId=null, dialColor=null, bandColor=null, caseMaterial=null, waterResistanceDepth=null]", watch.toString());
		
	}
	
	
	@Test
	void checktoStringWithValue()
	{
		watch.setProductId("EM1");
		watch.setDialColor("Black");
		watch.setBandColor("Grey");
		watch.setCaseMaterial("Aluminuium");
		watch.setWaterResistanceDepth("50 Meter");
		assertEquals("Watches [productId=EM1, dialColor=Black, bandColor=Grey, caseMaterial=Aluminuium, waterResistanceDepth=50 Meter]", watch.toString());
		
	}
	
	
	
}
