package com.amakart.modeltest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.amakart.model.CartProduct;
import com.amakart.model.Mobile;

class MobileTest {

	Mobile mobile;

	@BeforeEach
	void initialize() {
		mobile = new Mobile();
	}

	@Test
	void checkProductIdWithNull() {

		assertEquals(null, mobile.getProductId());

	}

	@Test
	void checkProductIdWithValue() {

		mobile.setProductId("EM1");
		assertEquals("EM1", mobile.getProductId());

	}
	
	
	@Test
	void checkRamSizeWithNull() {

		assertEquals(null, mobile.getRamSize());

	}

	@Test
	void checkRamSizeWithValue() {

		mobile.setRamSize("4GB");
		assertEquals("4GB", mobile.getRamSize());

	}
	
	
	@Test
	void checkRomSizeWithNull() {

		assertEquals(null, mobile.getRomSize());

	}

	@Test
	void checkRomSizeWithValue() {

		mobile.setRomSize("64GB");
		assertEquals("64GB", mobile.getRomSize());

	}
	
	
	
	@Test
	void checkScreenSizeWithNull() {

		assertEquals(null, mobile.getScreenSize());

	}

	@Test
	void checkScreenSizeWithValue() {

		mobile.setScreenSize("5.3 Inch");
		assertEquals("5.3 Inch", mobile.getScreenSize());

	}
	
	
	
	
	@Test
	void checkProcessorNameWithNull() {

		assertEquals(null, mobile.getProcessorName());

	}

	@Test
	void checkProcessorNameWithValue() {

		mobile.setProcessorName("Qualcomm Snapdragon 675 AIE octa core processor");
		assertEquals("Qualcomm Snapdragon 675 AIE octa core processor", mobile.getProcessorName());

	}
	
	
	
	@Test
	void checkBatteryCapacityWithNull() {

		assertEquals(null, mobile.getBatteryCapacity());

	}

	@Test
	void checkBatteryCapacityWithValue() {

		mobile.setBatteryCapacity("4000mAH");
		assertEquals("4000mAH", mobile.getBatteryCapacity());

	}
	
	
	@Test
	void checktoStringWithNull() {

		assertEquals("Mobile [productId=null, ramSize=null, romSize=null, screenSize=null, processorName=null, batteryCapacity=null]", mobile.toString());

	}

	@Test
	void checktoStringWithValue() {
		mobile.setProductId("EM1");
		mobile.setRamSize("4GB");
		mobile.setRomSize("64GB");
		mobile.setScreenSize("5.3 Inch");
		mobile.setProcessorName("Qualcomm Snapdragon 675 AIE octa core processor");
		mobile.setBatteryCapacity("4000mAH");
		assertEquals("Mobile [productId=EM1, ramSize=4GB, romSize=64GB, screenSize=5.3 Inch, processorName=Qualcomm Snapdragon 675 AIE octa core processor, batteryCapacity=4000mAH]", mobile.toString());

	}
	
	
}
