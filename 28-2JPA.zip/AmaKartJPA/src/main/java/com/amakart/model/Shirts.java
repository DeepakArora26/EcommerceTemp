package com.amakart.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PrimaryKeyJoinColumn;

@Entity
@PrimaryKeyJoinColumn(referencedColumnName = "productId")
public class Shirts extends Product {

	@Id
	private String productId;
	private String colorName;
	private String material;
	private String pattern;
	private String fitType;



	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getColorName() {
		return colorName;
	}

	public void setColorName(String colorName) {
		this.colorName = colorName;
	}

	public String getMaterial() {
		return material;
	}

	public void setMaterial(String material) {
		this.material = material;
	}

	public String getPattern() {
		return pattern;
	}

	public void setPattern(String pattern) {
		this.pattern = pattern;
	}

	public String getFitType() {
		return fitType;
	}

	public void setFitType(String fitType) {
		this.fitType = fitType;
	}

	@Override
	public String toString() {
		return "Shirts [productId=" + productId + ", colorName=" + colorName + ", material=" + material + ", pattern="
				+ pattern + ", fitType=" + fitType + "]";
	}

}
