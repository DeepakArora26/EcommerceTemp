package com.amakart.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PrimaryKeyJoinColumn;

@Entity
@PrimaryKeyJoinColumn(referencedColumnName="productId")
public class Mobile extends Product{
	
	
	@Id
	private String productId;
	private String ramSize;
	private String romSize;
	private String screenSize;
	private String processorName;
	private String batteryCapacity;
	
	
	

	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getRamSize() {
		return ramSize;
	}
	public void setRamSize(String ramSize) {
		this.ramSize = ramSize;
	}
	public String getRomSize() {
		return romSize;
	}
	public void setRomSize(String romSize) {
		this.romSize = romSize;
	}
	public String getScreenSize() {
		return screenSize;
	}
	public void setScreenSize(String screenSize) {
		this.screenSize = screenSize;
	}
	public String getProcessorName() {
		return processorName;
	}
	public void setProcessorName(String processorName) {
		this.processorName = processorName;
	}
	public String getBatteryCapacity() {
		return batteryCapacity;
	}
	public void setBatteryCapacity(String batteryCapacity) {
		this.batteryCapacity = batteryCapacity;
	}
	
	
	@Override
	public String toString() {
		return "Mobile [productId=" + productId + ", ramSize=" + ramSize + ", romSize=" + romSize + ", screenSize="
				+ screenSize + ", processorName=" + processorName + ", batteryCapacity=" + batteryCapacity + "]";
	}
	
	
	
	
	

}
