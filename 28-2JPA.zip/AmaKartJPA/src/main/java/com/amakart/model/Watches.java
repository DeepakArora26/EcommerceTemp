package com.amakart.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PrimaryKeyJoinColumn;

@Entity
@PrimaryKeyJoinColumn(referencedColumnName="productId")
public class Watches extends Product {

	@Id
	private String productId;
	private String dialColor;
	private String bandColor;
	private String caseMaterial;
	private String waterResistanceDepth;


	
	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getDialColor() {
		return dialColor;
	}

	public void setDialColor(String dialColor) {
		this.dialColor = dialColor;
	}

	public String getBandColor() {
		return bandColor;
	}

	public void setBandColor(String bandColor) {
		this.bandColor = bandColor;
	}

	public String getCaseMaterial() {
		return caseMaterial;
	}

	public void setCaseMaterial(String caseMaterial) {
		this.caseMaterial = caseMaterial;
	}

	public String getWaterResistanceDepth() {
		return waterResistanceDepth;
	}

	public void setWaterResistanceDepth(String waterResistanceDepth) {
		this.waterResistanceDepth = waterResistanceDepth;
	}

	@Override
	public String toString() {
		return "Watches [productId=" + productId + ", dialColor=" + dialColor + ", bandColor=" + bandColor
				+ ", caseMaterial=" + caseMaterial + ", waterResistanceDepth=" + waterResistanceDepth + "]";
	}

}
