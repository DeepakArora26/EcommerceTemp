package com.amakart.services;

import com.amakart.dao.ShoppingDaoService;
import com.amakart.dao.ShoppingDaoServiceImpl;
import com.amakart.model.Cart;
import com.amakart.model.CartProduct;
import com.amakart.model.Product;

public class CartServiceImpl implements CartService {

	
	CartProduct productInCart;
	ShoppingDaoService shopping;
	Product product;
	Cart cart = new Cart();
	
	
	
	
	
	@Override
	public void addToCart(String productId, int productQuantity) {


		shopping = new ShoppingDaoServiceImpl();
		
		product = new Product();
		
		product = shopping.getProductDetails(productId);
		
		productInCart = new CartProduct();
		
		productInCart.setProductId(product.getProductId());
		productInCart.setProductImage(product.getThumbNail());
		productInCart.setProductName(product.getProductName());
		productInCart.setProductPrice(product.getProductDiscountedPrice());
		productInCart.setProductPurchasedQuantity(productQuantity);
		productInCart.setProductTotalPrice();
		
		System.out.println(productInCart);
		
		Cart.cartItems.add(productInCart);
		
	
		
	}





	@Override
	public void calculateCartTotal() {
		
		Double cartTotal=0.0;
		
		for (CartProduct currentProduct : Cart.cartItems) {
			cartTotal = cartTotal + currentProduct.getProductTotalPrice();
        }
		
		cart.setCartTotal(cartTotal);
		
	}

}
