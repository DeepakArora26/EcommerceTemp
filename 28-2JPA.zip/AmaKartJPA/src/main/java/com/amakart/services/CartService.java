package com.amakart.services;

public interface CartService {
	
	
	void addToCart(String productId,int productQuantity);
	
	void calculateCartTotal();

}
