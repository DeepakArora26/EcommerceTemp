package com.amakart.dao;

public interface CheckoutDaoService {

}
