package com.amakart.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.amakart.services.ShoppingService;
import com.amakart.services.ShoppingServiceImpl;




@WebServlet("/DisplaySubCategories")
public class DisplaySubCategories extends HttpServlet {
	private static final long serialVersionUID = 1L;


	static ShoppingService shopping;
	static RequestDispatcher rd;
	
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		shopping = new ShoppingServiceImpl();
		
		request.setAttribute("subCategoryList", shopping.getSubCategoriesList(request.getParameter("categoryId")));
		
		rd = request.getRequestDispatcher("jsp/subCategories.jsp");
		
		rd.forward(request, response);
		
		
		
		
		
	}
	
	
	
	
	

}
