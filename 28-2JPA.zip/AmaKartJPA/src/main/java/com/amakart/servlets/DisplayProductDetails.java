package com.amakart.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.amakart.services.ShoppingService;
import com.amakart.services.ShoppingServiceImpl;



@WebServlet("/DisplayProductDetails")
public class DisplayProductDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	
	
	static ShoppingService shopping;
	static RequestDispatcher rd;
	
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		shopping = new ShoppingServiceImpl();
		
		request.setAttribute("productDetail", shopping.getProductDetails(request.getParameter("productId")));
		


		System.out.println("He"+request.getParameter("productId"));
		request.setAttribute("productImages", shopping.getProductsImagesList(request.getParameter("productId")));
		
		request.setAttribute("productSpecification", shopping.getProductSepcification(request.getParameter("productId")));
		
		rd = request.getRequestDispatcher("jsp/productDetails.jsp");
		
		rd.forward(request, response);
		
		
		
		
		
	}

}
