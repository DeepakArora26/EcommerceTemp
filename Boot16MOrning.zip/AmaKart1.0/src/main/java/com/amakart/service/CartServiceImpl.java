package com.amakart.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.amakart.model.Cart;
import com.amakart.model.CartItem;
import com.amakart.model.OrderItem;
import com.amakart.model.Orders;
import com.amakart.model.Product;
import com.amakart.repository.CartItemRepository;
import com.amakart.repository.CartRepository;
import com.amakart.repository.OrdersRepository;
import com.amakart.repository.ProductRepository;

@Service
public class CartServiceImpl implements CartService {

	@Autowired
	CartItem cartItem;

	@Autowired
	ProductRepository productRepository;

	@Autowired
	Product product;

	@Autowired
	OrderItem orderItem;

	@Autowired
	Orders order;

	@Autowired
	OrdersRepository orderRepository;

	@Autowired
	CartItemRepository cartItemRepository;

	@Autowired
	CartRepository cartRepository;

	@Autowired
	Cart cart;

	@Override
	public boolean addToCart(String productId, int productQuantity) {

		boolean flag = false;
		cart = cartRepository.findById(1).get();

		cartItem = new CartItem();

		if (productExistInCart(productId)) {

			int updateQuantity = productQuantity + checkExistingProductQuantity(productId);

			if (checkProductQuantity(productId, updateQuantity)) {

				cartItem = cartItemRepository.findById(productId).get();
				cartItem.setProductPurchasedQuantity(updateQuantity);
				cartItem.setProductTotalPrice();
				cartItemRepository.save(cartItem);
				
				calculateCartTotal();
				flag = true;
			}

		}

		else {

			if (checkProductQuantity(productId, productQuantity)) {

				product = productRepository.findByProductId(productId);

				cartItem.setProductId(product.getProductId());
				cartItem.setProductImage(product.getThumbnail());
				cartItem.setProductName(product.getProductName());
				cartItem.setProductPrice(product.getProductDiscountedPrice());
				cartItem.setProductPurchasedQuantity(productQuantity);
				cartItem.setProductTotalPrice();
				cartItem.setCart(cart);

				cartItemRepository.save(cartItem);
				calculateCartTotal();
				flag = true;

			}

		}

		
		return flag;
	}

	@Override
	public void calculateCartTotal() {

		Double cartTotal = 0.0;

		for (CartItem currentProduct : cart.getCartItems()) {

			cartTotal = cartTotal + currentProduct.getProductTotalPrice();
		}

		cart = cartRepository.findById(1).get();
		cart.setCartTotal(cartTotal);
		cartRepository.save(cart);

	}

	@Override
	public boolean checkProductQuantity(String productId, int productQuantity) {

		return (productRepository.findByProductId(productId).getProductAvailableStock() >= productQuantity);

	}

	@Override
	public boolean productExistInCart(String productId) {

		boolean result = false;

		Optional<CartItem> cartItem = cartItemRepository.findById(productId);

		if (cartItem.isPresent()) {
			result = true;
		}

		return result;

	}

	@Override
	public int checkExistingProductQuantity(String productId) {

		return cartItemRepository.findById(productId).get().getProductPurchasedQuantity();

	}

	@Override
	public Orders checkout() {

		cart = cartRepository.findById(1).get();

		for (CartItem productDetail : cart.getCartItems()) {

			orderItem = new OrderItem();
			orderItem.setProductId(productDetail.getProductId());
			orderItem.setProductImage(productDetail.getProductImage());
			orderItem.setProductName(productDetail.getProductName());
			orderItem.setProductPrice(productDetail.getProductPrice());
			orderItem.setProductPurchasedQuantity(productDetail.getProductPurchasedQuantity());
			orderItem.setProductTotalPrice(productDetail.getProductTotalPrice());
			order.addProduct(orderItem);
		}

		order.setCartTotal(cart.getCartTotal());
		long millis = System.currentTimeMillis();
		java.sql.Date date = new java.sql.Date(millis);

		order.setOrderDate(date);
		order.setCustomerId("Dummy Customer");

		orderRepository.save(order);

		cartRepository.deleteAll();
		return order;
	}

	@Override
	public Cart getCart() {

		return cartRepository.findById(1).get();
	}

}
