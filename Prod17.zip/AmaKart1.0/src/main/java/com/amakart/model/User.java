/*
 * package com.amakart.model;
 * 
 * import javax.persistence.Entity; import javax.persistence.Id; import
 * javax.persistence.OneToMany; import javax.persistence.OneToOne;
 * 
 * @Entity public class User {
 * 
 * @Id private String userId; private String password; private String Name;
 * 
 * @OneToOne private Cart cart;
 * 
 * @OneToMany private OrderHistory orderHistory;
 * 
 * 
 * }
 */