package com.amakart.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.amakart.model.ProductAttribute;

public interface ProductAttributeRepository extends JpaRepository<ProductAttribute, Integer> {
	
	
	

}
