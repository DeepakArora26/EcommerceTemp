package com.amakart.modeltest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.amakart.model.Cart;
import com.amakart.model.Category;

class CartTest {

	Cart cart;

	@BeforeEach
	void initialize() {
		cart = new Cart();
	}

	@Test
	void checkCartItemsWithNull() {

		assertEquals("[]", cart.getCartItems());

	}

	@Test
	void checkCartItemsWithValue() {

		//cart.setCartItems("1");
		assertEquals("1", cart.getCartItems());

	}

	@Test
	void checkCartTotalWithNull() {

		assertEquals(null, cart.getCartTotal());

	}

	@Test
	void checkCartTotalWithValue() {

		cart.setCartTotal(10252.3);
		assertEquals(10252.3, cart.getCartTotal());

	}
	
	@Test
	void checktoStringWithNull() {

		assertEquals("Cart [cartItems=[], cartTotal=10252.3]", cart.toString());

	}

	@Test
	void checktoStringWithValue() {

		cart.setCartTotal(10252.3);
		assertEquals("1Cart [cartItems=[], cartTotal=10252.3]", cart.toString());

	}
	
	
}
