package com.amakart.modeltest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.amakart.model.Category;

class CategoryTest {

	Category category;

	@BeforeEach
	void initialize() {
		category = new Category();
	}

	@Test
	void checkCategoryIdWithNull() {

		assertEquals(null, category.getCategoryId());

	}

	@Test
	void checkCategoryIdWithValue() {

		category.setCategoryId("1");
		assertEquals("1", category.getCategoryId());

	}

	@Test
	void checkCategoryNameWithNull() {

		assertEquals(null, category.getCategoryName());

	}

	@Test
	void checkCategoryNameWithValue() {

		category.setCategoryName("Electronics");
		assertEquals("Electronics", category.getCategoryName());

	}

	@Test
	void checkCategoryImageWithNull() {

		assertEquals(null, category.getCategoryImage());

	}

	@Test
	void checkCategoryImageWithValue() {

		category.setCategoryImage("Electronics.jpg");
		assertEquals("Electronics.jpg", category.getCategoryImage());

	}
	
	
	
	@Test
	void checktoStringWithNull() {

		assertEquals("Category [categoryId=null, categoryName=null, categoryImage=null]", category.toString());

	}

	@Test
	void checktoStringWithValue() {
		
		category.setCategoryId("1");
		category.setCategoryName("Electronics");
		category.setCategoryImage("Electronics.jpg");
		assertEquals("Category [categoryId=1, categoryName=Electronics, categoryImage=Electronics.jpg]", category.toString());

	}
	

}
