package com.amakart.servicestest;



import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.amakart.dao.ShoppingDaoServiceImpl;
import com.amakart.model.Category;
import com.amakart.model.Product;
import com.amakart.model.ProductImages;
import com.amakart.model.SubCategory;
import com.amakart.services.ShoppingServiceImpl;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
 
class ShoppingServiceImplTest {
	
	
	
	
	@Mock
	ShoppingDaoServiceImpl shoppingDao;	
	
	@Mock
	List<Category> categoryList;
	
	@Mock
	List<SubCategory> subCategoryList;
	
	@Mock
	List<Product> productList;
	
	@Mock
	List<ProductImages> productImagesList;
	
	@InjectMocks
	ShoppingServiceImpl shoppingService; 
	
	@Mock
	Product product;
	
	@BeforeEach
	void initialize() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	void checkgetCategoriesList() {

		
		Category cat = new Category();
		cat.setCategoryId("1");
		cat.setCategoryImage("abc");
		cat.setCategoryName("ab");
		categoryList = new ArrayList<>();
		categoryList.add(cat);
		
		when(shoppingDao.getCategories()).thenReturn(categoryList);
		assertEquals(categoryList,shoppingService.getCategoriesList());
	}
	

	
	
	@Test
	void checkgetSubCategoriesList() {

		
		SubCategory subcat = new SubCategory();
		subcat.setCategoryId("1");
		subcat.setSubCategoryId("EM");
		subcat.setSubCategoryImage("Electronics.jpg");
		subcat.setSubCategoryName("Electronics");
		subCategoryList.add(subcat);
		
		when(shoppingDao.getSubCategories("1")).thenReturn(subCategoryList);
		assertEquals(subCategoryList,shoppingService.getSubCategoriesList("1"));
	}
	
	
	
	
	@Test
	void checkgetProductsList() {

		
		Product product = new Product();
		product.setProductAvailableStock(20);
		product.setProductAverageRating(3.0);
		product.setProductDiscountedPrice(15999.0);
		product.setProductId("EM1");
		product.setProductMRP(20000.0);
		product.setSubCategoryId("EM");
		product.setThumbNail("RedmiNote8.jpg");
		
		
		when(shoppingDao.getProducts("EM")).thenReturn(productList);
		assertEquals(productList,shoppingService.getProductsList("EM"));
	}
	
	
	
	
	@Test
	void checkgetProductDetails() {
		
		product.setProductAvailableStock(20);
		product.setProductAverageRating(3.0);
		product.setProductDiscountedPrice(15999.0);
		product.setProductId("EM1");
		product.setProductMRP(20000.0);
		product.setSubCategoryId("EM");
		product.setThumbNail("RedmiNote8.jpg");
		
		when(shoppingDao.getProductDetails("EM1")).thenReturn(product);
		assertEquals(product,shoppingService.getProductDetails("EM1"));
	}
	
	
	@Test
	void checkgetProductsImagesList() {
		
		
		ProductImages productImages = new ProductImages();
		
		productImages.setImageId("EM11");
		productImages.setProductId("EM1");
		productImages.setProductImage("RedmiNote8.jpg");
		
		productImagesList.add(productImages);
		
		when(shoppingDao.getProductImages("EM1")).thenReturn(productImagesList);
		assertEquals(productImagesList,shoppingService.getProductsImagesList("EM1"));
	}
	
	
	
	
}
