package com.amakart.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.QueryHint;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.amakart.model.Category;
import com.amakart.model.Mobile;
import com.amakart.model.Product;
import com.amakart.model.ProductImages;
import com.amakart.model.SubCategory;

public class ShoppingDaoServiceImpl implements ShoppingDaoService {

	EntityManagerFactory emFactory = Persistence.createEntityManagerFactory("my-local-mysql");

	EntityManager eManager;

	@Override
	public List<Category> getCategories() {

		eManager = emFactory.createEntityManager();

		CriteriaBuilder cb = eManager.getCriteriaBuilder();
		CriteriaQuery<Category> cq = cb.createQuery(Category.class);
		Root<Category> rootEntry = cq.from(Category.class);
		CriteriaQuery<Category> all = cq.select(rootEntry);

		TypedQuery<Category> allQuery = eManager.createQuery(all);
		return allQuery.getResultList();

	}

	@Override
	public List<SubCategory> getSubCategories(String categoryId) {

		eManager = emFactory.createEntityManager();
		Query query = eManager.createNamedQuery("find employee by categoryId");
		query.setParameter("categoryId", categoryId);
		List<SubCategory> sub = query.getResultList();
		return sub;

	}

	@Override
	public List<Product> getProducts(String subCategoryId) {

		eManager = emFactory.createEntityManager();
		Query query = eManager.createNamedQuery("find employee by subCategoryId");
		query.setParameter("subCategoryId", subCategoryId);
		List<Product> sub = query.getResultList();
		return sub;
	}

	@Override
	public Product getProductDetails(String productId) {

		eManager = emFactory.createEntityManager();

		Product productDetail = eManager.find(Product.class, productId);

		return productDetail;
	}

	@Override
	public List<ProductImages> getProductImages(String productId) {

		eManager = emFactory.createEntityManager();
		Query query = eManager.createNamedQuery("find employee by productIds");
		query.setParameter("productId", productId);
		List<ProductImages> sub = query.getResultList();
		return sub;
	}

	@Override
	public List<? extends Product> getProductSpecification(String productId) {
		
		
		eManager = emFactory.createEntityManager();

		Query query = eManager.createNamedQuery("find subcategoryName by productId");
		query.setParameter("productId", productId);

		String subCategoryId = query.getResultList().get(0).toString();
		Query query1 = eManager.createNamedQuery("find subcatname by subcategoryId");
		query1.setParameter("subCategoryId", subCategoryId);

		
		String subCategoryName = query1.getResultList().get(0).toString();
		
		/*
		 * Query qu = eManager .createNativeQuery("select * from " + subCategoryName +
		 * " where productId = '" + productId + "'");
		 * 
		 * System.out.println("hello"+qu.getResultList());
		 * 
		 * List<? extends Product> a = qu.getResultList();
		 */
		Query query2 = eManager.createQuery("from "+subCategoryName+" where productId='"+productId+"'");
		System.out.println(query2.getResultList());
		List<? extends Product> a = query2.getResultList();
		System.out.println(a);
		return a;
	}
	

}
