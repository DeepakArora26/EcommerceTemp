package com.amakart.dao;

import java.util.List;

import com.amakart.model.Category;
import com.amakart.model.Product;
import com.amakart.model.ProductImages;
import com.amakart.model.SubCategory;

public interface ShoppingDaoService {

	List<Category> getCategories();

	List<SubCategory> getSubCategories(String categoryId);

	List<Product> getProducts(String subCategoryId);

	Product getProductDetails(String productId);

	List<ProductImages> getProductImages(String productId);
	
	List<? extends Product> getProductSpecification(String productId);

}
