package com.amakart.services;

import java.util.ArrayList;
import java.util.List;

import com.amakart.dao.ShoppingDaoService;
import com.amakart.dao.ShoppingDaoServiceImpl;
import com.amakart.model.Category;
import com.amakart.model.Product;
import com.amakart.model.ProductImages;
import com.amakart.model.SubCategory;

public class ShoppingServiceImpl implements ShoppingService {
	
	
	ShoppingDaoService shoppingDao ;
	List<Category> categoryList;
	List<SubCategory> subCategoryList;
	List<Product> productList;
	Product productDetails;
	List<ProductImages> productImagesList;
	String subCategoryName;
	
	
	

	public ShoppingServiceImpl() {
		shoppingDao = new ShoppingDaoServiceImpl();
	}



	@Override
	public List<Category> getCategoriesList() {
		
		
		categoryList = new ArrayList<>();

		categoryList = shoppingDao.getCategories();

		System.out.println(categoryList);
		
		return categoryList;
	}



	@Override
	public List<SubCategory> getSubCategoriesList(String categoryId) {
		
		
		subCategoryList = new ArrayList<>();

		subCategoryList = shoppingDao.getSubCategories(categoryId);

		System.out.println(subCategoryList);
		
		return subCategoryList;
	}



	@Override
	public List<Product> getProductsList(String subCategoryId) {
		
		
		productList = new ArrayList<>();

		productList = shoppingDao.getProducts(subCategoryId);

		System.out.println(productList);
		
		return productList;
	}




	@Override
	public Product getProductDetails(String productId) {
		
		
		productDetails = new Product();

		productDetails = shoppingDao.getProductDetails(productId);

		System.out.println(productImagesList);
		
		return productDetails;
	}

	


	@Override
	public List<ProductImages> getProductsImagesList(String productId) {
		
		
		productImagesList = new ArrayList<>();

		productImagesList = shoppingDao.getProductImages(productId);

		System.out.println(productImagesList);
		
		return productImagesList;
	}



	@Override
	public List<? extends Product> getProductSepcification(String productId) {
		
		shoppingDao = new ShoppingDaoServiceImpl();
		
		return shoppingDao.getProductSpecification(productId);

		
	}



	
	



	
	
}
