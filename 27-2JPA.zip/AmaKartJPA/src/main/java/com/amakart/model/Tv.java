package com.amakart.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PrimaryKeyJoinColumn;


@Entity
@PrimaryKeyJoinColumn(referencedColumnName="productId")
public class Tv extends Product {
	
	@Id
	private String productId;
	private String screenSize;
	private String resolution;
	private String refreshRate;
	private String noOfHDMIPorts;
	private String noOfUSBPorts;
	
	
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	
	public String getScreenSize() {
		return screenSize;
	}
	public void setScreenSize(String screenSize) {
		this.screenSize = screenSize;
	}
	public String getResolution() {
		return resolution;
	}
	public void setResolution(String resolution) {
		this.resolution = resolution;
	}
	public String getRefreshRate() {
		return refreshRate;
	}
	public void setRefreshRate(String refreshRate) {
		this.refreshRate = refreshRate;
	}
	public String getNoOfHDMIPorts() {
		return noOfHDMIPorts;
	}
	public void setNoOfHDMIPorts(String noOfHDMIPorts) {
		this.noOfHDMIPorts = noOfHDMIPorts;
	}
	public String getNoOfUSBPorts() {
		return noOfUSBPorts;
	}
	public void setNoOfUSBPorts(String noOfUSBPorts) {
		this.noOfUSBPorts = noOfUSBPorts;
	}
	

	@Override
	public String toString() {
		return "Tv [productId=" + productId + ", screenSize=" + screenSize + ", resolution=" + resolution
				+ ", refreshRate=" + refreshRate + ", noOfHDMIPorts=" + noOfHDMIPorts + ", noOfUSBPorts=" + noOfUSBPorts
				+ "]";
	}
	
				

}
