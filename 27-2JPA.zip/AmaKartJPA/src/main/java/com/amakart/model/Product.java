package com.amakart.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;

@Entity
@NamedQuery(query = "Select e from Product e where e.subCategoryId = :subCategoryId", name = "find employee by subCategoryId")
@NamedQuery(query = "Select e.subCategoryId from Product e where e.productId = :productId", name = "find subcategoryName by productId")
@Inheritance( strategy = InheritanceType.JOINED )
public class Product {

	
	
	@Id
	private String productId;
	private String subCategoryId;
	private String productName;
	private Double productMRP;
	private Double productDiscountedPrice;
	private int productAvailableStock;
	private Double productAverageRating;
	private String thumbNail;

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getSubCategoryId() {
		return subCategoryId;
	}

	public void setSubCategoryId(String subCategoryId) {
		this.subCategoryId = subCategoryId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public Double getProductMRP() {
		return productMRP;
	}

	public void setProductMRP(Double productMRP) {
		this.productMRP = productMRP;
	}

	public Double getProductDiscountedPrice() {
		return productDiscountedPrice;
	}

	public void setProductDiscountedPrice(Double productDiscountedPrice) {
		this.productDiscountedPrice = productDiscountedPrice;
	}

	public int getProductAvailableStock() {
		return productAvailableStock;
	}

	public void setProductAvailableStock(int productAvailableStock) {
		this.productAvailableStock = productAvailableStock;
	}

	public Double getProductAverageRating() {
		return productAverageRating;
	}

	public void setProductAverageRating(Double productAverageRating) {
		this.productAverageRating = productAverageRating;
	}

	
	
	public String getThumbNail() {
		return thumbNail;
	}

	public void setThumbNail(String thumbNail) {
		this.thumbNail = thumbNail;
	}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", subCategoryId=" + subCategoryId + ", productName=" + productName
				+ ", productMRP=" + productMRP + ", productDiscountedPrice=" + productDiscountedPrice
				+ ", productAvailableStock=" + productAvailableStock + ", productAverageRating=" + productAverageRating
				+ ", thumbNail=" + thumbNail + "]";
	}

}
