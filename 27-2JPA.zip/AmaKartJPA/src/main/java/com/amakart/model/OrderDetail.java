package com.amakart.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class OrderDetail {

	
	
	@Id
	private String orderId;
	private String productName;
	private int productPurchasedQuantity;
	private Double productPerQuantityPrice;
	private Double productTotalPrice;

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getProductPurchasedQuantity() {
		return productPurchasedQuantity;
	}

	public void setProductPurchasedQuantity(int productPurchasedQuantity) {
		this.productPurchasedQuantity = productPurchasedQuantity;
	}

	public Double getProductPerQuantityPrice() {
		return productPerQuantityPrice;
	}

	public void setProductPerQuantityPrice(Double productPerQuantityPrice) {
		this.productPerQuantityPrice = productPerQuantityPrice;
	}

	public Double getProductTotalPrice() {
		return productTotalPrice;
	}

	public void setProductTotalPrice(Double productTotalPrice) {
		this.productTotalPrice = productTotalPrice;
	}

	@Override
	public String toString() {
		return "OrderDetail [orderId=" + orderId + ", productname=" + productName + ", productPurchasedQuantity="
				+ productPurchasedQuantity + ", productPerQuantityPrice=" + productPerQuantityPrice
				+ ", productTotalPrice=" + productTotalPrice + "]";
	}

}
