package com.amakart.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.amakart.model.Cart;
import com.amakart.services.CartService;
import com.amakart.services.CartServiceImpl;


@WebServlet("/cart")
public class DisplayCart extends HttpServlet {
	private static final long serialVersionUID = 1L;

	static CartService cartService;
	static RequestDispatcher rd;
	Cart cart = new Cart();
	

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		cartService = new CartServiceImpl();
		cartService.calculateCartTotal();

		request.setAttribute("Cart", Cart.cartItems);
		request.setAttribute("CartTotal", cart.getCartTotal());
		rd = request.getRequestDispatcher("jsp/cart.jsp");
		rd.forward(request, response);

	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		
		
		
		
		rd = request.getRequestDispatcher("jsp/cart.jsp");

		rd.forward(request, response);

	}

}
