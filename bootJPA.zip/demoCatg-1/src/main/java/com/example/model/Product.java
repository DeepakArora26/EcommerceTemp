package com.example.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Product {

	@Id
	private String productId;
	private String subCategoryId;
	private String productName;
	private Double productMRP;
	private Double productDiscountedPrice;
	private int productAvailableStock;
	private Double productAverageRating;
	private String thumbNail;
	@OneToMany(mappedBy="product", fetch=FetchType.EAGER)
	private List<ProductAttribute> attrbiutes;
	@ElementCollection
	private List<String> productImages;

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getSubCategoryId() {
		return subCategoryId;
	}

	public void setSubCategoryId(String subCategoryId) {
		this.subCategoryId = subCategoryId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public Double getProductMRP() {
		return productMRP;
	}

	public void setProductMRP(Double productMRP) {
		this.productMRP = productMRP;
	}

	public Double getProductDiscountedPrice() {
		return productDiscountedPrice;
	}

	public void setProductDiscountedPrice(Double productDiscountedPrice) {
		this.productDiscountedPrice = productDiscountedPrice;
	}

	public int getProductAvailableStock() {
		return productAvailableStock;
	}

	public void setProductAvailableStock(int productAvailableStock) {
		this.productAvailableStock = productAvailableStock;
	}

	public Double getProductAverageRating() {
		return productAverageRating;
	}

	public void setProductAverageRating(Double productAverageRating) {
		this.productAverageRating = productAverageRating;
	}

	public String getThumbNail() {
		return thumbNail;
	}

	public void setThumbNail(String thumbNail) {
		this.thumbNail = thumbNail;
	}

	public List<ProductAttribute> getAttrbiutes() {
		return attrbiutes;
	}

	public void setAttrbiutes(List<ProductAttribute> attrbiutes) {
		this.attrbiutes = attrbiutes;
	}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", subCategoryId=" + subCategoryId + ", productName=" + productName
				+ ", productMRP=" + productMRP + ", productDiscountedPrice=" + productDiscountedPrice
				+ ", productAvailableStock=" + productAvailableStock + ", productAverageRating=" + productAverageRating
				+ ", thumbNail=" + thumbNail + ", attrbiutes=" + attrbiutes + "]";
	}

}
