package com.amakart.restcontroller;

import com.amakart.exception.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.amakart.service.CartService;
import com.amakart.service.ShoppingService;

@RestController
@RequestMapping("/amakart")
@Api(value="User Resource", description = "Rest EndPoints Related to Shopping for a User")
public class RestUserController {

	private static final Logger LOGGER = LogManager.getLogger(RestUserController.class);

	@Autowired
	ShoppingService shopping;

	@Autowired
	CartService cartService;

	@SuppressWarnings("rawtypes")
	@ApiOperation(value = "Returns All The Categories Present")
	@GetMapping("/categories")
	public ResponseEntity displayCategories() throws CategoriesNotFoundException {

		return ResponseEntity.ok().body(shopping.getCategories());

	}

	@SuppressWarnings("rawtypes")
	@ApiOperation(value = "Returns All The Sub Categories Present Under the Category with Id Provided")
	@GetMapping("categories/{id}")
	public ResponseEntity displaySubCategories(@PathVariable(value = "id") int parentId) throws CategoryNotFoundException, SubCategoriesNotFoundException {

			return ResponseEntity.ok().body(shopping.getSubCategories(parentId));
	}

	@SuppressWarnings("rawtypes")
	@ApiOperation(value = "Returns All Products Present Under the SubCategory with Id Provided")
	@GetMapping("products/{subCategoryid}")
	public ResponseEntity displayProducts(@PathVariable(value = "subCategoryid") int subcategoryId)
			throws ProductNotFoundException, SubCategoryNotFoundException {

		return ResponseEntity.ok().body(shopping.getProducts(subcategoryId));

	}

	@SuppressWarnings("rawtypes")
	@ApiOperation(value = "Adds the Product with Id to the Cart")
	@PostMapping("/cart/product/{productId}")
	public ResponseEntity addProductToCart(@PathVariable(value = "productId") String productId,
			@RequestParam int productQuantity) throws InsufficientQuantityException, ProductNotFoundException, ProductNotInCartException, InvalidQuantityException {

		cartService.addToCart(productId, productQuantity);

		return ResponseEntity.status(201).body("Successfully Added");

	}

	@SuppressWarnings("rawtypes")
	@ApiOperation(value = "Removes the Product with Id from the Cart")
	@DeleteMapping("/cart/product/{productId}")
	public ResponseEntity removeProductFromCart(@PathVariable(value = "productId") String productId) throws ProductNotInCartException {


		cartService.deleteCartItem(productId);

		return ResponseEntity.ok().body("Product Removed Successfully");

	}

	@SuppressWarnings("rawtypes")
	@ApiOperation(value = "Updates the Product with ID and the Updated Quantity in the Cart")
	@PutMapping("/cart/product/{productId}")
	public ResponseEntity updateCart(@PathVariable(value = "productId") String productId,
			@RequestParam int updatedProductQuantity) throws InsufficientQuantityException, ProductNotFoundException, ProductNotInCartException, InvalidQuantityException {


		cartService.updateProductQuantity(productId, updatedProductQuantity);

		return ResponseEntity.ok().body("Product Updated Successfully");

	}

	@SuppressWarnings("rawtypes")
	@ApiOperation(value = "Returns All The Items Present In Cart")
	@GetMapping("/cart")
	public ResponseEntity showCart() {

		Double cartTotal = cartService.getCart().getCartTotal();

		if (cartTotal == 0.0) {
			throw new EmptyCartException("Cart Is Empty");
		}

		return ResponseEntity.ok().body(cartService.getCart().getCartItems());

	}

	@SuppressWarnings("rawtypes")
	@GetMapping("/checkout")
	@ApiOperation(value = "Does the Checkout and Returns the Order Details")
	public ResponseEntity checkout() throws InsufficientQuantityException {

		return ResponseEntity.ok().body(cartService.checkout());
	}

}
