package com.amakart.service;

import com.amakart.exception.*;
import com.amakart.repository.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.amakart.model.Cart;
import com.amakart.model.CartItem;
import com.amakart.model.OrderItem;
import com.amakart.model.Orders;
import com.amakart.model.Product;

@Service
public class CartServiceImpl implements CartService {

	private static final Logger LOGGER = LogManager.getLogger(CartServiceImpl.class);

	@Autowired
	CartItem cartItem;

	@Autowired
	ProductRepository productRepository;

	@Autowired
	Product product;

	@Autowired
	OrderItem orderItem;

	@Autowired
	Orders order;

	@Autowired
	OrdersRepository orderRepository;

	@Autowired
	CartItemRepository cartItemRepository;

	@Autowired
	CartRepository cartRepository;

	@Autowired
	Cart cart;



	@Override
	public boolean addToCart(String productId, int productQuantity)
			throws InsufficientQuantityException, ProductNotFoundException, InvalidQuantityException, ProductNotInCartException {

		LOGGER.info("--------In Add To Cart Function----------");

		validateProductQuantity(productQuantity);

		validateProduct(productId);


		boolean flag = false;

		cart = getCart();

		cartItem = new CartItem();

		if (productExistInCart(productId)) {

			LOGGER.info("--------Product Exists In Cart----------");

			productQuantity += checkExistingProductQuantity(productId);

			flag = updateProductQuantity(productId, productQuantity);
		}

		else {

			LOGGER.info("--------Adding New Product To Cart----------");
			flag = addNewProduct(productId, productQuantity);

		}

		calculateCartTotal();

		return flag;
	}

	public void validateProduct(String productId) throws ProductNotFoundException {

		LOGGER.info("--------In Validate Product Function----------");

		if(!productRepository.findById(productId).isPresent())
		{

			LOGGER.info("--------Product Not Found Exception In Validate Product Function----------");

			throw new ProductNotFoundException("Product Not Found.");
		}
	}

	public void validateProductQuantity(int productQuantity) throws InvalidQuantityException {


		LOGGER.info("--------In Validate Product Quantity Function----------");

		if (productQuantity <= 0) {

			LOGGER.info("--------Invalid Quantity Exception In Validate Product Quantity Function----------");

			throw new InvalidQuantityException("Quantity Cannot be <=0");
		}
	}

	@Override
	public void calculateCartTotal() {

		LOGGER.info("--------In Calculate Cart Total Function----------");

		Double cartTotal = 0.0;

		for (CartItem currentProduct : cartItemRepository.findAll()) {

			cartTotal = cartTotal + currentProduct.getProductTotalPrice();
		}

		cart.setCartTotal(cartTotal);
		cartRepository.save(cart);

	}

	@Override
	public boolean checkProductQuantity(String productId, int productQuantity) {

		LOGGER.info("--------In Check Product Quantity Function----------");

		return (productRepository.findByProductId(productId).getProductAvailableStock() >= productQuantity);

	}

	@Override
	public boolean productExistInCart(String productId) throws ProductNotInCartException {

		LOGGER.info("--------In Product Exist In Cart Function----------");

		boolean result = false;

		if (cartItemRepository.findById(productId).isPresent()) {

			LOGGER.info("--------Product Exist In Cart----------");

			result = true;
		}


		return result;

	}

	@Override
	public int checkExistingProductQuantity(String productId) {

		LOGGER.info("--------In Check Existing Product Quantity Function----------");

		return cartItemRepository.findById(productId).get().getProductPurchasedQuantity();

	}

	@Override
	public Orders checkout() {

		LOGGER.info("--------In Checkout Function----------");

		cart = getCart();

		validateEmptyCart();

		order = new Orders();

		for (CartItem productDetail : cart.getCartItems()) {

				convertCartItemToOrder(productDetail);
		}

		order.setCartTotal(cart.getCartTotal());
		long millis = System.currentTimeMillis();
		java.sql.Date date = new java.sql.Date(millis);

		order.setOrderDate(date);
		order.setCustomerId(cart.getUserId());

		orderRepository.save(order);

		cartItemRepository.deleteAll();
		cartRepository.deleteAll();

		cart = new Cart();
		cartItem = new CartItem();
		initializeCart();
		return order;
	}

	public void convertCartItemToOrder(CartItem productDetail) {


		LOGGER.info("--------In Convert Cart Item To Order Function----------");


		orderItem = new OrderItem();

		product = productRepository.findByProductId(productDetail.getProductId());
		orderItem.setProductId(productDetail.getProductId());
		orderItem.setProductImage(productDetail.getProductImage());
		orderItem.setProductName(productDetail.getProductName());
		orderItem.setProductPrice(productDetail.getProductPrice());
		orderItem.setProductPurchasedQuantity(productDetail.getProductPurchasedQuantity());
		orderItem.setProductTotalPrice(productDetail.getProductTotalPrice());
		order.addProduct(orderItem);
		product.setProductAvailableStock(product.getProductAvailableStock() - orderItem.getProductPurchasedQuantity());
	}


	public void validateEmptyCart() {


		LOGGER.info("--------In Validate Empty Cart Function----------");


		if(cart.getCartTotal() == 0.0)
		{
			LOGGER.info("--------Empty Cart Exception In Checkout Function----------");

			throw new EmptyCartException("Cart Is Empty");
		}
	}

	@Override
	public Cart getCart() {

		LOGGER.info("--------In Get Cart Function----------");

		if (cartRepository.findById(1) == null) {

			initializeCart();
		
		}
		
		return cartRepository.findById(1);
		
	}
	
	
	@Override
	public void initializeCart() {

		LOGGER.info("--------In Initialize Cart Function----------");

		cart.setCartId(1);
		cart.setCartTotal(0.0);
		cart.setUserId("Dummy User");
		cartRepository.save(cart);

	}

	@Override
	public boolean deleteCartItem(String productId) throws ProductNotInCartException {

		LOGGER.info("--------In Delete Cart Item Function----------");

			if(!productExistInCart(productId))
			{
				throw new ProductNotInCartException("Product With Given Id Is Not Present In Cart.");
			}

			cartItemRepository.deleteById(productId);
			calculateCartTotal();




		return true;
	}

	@Override
	public boolean updateProductQuantity(String productId, int productQuantity) throws InsufficientQuantityException, ProductNotInCartException, InvalidQuantityException {

		LOGGER.info("--------In Update Product Quantity Function----------");


		validateProductQuantity(productQuantity);

		validateCartProduct(productId);

		if (checkProductQuantity(productId, productQuantity)) {

			cartItem = cartItemRepository.findById(productId).get();
			cartItem.setProductPurchasedQuantity(productQuantity);
			cartItem.setProductTotalPrice();
			cartItemRepository.save(cartItem);

		}

		else {

			LOGGER.error("--------Insufficient Quantity Exception In Update Product Quantity Function----------");

			throw new InsufficientQuantityException("Desired Quantity Not Available");

		}

		return true;

	}

	public void validateCartProduct(String productId) throws ProductNotInCartException {

		LOGGER.info("--------In Validate Cart Product Function----------");


		if(!productExistInCart(productId))
		{
			LOGGER.info("-------- Product Not In Cart Exception In Update Product Quantity Function----------");

			throw new ProductNotInCartException("Product With Given Id Is Not Present In Cart.");
		}
	}

	@Override
	public boolean addNewProduct(String productId, int productQuantity) throws InsufficientQuantityException {

		LOGGER.info("--------In Add New Product Funtion----------");

		if (checkProductQuantity(productId, productQuantity)) {

			product = productRepository.findByProductId(productId);
			cartItem.setProductId(product.getProductId());
			cartItem.setProductImage(product.getThumbnail());
			cartItem.setProductName(product.getProductName());
			cartItem.setProductPrice(product.getProductDiscountedPrice());
			cartItem.setProductPurchasedQuantity(productQuantity);
			cartItem.setProductTotalPrice();
			cartItem.setCart(cart);
			cartItemRepository.save(cartItem);

		}

		else {

			LOGGER.error("--------Required Quantity Is Not Available In Stock----------");

			throw new InsufficientQuantityException("Desired Quantity Not Available");

		}

		return true;
	}

}
