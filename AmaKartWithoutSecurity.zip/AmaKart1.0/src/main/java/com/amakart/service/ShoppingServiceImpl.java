package com.amakart.service;

import java.util.List;

import com.amakart.exception.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.amakart.model.Category;
import com.amakart.model.Product;
import com.amakart.repository.CategoryRepository;
import com.amakart.repository.ProductRepository;

@Service
public class ShoppingServiceImpl implements ShoppingService {

    private static final Logger LOGGER = LogManager.getLogger(ShoppingServiceImpl.class);

    @Autowired
    CategoryRepository categoryRepository;

    @Autowired
    ProductRepository productRepository;

    @Override
    public List<Category> getCategories() throws CategoriesNotFoundException {

        LOGGER.info("--------In Get Categories Function----------");

        List<Category> categories = categoryRepository.findByparentId(0);

        if (categories.isEmpty()) {

            LOGGER.error("--------Categories Not Found Exception Thrown----------");

            throw new CategoriesNotFoundException("Categories Not Found");

        }

        return categories;

    }


    @Override
    public List<Category> getSubCategories(int parentId) throws SubCategoriesNotFoundException, CategoryNotFoundException {

        LOGGER.info("--------In Get Sub-Categories Function----------");


        if (isCategoryInvalid(parentId)) {

            LOGGER.info("--------Category Not Found Exception In Get Sub-Categories Function----------");

            throw new CategoryNotFoundException("Category Not Found");

        }

        List<Category> categories = categoryRepository.findByparentId(parentId);

        if (categories.isEmpty()) {

            LOGGER.error("--------Sub-Categories Not Found Exception In Get Sub-Categories Function----------");

            throw new SubCategoriesNotFoundException("Sub-Categories Not Found");

        }

        return categories;

    }

    @Override
    public boolean isCategoryInvalid(int parentId) {

        LOGGER.error("--------In Is Category Invalid Function----------");


        boolean result = false;


        if (categoryRepository.findCategory(parentId) == null) {


            LOGGER.error("--------Category Invalid ----------");

            result = true;

        }

        return result;

    }

    @Override
    public List<Product> getProducts(int subCategoryId) throws ProductNotFoundException, SubCategoryNotFoundException {

        LOGGER.info("--------In Get Products Function----------");

        Category category = categoryRepository.findById(subCategoryId);

        if (category == null) {
            LOGGER.info("--------Sub Category Not Found Exception In Get Products Function----------");

            throw new SubCategoryNotFoundException("Sub Category Not Found WIth Given Id");
        }

        List<Product> productList = category.getProducts();

        if (productList.isEmpty()) {

            LOGGER.error("--------Product Not Found Exception In Get Products Function----------");

            throw new ProductNotFoundException("Products Not Found");

        }

        return productList;

    }

    @Override
    public Product getProductDetail(String productId) throws ProductNotFoundException {

        LOGGER.info("--------In Get Product Details Function----------");

        Product product = productRepository.findByProductId(productId);

        if (product == null) {

            LOGGER.error("--------Product Not Found Exception In Get Product Details Function----------");

            throw new ProductNotFoundException("Products Not Found");

        }

        return product;
    }

    @Override
    public String getCategoryName(int id) {

        LOGGER.info("--------In Get Category Name Function----------");

        return categoryRepository.findById(id).getName();

    }


    @Override
    public Category getFirstPromotedCategory() throws FirstPromotedCategoryNotFoundException {

        LOGGER.info("--------In Get First Promoted Category Function----------");

        Category category = categoryRepository.findFirstPromotedCategory();

        if (category == null) {

            LOGGER.info("--------First Promoted Category Not Found Returning First Category----------");

            category = categoryRepository.findFirstCategory();

            if (category == null) {
                LOGGER.info("--------First Promoted Category Not Found Exception In Get First Promoted Category Function----------");

                throw new FirstPromotedCategoryNotFoundException("No Category Found");
            }
        }

        return category;
    }

    @Override
    public List<Category> getFirstPromotedSubCategories() throws SubCategoriesNotFoundException, CategoryNotFoundException, FirstPromotedCategoryNotFoundException {

        LOGGER.info("--------In Get First Promoted Sub Categories Function----------");

        return getSubCategories(getFirstPromotedCategory().getId());

    }



    @Override
    public String getCategoryNameOfSubCategory(int subCategoryId) {


        LOGGER.info("--------In Get Category Name Of Sub Category Function----------");

        int id = categoryRepository.findById(subCategoryId).getParentId();

        return categoryRepository.findById(id).getName();

    }

    @Override
    public String getSubCategoryNameFromProductId(String productId) {


        LOGGER.info("--------In Get Sub Category Name From ProductId Function----------");


        return productRepository.findById(productId).get().getCategory().getName();

    }

    @Override
    public String getCategoryNameFromProductId(String productId) {


        LOGGER.info("--------In Get Category Name From ProductId Function----------");

        int categoryId = productRepository.findById(productId).get().getCategory().getParentId();

        return getCategoryName(categoryId);

    }

}
