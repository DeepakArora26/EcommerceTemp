package com.amakart.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Component
public class OrderItem {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int productOrderNo;
	private String productId;
	private String productName;
	private Double productPrice;
	@Column(columnDefinition = "INT(11) UNSIGNED")
	private int productPurchasedQuantity;
	private Double productTotalPrice;
	@ManyToOne
	@JoinColumn(name = "orderNo")
	@JsonBackReference
	private Orders orderHistory;
	private String productImage;

	public int getProductOrderNo() {
		return productOrderNo;
	}

	public void setProductOrderNo(int productOrderNo) {
		this.productOrderNo = productOrderNo;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public Double getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(Double productPrice) {
		this.productPrice = productPrice;
	}

	public int getProductPurchasedQuantity() {
		return productPurchasedQuantity;
	}

	public void setProductPurchasedQuantity(int productPurchasedQuantity) {
		this.productPurchasedQuantity = productPurchasedQuantity;
	}

	public Double getProductTotalPrice() {
		return productTotalPrice;
	}

	public void setProductTotalPrice(Double productTotalPrice) {
		this.productTotalPrice = productTotalPrice;
	}

	public Orders getOrderHistory() {
		return orderHistory;
	}

	public void setOrderHistory(Orders orderHistory) {
		this.orderHistory = orderHistory;
	}

	public String getProductImage() {
		return productImage;
	}

	public void setProductImage(String productImage) {
		this.productImage = productImage;
	}

	@Override
	public String toString() {
		return "OrderDetails [productOrderNo=" + productOrderNo + ", productId=" + productId + ", productName="
				+ productName + ", productPrice=" + productPrice + ", productPurchasedQuantity="
				+ productPurchasedQuantity + ", productTotalPrice=" + productTotalPrice + ", productImage="
				+ productImage + "]";
	}


}
