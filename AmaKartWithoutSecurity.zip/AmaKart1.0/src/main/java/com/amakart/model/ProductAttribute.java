package com.amakart.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Component
public class ProductAttribute {

	@ManyToOne
	@JoinColumn(name = "productId")
	@JsonManagedReference
	private Product product;
	@Id
	@GeneratedValue
	private int attributeId;
	private String attributeName;
	private String attributeValue;

	public ProductAttribute() {
		super();
	}


	public ProductAttribute(String attributeName, String attributeValue) {
		super();
		this.attributeName = attributeName;
		this.attributeValue = attributeValue;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public int getAttributeId() {
		return attributeId;
	}

	public void setAttributeId(int attributeId) {
		this.attributeId = attributeId;
	}

	public String getAttributeName() {
		return attributeName;
	}

	public void setAttributeName(String attributeName) {
		this.attributeName = attributeName;
	}

	public String getAttributeValue() {
		return attributeValue;
	}

	public void setAttributeValue(String attributeValue) {
		this.attributeValue = attributeValue;
	}

	@Override
	public String toString() {
		return "ProductAttribute [attributeId=" + attributeId + ", attributeName="
				+ attributeName + ", attributeValue=" + attributeValue + "]";
	}

	
	
	
}