package com.amakart.exception;

public class FirstPromotedCategoryNotFoundException extends Exception {
    public FirstPromotedCategoryNotFoundException(String message) {
        super(message);
    }
}
