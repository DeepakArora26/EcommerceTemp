package com.amakart.exception;

@SuppressWarnings("serial")
public class EmptyCartException extends RuntimeException {

	public EmptyCartException(String message) {
		super(message);
	}

}
