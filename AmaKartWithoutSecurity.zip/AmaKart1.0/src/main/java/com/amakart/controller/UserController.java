package com.amakart.controller;

import com.amakart.exception.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;

import com.amakart.service.CartService;
import com.amakart.service.ShoppingService;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.io.IOException;

@Controller
public class UserController {

    private static final Logger LOGGER = LogManager.getLogger(UserController.class);

    @Autowired
    ShoppingService shopping;

    @Autowired
    CartService cartService;

    @GetMapping("/")
    public ModelAndView showHome(ModelAndView modelAndView) throws CategoryNotFoundException {

        LOGGER.info("--------In showHome Controller----------");

		modelAndView.setViewName("Home");

        try {

			modelAndView.addObject("firstPromotedCategory", shopping.getFirstPromotedCategory());

			modelAndView.addObject("firstPromotedSubcategories", shopping.getFirstPromotedSubCategories());

			modelAndView.addObject("FirstPromoSubCatMessage", "Available");


        }
        catch (FirstPromotedCategoryNotFoundException e) {

			LOGGER.error("--------First Promoted Category Not Found Exception in showHome Controller----------");

			modelAndView.setViewName("coming_soon");


        } catch (SubCategoriesNotFoundException e) {

            LOGGER.error("--------First Promoted Sub-Categories Not Found Exception in showHome Controller----------");
        }


        return modelAndView;

    }


    @GetMapping("/subcategory")
    public ModelAndView showSubCategory(@RequestParam @Valid int parentId, ModelAndView modelAndView) {

        LOGGER.info("--------In showSubCategory Controller----------");
		modelAndView.setViewName("subcategories");
        try {

            modelAndView.addObject("subCategoriesList", shopping.getSubCategories(parentId));
            modelAndView.addObject("categoryName", shopping.getCategoryName(parentId));
            modelAndView.addObject("Message", "Available");

        	}

        catch (SubCategoriesNotFoundException e) {

            LOGGER.error("--------Sub Categories Not Found Exception in showSubCategory Controller----------");

            modelAndView.addObject("Message", "Coming Soon");

        }

        catch (CategoryNotFoundException e) {

			LOGGER.error("--------Category Not Found Exception in showSubCategory Controller----------");

			modelAndView.setViewName("Error_404");
        }


        return modelAndView;

    }



    @GetMapping("/products")
    public ModelAndView showProducts(@RequestParam int subCategoryId, ModelAndView model) {

        LOGGER.info("--------In products Controller----------");

		model.setViewName("products");

        try {


			model.addObject("productsList", shopping.getProducts(subCategoryId));
			model.addObject("subCategoryName", shopping.getCategoryName(subCategoryId));
			model.addObject("categoryName", shopping.getCategoryNameOfSubCategory(subCategoryId));

       		 }

        catch (SubCategoryNotFoundException e) {

            LOGGER.error("--------Sub Categories Not Found Exception in products Controller----------");

            model.setViewName("error_404");

        }

        catch (ProductNotFoundException e) {

            LOGGER.error("--------Product Not Found Exception in products Controller----------");

            model.addObject("Message", "Coming Soon");
			model.addObject("subCategoryName", shopping.getCategoryName(subCategoryId));
			model.addObject("categoryName", shopping.getCategoryNameOfSubCategory(subCategoryId));

		}

        return model;

    }

    @GetMapping("/productDetail")
    public ModelAndView showPoductDetails(@RequestParam String productId, ModelAndView model) {

        LOGGER.info("--------In productDetail Controller----------");
        model.setViewName("productDetails");


        try {
            model.addObject("productDetail", shopping.getProductDetail(productId));
            model.addObject("categoryName", shopping.getCategoryNameFromProductId(productId));
            model.addObject("subCategoryName", shopping.getSubCategoryNameFromProductId(productId));


        } catch (ProductNotFoundException e) {
            LOGGER.error("--------ProductNotFoundException in productDetail Controller----------");

            model.setViewName("Error_404");
        }


        return model;

    }

    @PostMapping("/addtocart")
    public RedirectView addToCart(@RequestParam String productId, @RequestParam int productQuantity, RedirectAttributes redirectAttributes,RedirectView redirectView) throws ProductNotFoundException, ProductNotInCartException, InvalidQuantityException {

        LOGGER.info("--------In addtocart Controller----------");

        try {
            cartService.addToCart(productId, productQuantity);

			redirectAttributes.addFlashAttribute("ProductAdditionMessage", "Product Has Been Successfully Added Into The Cart");

        }

        catch (InsufficientQuantityException e) {

            LOGGER.error("--------InsufficientQuantityException in addtocart Controller----------");

			redirectAttributes.addFlashAttribute("ProductAdditionMessage",
                    "Sorry It Seems We Don't Have That Much Stock Right Now. Try Again With The Lesser Quantity");
        }


        redirectView.setUrl("/productDetail");
        redirectView.addStaticAttribute("productId", productId);

        return redirectView;


    }

    @GetMapping("/cart")
    public ModelAndView showCart(ModelAndView model) {

        LOGGER.info("--------In cart Controller----------");

        model.setViewName("cart");

        return model;

    }

    @PostMapping("/checkout")
    public RedirectView checkout(ModelAndView model, RedirectAttributes redir) {

        LOGGER.info("--------In checkout Controller----------");

        try {

            redir.addFlashAttribute("OrderHistory", cartService.checkout());

        }

        catch (InsufficientQuantityException e) {

            LOGGER.error("--------InsufficientQuantityException in checkout Controller----------");
        }

        RedirectView redirectView = new RedirectView();
        redirectView.setUrl("/orders");
        return redirectView;

    }

    @GetMapping("/orders")
    public ModelAndView order(ModelAndView model) {

        LOGGER.info("--------In orders Controller----------");

        model.setViewName("Orders");
        return model;

    }

    @PostMapping("/deleteItem")
    public RedirectView deleteProduct(@RequestParam String productId, ModelAndView model, RedirectView redirectView) throws ProductNotInCartException {

        LOGGER.info("--------In deleteItem Controller----------");

        cartService.deleteCartItem(productId);

        redirectView.setUrl("/cart");

        return redirectView;

    }

    @PostMapping("/updateCart")
    public RedirectView updateCart(@RequestParam String productId, @RequestParam int productQuantity,
                                   RedirectAttributes redirectAttributes,RedirectView redirectView) throws ProductNotInCartException, InvalidQuantityException {

        LOGGER.info("--------In updateCart Controller----------");

        try {
            cartService.updateProductQuantity(productId, productQuantity);
			redirectAttributes.addFlashAttribute("ProductAdditionMessage", "Product Has Been Successfully Added Into The Cart");

        } catch (InsufficientQuantityException e) {

            LOGGER.error("--------InsufficientQuantityException in updateCart Controller----------");

			redirectAttributes.addFlashAttribute("ProductAdditionMessage",
                    "Sorry It Seems We Don't Have That Much Stock Right Now. Try Again With The Lesser Quantity");
        }


        redirectView.setUrl("/cart");
        return redirectView;

    }


    @GetMapping("/contactUs")
    public ModelAndView contactUs(ModelAndView model) {

        LOGGER.info("--------In contactUs Controller----------");


        model.setViewName("contactUs");
        return model;

    }


    @GetMapping("/login")
    public ModelAndView login(ModelAndView model) {

        LOGGER.info("--------In contactUs Controller----------");


        model.setViewName("login");
        return model;

    }


    @ExceptionHandler
    void handleIllegalArgumentException(IllegalArgumentException e, HttpServletResponse response) throws IOException {
        response.sendError(HttpStatus.BAD_REQUEST.value());
    }


    @ExceptionHandler
    void handleIllegalArgumentException(MissingServletRequestParameterException e, HttpServletResponse response) throws IOException {
        response.sendError(HttpStatus.BAD_REQUEST.value());
    }


}
