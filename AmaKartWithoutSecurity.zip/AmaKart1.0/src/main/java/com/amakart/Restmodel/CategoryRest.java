package com.amakart.Restmodel;

public class CategoryRest {

	private String Name;
	private int Id;

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	@Override
	public String toString() {
		return "CategoryRest [Name=" + Name + ", Id=" + Id + "]";
	}

}
