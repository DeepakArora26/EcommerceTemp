package com.amakart.dao;

import java.util.List;

import org.springframework.stereotype.Service;

import com.amakart.model.Category;

@Service
public interface ShoppingDaoService {

	
	
	
	
	
	
	
	
	
	

}
