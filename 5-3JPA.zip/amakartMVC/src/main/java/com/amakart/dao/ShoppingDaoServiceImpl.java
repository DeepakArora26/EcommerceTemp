package com.amakart.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.amakart.model.Category;
import com.amakart.service.ShoppingService;


@Service
public class ShoppingDaoServiceImpl implements ShoppingDaoService {

	EntityManagerFactory emFactory = Persistence.createEntityManagerFactory("my-local-mysql");

	EntityManager eManager;
	



}
