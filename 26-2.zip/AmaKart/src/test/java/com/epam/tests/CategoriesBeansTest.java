package com.epam.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.epam.model.Categories;
import com.epam.model.Product;

class CategoriesBeansTest {

	Categories category;

	@BeforeEach
	void init() {

		category = new Categories();

	}

	@Test
	void checkCategoryId() {

		assertEquals(null, category.getcategoryId());
	}

	@Test
	void checkCategoryId1() {
		category.setcategoryId("1");

		assertEquals("1", category.getcategoryId());
	}

	@Test
	void checkcategoryName() {

		assertEquals(null, category.getcategoryName());
	}

	@Test
	void checkcategoryName1() {
		category.setcategoryName("Electronics");

		assertEquals("Electronics", category.getcategoryName());
	}

	@Test
	void checkcategoryImage() {

		assertEquals(null, category.getcategoryImage());
	}

	@Test
	void checkcategoryImage1() {
		category.setcategoryImage("Fashion.jpg");
		assertEquals("Fashion.jpg", category.getcategoryImage());
	}

	@Test
	void checktoString() {

		assertEquals("Categories [categoryId=null, categoryName=null]", category.toString());
	}

	@Test
	void checktoString1() {

		category.setcategoryId("3");
		category.setcategoryName("Sports");

		assertEquals("Categories [categoryId=3, categoryName=Sports]", category.toString());

	}

}
