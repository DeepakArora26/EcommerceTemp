package com.epam.tests;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.epam.dao.ShoppingDaoService;
import com.epam.model.Categories;
import com.epam.services.ShoppingService;
import com.epam.services.ShoppingServiceImpl;

class ShoppingServiceImplTest {

	
	@Test
	void checlGetCategory() throws SQLException
	{
	
	ShoppingDaoService shopping = mock(ShoppingDaoService.class);
	
	Categories categoryDetail = mock(Categories.class);
	
	ShoppingService shoppingService = new ShoppingServiceImpl();
	List<Categories> categoryList = new ArrayList<>();
	
	
	categoryDetail.setcategoryId("1");
	categoryDetail.setcategoryName("Electronics");
	categoryDetail.setcategoryImage("Electronics.jpg");
	
	categoryList.add(categoryDetail);
	
	categoryDetail.setcategoryId("2");
	categoryDetail.setcategoryName("Fashion");
	categoryDetail.setcategoryImage("Fashion.jpg");
	
	categoryList.add(categoryDetail);
	
		when(shopping.getCategories()).thenReturn(categoryList);

	List<Categories> cat = shopping.getCategories();
	
	
	assertEquals(shopping.getCategories(),cat);
	
	
	
	}

}
