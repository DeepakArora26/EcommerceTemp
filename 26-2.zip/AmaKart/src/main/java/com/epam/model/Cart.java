package com.epam.model;

public class Cart {

	private String productId;
	private String productName;
	private double productPrice;
	private int productQuantity;
	private double totalPrice;
	public static double cartTotal;
	private String productImage;
	
	
	

	public Cart(String productId, String productName, double productPrice, int productQuantity, String productImage) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productPrice = productPrice;
		this.productQuantity = productQuantity;
		this.totalPrice = productPrice * productQuantity;
		this.productImage = productImage;
	}

	public String getproductId() {
		return productId;
	}

	public void setproductId(String productId) {
		this.productId = productId;
	}

	public String getproductName() {
		return productName;
	}

	public void setproductName(String productName) {
		this.productName = productName;
	}

	public double getproductPrice() {
		return productPrice;
	}

	public void setproductPrice(double productPrice) {
		this.productPrice = productPrice;
	}

	public int getproductQuantity() {
		return productQuantity;
	}

	public void setproductQuantity(int productQuantity) {
		this.productQuantity = productQuantity;
		totalPrice = productPrice * productQuantity;
	}

	public double gettotalPrice() {
		return totalPrice;
	}

	public void settotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}


	public String getproductImage() {
		return productImage;
	}

	public void setproductImage(String productImage) {
		this.productImage = productImage;
	}

	
	

	@Override
	public String toString() {
		return productId + "             " +  productName + productPrice +  "                    " + productQuantity + "                 "+ totalPrice;
	}

}
