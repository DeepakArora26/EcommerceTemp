package com.epam.model;

import java.util.Date;

public class OrderHistory {

	private String orderId;
	private String customerName;
	private Double cartTotal;
	private Date orderDate;

	public String getorderId() {
		return orderId;
	}

	public void setorderId(String orderId) {
		this.orderId = orderId;
	}

	public String getcustomerName() {
		return customerName;
	}

	public void setcustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Double getcartTotal() {
		return cartTotal;
	}

	public void setcartTotal(Double cartTotal) {
		this.cartTotal = cartTotal;
	}

	public Date getorderDate() {
		return orderDate;
	}

	public void setorderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	@Override
	public String toString() {
		return "Order_History [orderId=" + orderId + ", customerName=" + customerName + ", cartTotal=" + cartTotal
				+ ", orderDate=" + orderDate + "]";
	}

}
