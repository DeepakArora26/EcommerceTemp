package com.epam.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.epam.model.Cart;
import com.epam.model.Categories;

public interface ShoppingDaoService {

	List<Categories> getCategories() throws SQLException;

	ResultSet getSubCategories(String categoryId);

	ResultSet getProducts(String subCategoryId);

	ResultSet getProductDetails(String productId);
	
	void checkout(String customerName , List<Cart> currentCart);

}
