package com.epam.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.epam.model.Cart;
import com.epam.services.CartService;
import com.epam.services.CartServiceImpl;

@WebServlet("/cart")
public class DisplayCart extends HttpServlet {
	private static final long serialVersionUID = 1L;

	static CartService cartShopping;
	static RequestDispatcher rd;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		cartShopping = new CartServiceImpl();
		cartShopping.calculateCartTotal();

		request.setAttribute("CartDetail", cartShopping.getCart());
		request.setAttribute("CartTotal", Cart.cartTotal);
		rd = request.getRequestDispatcher("jsp/cart.jsp");
		rd.forward(request, response);

	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		rd = request.getRequestDispatcher("jsp/cart.jsp");

		rd.forward(request, response);

	}

}
