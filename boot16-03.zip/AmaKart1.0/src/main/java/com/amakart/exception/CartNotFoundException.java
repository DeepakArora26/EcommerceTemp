package com.amakart.exception;

@SuppressWarnings("serial")
public class CartNotFoundException extends Exception {

	public CartNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
