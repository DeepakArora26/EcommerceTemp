package com.amakart.exception;

@SuppressWarnings("serial")
public class FirstPromotedCategoryNotFoundException extends Exception {

	public FirstPromotedCategoryNotFoundException(String message) {
		super(message);
	}

}
