package com.amakart.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.amakart.exception.CartNotFoundException;
import com.amakart.model.Cart;
import com.amakart.model.CartItem;
import com.amakart.model.OrderItem;
import com.amakart.model.Orders;
import com.amakart.model.Product;
import com.amakart.repository.CartItemRepository;
import com.amakart.repository.CartRepository;
import com.amakart.repository.OrdersRepository;
import com.amakart.repository.ProductRepository;

@Service
public class CartServiceImpl implements CartService {

	@Autowired
	CartItem cartItem;

	@Autowired
	ProductRepository productRepository;

	@Autowired
	Product product;

	@Autowired
	OrderItem orderItem;

	@Autowired
	Orders order;

	@Autowired
	OrdersRepository orderRepository;

	@Autowired
	CartItemRepository cartItemRepository;

	@Autowired
	CartRepository cartRepository;

	@Autowired
	Cart cart;

	@Override
	public boolean addToCart(String productId, int productQuantity) {

		boolean flag = false;

		cart = getCart();

		cartItem = new CartItem();

		if (productExistInCart(productId)) {

			int updateQuantity = productQuantity + checkExistingProductQuantity(productId);

			if (checkProductQuantity(productId, updateQuantity)) {

				cartItem = cartItemRepository.findById(productId).get();
				cartItem.setProductPurchasedQuantity(updateQuantity);
				cartItem.setProductTotalPrice();
				cartItemRepository.save(cartItem);

				flag = true;
			}

		}

		else {

			if (checkProductQuantity(productId, productQuantity)) {

				product = productRepository.findByProductId(productId);

				cartItem.setProductId(product.getProductId());
				cartItem.setProductImage(product.getThumbnail());
				cartItem.setProductName(product.getProductName());
				cartItem.setProductPrice(product.getProductDiscountedPrice());
				cartItem.setProductPurchasedQuantity(productQuantity);
				cartItem.setProductTotalPrice();
				cartItem.setCart(cart);

				cartItemRepository.save(cartItem);
				cartItemRepository.flush();

				flag = true;

			}

		}

		calculateCartTotal();
		return flag;
	}

	@Override
	public void calculateCartTotal() {

		Double cartTotal = 0.0;

		for (CartItem currentProduct : cartItemRepository.findAll()) {

			cartTotal = cartTotal + currentProduct.getProductTotalPrice();
		}

		cart.setCartTotal(cartTotal);
		cartRepository.save(cart);

	}

	@Override
	public boolean checkProductQuantity(String productId, int productQuantity) {

		return (productRepository.findByProductId(productId).getProductAvailableStock() >= productQuantity);

	}

	@Override
	public boolean productExistInCart(String productId) {

		boolean result = false;

		Optional<CartItem> cartItem = cartItemRepository.findById(productId);

		if (cartItem.isPresent()) {
			result = true;
		}

		return result;

	}

	@Override
	public int checkExistingProductQuantity(String productId) {

		return cartItemRepository.findById(productId).get().getProductPurchasedQuantity();

	}

	@Override
	public Orders checkout() {

		cart = getCart();
		
		order = new Orders();

		for (CartItem productDetail : cart.getCartItems()) {

			orderItem = new OrderItem();
			
			orderItem.setProductId(productDetail.getProductId());
			orderItem.setProductImage(productDetail.getProductImage());
			orderItem.setProductName(productDetail.getProductName());
			orderItem.setProductPrice(productDetail.getProductPrice());
			orderItem.setProductPurchasedQuantity(productDetail.getProductPurchasedQuantity());
			orderItem.setProductTotalPrice(productDetail.getProductTotalPrice());
			order.addProduct(orderItem);
		}

		order.setCartTotal(cart.getCartTotal());
		long millis = System.currentTimeMillis();
		java.sql.Date date = new java.sql.Date(millis);

		order.setOrderDate(date);
		order.setCustomerId("Dummy Customer");

		orderRepository.save(order);
		
		
		cartItemRepository.deleteAll();
		cartRepository.deleteAll();
		
		
		
		cart = getCart();
		
		initializeCart();
		return order;
	}

	@Override
	public Cart getCart() {

		if (cartRepository.findById(1) == null) {

			initializeCart();
		}

		return cartRepository.findById(1);
	}

	@Override
	public void initializeCart() {
		// TODO Auto-generated method stub

		cart.setCartId(1);
		cart.setCartTotal(0.0);
		cart.setUserId("Dummy User");
		cartRepository.save(cart);

	}

}
