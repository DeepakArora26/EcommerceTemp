package com.amakart.service;

import com.amakart.model.Cart;
import com.amakart.model.Orders;

public interface CartService {

	boolean addToCart(String productId, int productQuantity);

	boolean checkProductQuantity(String productId, int productQuantity);

	void calculateCartTotal();

	boolean productExistInCart(String productId);
	
	int checkExistingProductQuantity(String productId);

	Orders checkout();
	
	Cart getCart();
	
	void initializeCart();
	

}
