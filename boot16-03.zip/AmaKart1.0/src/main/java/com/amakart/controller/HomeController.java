package com.amakart.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.taglibs.standard.tag.el.core.RedirectTag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;

import com.amakart.exception.CartNotFoundException;
import com.amakart.exception.CategoriesNotFoundException;
import com.amakart.exception.FirstPromotedCategoryNotFoundException;
import com.amakart.exception.SecondPromotedCategoryNotFoundException;
import com.amakart.model.Cart;
import com.amakart.service.CartService;
import com.amakart.service.ShoppingService;

@Controller
public class HomeController {

	private static final Logger LOGGER = LogManager.getLogger(HomeController.class);

	@Autowired
	ShoppingService shopping;

	@Autowired
	CartService cartService;
	
	

	@GetMapping("/")
	public ModelAndView showHome(ModelAndView model) {

		LOGGER.info("--------In showHome Controller----------");
		
		model.setViewName("Home");

		try {
			model.addObject("categoriesList", shopping.getCategories(0));

			model.addObject("firstPromoted", shopping.getFirstPromoted());

			model.addObject("firstPromotedSubcategories", shopping.getCategories(shopping.getFirstPromoted().getId()));

			model.addObject("secondPromoted", shopping.getSecondPromoted());

			
			model.addObject("secondPromotedSubcategories",
					shopping.getCategories(shopping.getSecondPromoted().getId()));
			
			model.addObject("Cart", cartService.getCart().getCartItems());
			model.addObject("CartTotal", cartService.getCart().getCartTotal());

			
		}

		catch (CategoriesNotFoundException e) {

			LOGGER.info("--------Exception in showHome Controller----------");
			
			model.setViewName("coming_soon");
		}

		catch (SecondPromotedCategoryNotFoundException e) {

			LOGGER.info("--------Exception in showHome Controller----------");

			model.addObject("SecondPromotedCategoryMessage", "Coming Soon !");
		}
		
		

		
		return model;

	}

	@GetMapping("/subcategory")
	public ModelAndView showSubCategory(@RequestParam int parentId,@RequestParam String categoryName, ModelAndView model) {

		LOGGER.info("--------In showSubCategory Controller----------");

		try {
			
			model.addObject("categoriesList", shopping.getCategories(0));
			model.addObject("categoryName",categoryName);


			model.addObject("Cart", cartService.getCart().getCartItems());
			model.addObject("CartTotal", cartService.getCart().getCartTotal());


			model.addObject("subCategoriesList", shopping.getCategories(parentId));

		}

		catch (CategoriesNotFoundException e) {

			LOGGER.info("--------Exception in showSubCategory Controller----------");

			model.addObject("Message", "New Categories Coming Soon !!!!");
		}

		model.setViewName("subcategories");
		return model;

	}

	@GetMapping("/products")
	public ModelAndView showPoducts(@RequestParam int subCategoryId, ModelAndView model) {

		try {
			model.addObject("categoriesList", shopping.getCategories(0));
		} catch (CategoriesNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


		model.addObject("Cart", cartService.getCart().getCartItems());
		model.addObject("CartTotal", cartService.getCart().getCartTotal());

		model.setViewName("products");
		model.addObject("productsList", shopping.getProducts(subCategoryId));
		return model;

	}

	@GetMapping("/productDetail")
	public ModelAndView showPoductDetails(@RequestParam String productId, ModelAndView model) {

		try {
			model.addObject("categoriesList", shopping.getCategories(0));
		} catch (CategoriesNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

		model.addObject("Cart", cartService.getCart().getCartItems());
		model.addObject("CartTotal", cartService.getCart().getCartTotal());

		model.setViewName("productDetails");
		model.addObject("productDetail", shopping.getProductDetail(productId));
		return model;

	}

	@PostMapping("/addtocart")
	public RedirectView addToCart(@RequestParam String productId, @RequestParam int productQuantity,
			 RedirectAttributes redir) {

		if (cartService.addToCart(productId, productQuantity)) {
			redir.addFlashAttribute("ProductAdditionMessage", "Product Has Been Successfully Added Into The Cart");
			
		}

		else {
			redir.addFlashAttribute("ProductAdditionMessage", 
					"Sorry It Seems We Don't Have That Much Stock Right Now. Try Again With The Lesser Quantity");
		}
		
		
		RedirectView redirectView = new RedirectView();
		redirectView.setUrl("/productDetail");
		redirectView.addStaticAttribute("productId", productId);
		
		return redirectView;

	}

	@GetMapping("/cart")
	public ModelAndView showCart(ModelAndView model) {

		model.setViewName("cart");

		try {
			model.addObject("categoriesList", shopping.getCategories(0));
		} catch (CategoriesNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		model.addObject("Cart", cartService.getCart().getCartItems());
		model.addObject("CartTotal", cartService.getCart().getCartTotal());
		return model;

	}

	@PostMapping("/checkout")
	public ModelAndView checkout(ModelAndView model) {

		model.setViewName("Orders");
		model.addObject("OrderHistory", cartService.checkout());
		return model;

	}

}
