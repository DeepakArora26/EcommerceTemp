package com.amakart.controllertest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import com.amakart.controller.HomeController;

class HomeControllerTest {
	
	
	@InjectMocks
	HomeController homeController;

	@Test
	void test() {
	}

}
