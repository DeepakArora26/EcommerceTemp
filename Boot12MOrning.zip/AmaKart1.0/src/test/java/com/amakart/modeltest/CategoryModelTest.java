package com.amakart.modeltest;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;

import com.amakart.model.Category;
import com.amakart.model.Product;
import com.amakart.model.ProductAttribute;

@SpringBootTest
class CategoryModelTest {

	@Autowired
	Category category;

	@Mock
	Product product;

	@Mock
	List<Product> products = new ArrayList<>();

	@Mock
	ProductAttribute productAttributeDetail;

	@Test
	void checkCategoryId() {

		category.setId(1);
		assertEquals(1, category.getId());

	}

	@Test
	void checkCategoryName() {

		category.setName("Electronics");
		assertEquals("Electronics", category.getName());

	}

	@Test
	void checkCategoryParentId() {

		category.setParentId(2);
		assertEquals(2, category.getParentId());

	}

	@Test
	void checkCategoryImage() {

		category.setImage("Sports.png");
		assertEquals("Sports.png", category.getImage());

	}

	@Test
	void checkCategoryPromotion() {

		category.setPromoted(false);
		assertEquals(false, category.isPromoted());

	}

	@Test
	void checkCategoryPromotionThumbnail() {

		category.setPromotedThumbnail("ManBig.jpg");
		assertEquals("ManBig.jpg", category.getPromotedThumbnail());

	}

	@Test
	void checkCategoryConstructorWith3Value() {

		category = new Category("Electronics", 0, "Electronics.jpg");
		assertEquals("Electronics", category.getName());
		assertEquals(0, category.getId());
		assertEquals("Electronics.jpg", category.getImage());

	}

	@Test
	void checkCategoryConstructorWith4Value() {

		category = new Category("Electronics", 0, "Electronics.jpg", "PromotedElectronics.jpg");
		assertEquals("Electronics", category.getName());
		assertEquals(0, category.getId());
		assertEquals("Electronics.jpg", category.getImage());
		assertEquals("PromotedElectronics.jpg", category.getPromotedThumbnail());

	}

	@Test
	void checkCategoryConstructorWith5Value() {

		category = new Category("Electronics", 0, "Electronics.jpg", true, "PromotedElectronics.jpg");
		assertEquals("Electronics", category.getName());
		assertEquals(0, category.getId());
		assertEquals("Electronics.jpg", category.getImage());
		assertEquals("PromotedElectronics.jpg", category.getPromotedThumbnail());
		assertEquals(true, category.isPromoted());

	}

	@Test
	void checkCategorytoString() {

		category.setId(1);
		category.setName("Sports");
		category.setParentId(0);
		category.setImage("Sports.jpg");
		category.setPromoted(true);
		category.setPromotedThumbnail("SportsBanner.jpg");
		assertEquals(
				"Category [id=1, name=Sports, parentId=0, image=Sports.jpg, promoted=true, promotedThumbnail=SportsBanner.jpg]",
				category.toString());

	}

}
