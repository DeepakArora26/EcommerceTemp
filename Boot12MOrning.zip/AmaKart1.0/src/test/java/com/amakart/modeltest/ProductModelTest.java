package com.amakart.modeltest;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.amakart.model.Category;
import com.amakart.model.Product;
import com.amakart.model.ProductAttribute;


@SpringBootTest
class ProductModelTest {
	
	
	@Autowired
	Product product;
	
	@Autowired
	ProductAttribute productAttributeDetail;
	
	@Autowired
	Category category;
	


	@Test
	void checkProductId() {

		product.setProductId("M1");
		assertEquals("M1", product.getProductId());

	}
	
	
	
	
	@Test
	void checkProductName() {

		product.setProductName("Redmi Note 8");
		assertEquals("Redmi Note 8", product.getProductName());

	}

	
	
	@Test
	void checkProductMrp() {

		product.setProductMrp(999.00);
		assertEquals(999.00, product.getProductMrp());

	}
	
	@Test
	void checkProductDiscountedPrice() {

		product.setProductDiscountedPrice(1999.00);
		assertEquals(1999.00, product.getProductDiscountedPrice());

	}
	
	
	
	@Test
	void checkProductAvailableStock() {

		product.setProductAvailableStock(1999);
		assertEquals(1999, product.getProductAvailableStock());

	}
	
	
	
	
	@Test
	void checkProductAverageRating() {

		product.setProductAverageRating(4.2);
		assertEquals(4.2, product.getProductAverageRating());

	}
	
	
	
	@Test
	void checkProductThumbnail() {

		product.setThumbnail("RedmiNote.jpg");
		assertEquals("RedmiNote.jpg", product.getThumbnail());

	}
	
	
	@Test
	void Attrbiutes() {

		productAttributeDetail.setAttributeId(1);
		productAttributeDetail.setAttributeName("ROM");
		productAttributeDetail.setAttributeValue("64GB");
		product.addAttribute(productAttributeDetail);
		List<ProductAttribute> attributeList = new ArrayList<>();
		attributeList.add(productAttributeDetail);
		assertEquals(attributeList, product.getAttrbiutes());

	}
	
	
	
	@Test
	void checkProductImages() {
		List<String> productimages = new ArrayList<>();
		productimages.add("RedmiNote.jpg");
		productimages.add("RedmiNote1.jpg");
		product.addImage("RedmiNote.jpg");
		product.addImage("RedmiNote1.jpg");
		assertEquals(productimages, product.getProductImages());

	}
	
	

	@Test
	void checkProducttoString() {
		
		
		product.setProductId("M1");
		product.setProductName("Redmi Note 8");
		product.setProductMrp(999.00);
		product.setProductDiscountedPrice(1999.00);
		product.setProductAverageRating(4.2);
		product.setThumbnail("RedmiNote.jpg");
		productAttributeDetail.setAttributeId(1);
		productAttributeDetail.setAttributeName("ROM");
		productAttributeDetail.setAttributeValue("64GB");
		product.addAttribute(productAttributeDetail);
		product.addImage("RedmiNote.jpg");
		product.addImage("RedmiNote1.jpg");
		category.setId(1);
		category.addProduct(product);
		assertEquals("Product [productId=M1, subCategoryId=, productName=Redmi Note 8, productMrp=999.0, productDiscountedPrice=1999.0, productAvailableStock=0, productAverageRating=4.2, thumbnail=RedmiNote.jpg, attrbiutes=[ProductAttribute [attributeId=1, attributeName=ROM, attributeValue=64GB]], productImages=[RedmiNote.jpg, RedmiNote1.jpg]]", product.toString());

	}
	
	
	
	
	
	
}
