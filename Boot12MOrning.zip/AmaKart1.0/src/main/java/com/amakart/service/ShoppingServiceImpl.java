package com.amakart.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.amakart.model.Category;
import com.amakart.model.Product;
import com.amakart.repository.CategoryRepository;
import com.amakart.repository.ProductRepository;

@Service
public class ShoppingServiceImpl implements ShoppingService {

	@Autowired
	CategoryRepository categoryRepository;

	@Autowired
	ProductRepository productRepository;

	@Override
	public List<Category> getCategories(int parentId) {
		return categoryRepository.findByparentId(parentId);
	}

	@Override
	public List<Product> getProducts(int subCategoryId) {
		
		return categoryRepository.findById(subCategoryId).get(0).getProducts();
		
	}

	@Override
	public Product getProductDetail(String productId) {
		return productRepository.findByProductId(productId);
	}

	@Override
	public Category getFirstPromoted() {
		return categoryRepository.findFirstPromotedCategory();
	}

	@Override
	public Category getSecondPromoted() {
		return categoryRepository.findSecondPromotedCategory();
	}

	@Override
	public boolean checkOut() {
		// TODO Auto-generated method stub
		return false;
	}

}
