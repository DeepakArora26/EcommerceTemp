package com.amakart.service;

import com.amakart.model.OrderHistory;

public interface CartService {
	
	
	

	boolean addToCart(String productId,int productQuantity);
	
	boolean checkProductQuantity(String productId,int productQuantity);
	
	void calculateCartTotal();

	int productExistInCart(String productId);
	
	OrderHistory checkout();
	
	
}
