package com.amakart.model;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.springframework.stereotype.Component;

@Entity
@Component
public class OrderHistory {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int orderNo;
	private String customerId;
	private Double cartTotal;
	private Date orderDate;
	@OneToMany(mappedBy = "orderHistory", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	private List<OrderDetails> orderDetailList = new ArrayList<>();

	public int getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(int orderNo) {
		this.orderNo = orderNo;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public Double getCartTotal() {
		return cartTotal;
	}

	public void setCartTotal(Double cartTotal) {
		this.cartTotal = cartTotal;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public List<OrderDetails> getOrderDetailList() {
		return orderDetailList;
	}

	public void addProduct(OrderDetails orderdetail) {
		orderdetail.setOrderHistory(this);
		orderDetailList.add(orderdetail);
	}

	@Override
	public String toString() {
		return "OrderHistory [orderNo=" + orderNo + ", customerId=" + customerId + ", cartTotal=" + cartTotal
				+ ", orderDate=" + orderDate + ", orderDetailList=" + orderDetailList + "]";
	}

}
