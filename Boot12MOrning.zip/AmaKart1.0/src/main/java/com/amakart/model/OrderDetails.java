package com.amakart.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.ManyToAny;
import org.springframework.stereotype.Component;

@Entity
@Component
public class OrderDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int productOrderNo;
	private String productId;
	private String productName;
	private Double productPrice;
	private int productPurchasedQuantity;
	private Double productTotalPrice;
	@ManyToOne
	@JoinColumn(name = "orderNo")
	private OrderHistory orderHistory;
	private String productImage;

	public int getProductOrderNo() {
		return productOrderNo;
	}

	public void setProductOrderNo(int productOrderNo) {
		this.productOrderNo = productOrderNo;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public Double getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(Double productPrice) {
		this.productPrice = productPrice;
	}

	public int getProductPurchasedQuantity() {
		return productPurchasedQuantity;
	}

	public void setProductPurchasedQuantity(int productPurchasedQuantity) {
		this.productPurchasedQuantity = productPurchasedQuantity;
	}

	public Double getProductTotalPrice() {
		return productTotalPrice;
	}

	public void setProductTotalPrice(Double productTotalPrice) {
		this.productTotalPrice = productTotalPrice;
	}

	public OrderHistory getOrderHistory() {
		return orderHistory;
	}

	public void setOrderHistory(OrderHistory orderHistory) {
		this.orderHistory = orderHistory;
	}

	public String getProductImage() {
		return productImage;
	}

	public void setProductImage(String productImage) {
		this.productImage = productImage;
	}

	@Override
	public String toString() {
		return "OrderDetails [productOrderNo=" + productOrderNo + ", productId=" + productId + ", productName="
				+ productName + ", productPrice=" + productPrice + ", productPurchasedQuantity="
				+ productPurchasedQuantity + ", productTotalPrice=" + productTotalPrice + ", productImage="
				+ productImage + "]";
	}

}
