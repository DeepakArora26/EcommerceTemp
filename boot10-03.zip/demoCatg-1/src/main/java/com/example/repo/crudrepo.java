package com.example.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.model.Category;

@Repository
public interface crudrepo extends JpaRepository<Category, Integer> {

	List<Category> findByparentId(int parendId);

	@Query(value = " SELECT * FROM category where promoted=1 LIMIT 1 offset 0", nativeQuery = true)
	Category findFirstPromoted();

	@Query(value = " SELECT * FROM category where promoted=1 LIMIT 1 offset 1", nativeQuery = true)
	Category findSecondPromoted();
	
	
	
	


}
