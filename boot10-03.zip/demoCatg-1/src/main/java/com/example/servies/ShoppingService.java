package com.example.servies;

import java.util.List;

import com.example.model.Category;
import com.example.model.Product;

public interface ShoppingService {

	List<Category> getCategories(int parentId);

	/* List<Product> getProducts(int subCategoryId); */
	
	Product getProductDetail(String productId);
	
	
	Category getFirstPromoted();

	
	Category getSecondPromoted();
	
}
