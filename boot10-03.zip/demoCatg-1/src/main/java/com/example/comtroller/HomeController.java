package com.example.comtroller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.servies.ShoppingService;

@Controller
public class HomeController {

	@Autowired
	ShoppingService shopping;

	@GetMapping("/")
	public ModelAndView showHome(ModelAndView model) {

		model.setViewName("Home");
		model.addObject("categoriesList", shopping.getCategories(0));

		model.addObject("firstPromoted", shopping.getFirstPromoted());

		model.addObject("firstPromotedSubcategories", shopping.getCategories(shopping.getFirstPromoted().getId()));

		model.addObject("secondPromoted", shopping.getSecondPromoted());

		model.addObject("secondPromotedSubcategories", shopping.getCategories(shopping.getSecondPromoted().getId()));

		return model;

	}

	@PostMapping("/subcategory")
	public ModelAndView showSubCategory(@RequestParam int parentId, ModelAndView model) {

		model.setViewName("subcategories");
		model.addObject("subCategoriesList", shopping.getCategories(parentId));
		return model;

	}

	@PostMapping("/products")
	public ModelAndView showPoducts(@RequestParam int subCategoryId, ModelAndView model) {

		model.setViewName("products");
		// model.addObject("productsList",shopping.getProducts(subCategoryId));
		return model;

	}

	@PostMapping("/productDetail")
	public ModelAndView showPoductDetails(@RequestParam String productId, ModelAndView model) {

		model.setViewName("productDetails");
		model.addObject("productDetail", shopping.getProductDetail(productId));
		return model;

	}

}
